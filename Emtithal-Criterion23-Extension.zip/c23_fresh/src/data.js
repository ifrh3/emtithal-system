// data.js — Criterion 23: Switch Design System Compliance
const CRITERION_23_NAME    = "Ensure Switch follows the Platforms Code Design System";
const CRITERION_23_NAME_AR = "التأكد من أن عنصر زر التبديل يتماشى مع معايير التصميم الموحد (كود المنصات)";

const CATEGORY_COLORS = {
  "أساسات":"#E5E500","قوالب":"#E49EDD","عناصر":"#94DCF8","التجربة":"#9DA6F3"
};

const EMPTY_SUMMARY = {
  totalSwitches:0,nativeSwitches:0,customSwitches:0,
  switchesWithIssues:0,issuesCount:0,
  baseDesignMismatch:0,interactiveStateIssue:0,contextualStateIssue:0,
  bySeverity:{Critical:0,High:0,Medium:0,Low:0,"Manual Review":0}
};

const BASE_SUB_CRITERIA = [
  {
    id:"base-design-compliance",requirement:"Base Design Compliance",category:"Base Design Mismatch",
    title:"مطابقة التصميم الأساسي لـ Switch",
    description:"التحقق من أن عنصر Switch يستخدم الشكل الممدود (pill)، الحواف، اللون، المسافات، والمقبض (thumb) كما هي معتمدة في كود المنصات دون أي تعديل على التصميم الأساسي.",
    howToFix:"استخدم مكوّن Switch الرسمي من كود المنصات. أزل أي تنسيقات مباشرة تعدل الشكل أو الأبعاد أو الألوان.",
    reason:"لم يتم العثور على مخالفات مؤكدة في التصميم الأساسي لـ Switch.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"interactive-states-compliance",requirement:"Interactive States Compliance",category:"Interactive State Issue",
    title:"تطبيق الحالات التفاعلية (Default, Hovered, Focused, Disabled)",
    description:"التحقق من تطبيق جميع الحالات التفاعلية المعتمدة: Default, Hovered, Focused, Disabled — كما هو معتمد في كود المنصات.",
    howToFix:"عرّف حالات :hover و:focus و:disabled باستخدام أنماط نظام التصميم الرسمي. تأكد من ظهور focus ring واضح وأن الحالة المعطلة غير تفاعلية.",
    reason:"تم العثور على أدلة كافية على الحالات التفاعلية المطلوبة.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"contextual-states-compliance",requirement:"Contextual States Compliance",category:"Contextual State Issue",
    title:"تطبيق الحالات السياقية (On / Off)",
    description:"التحقق من وجود تمييز بصري واضح بين حالة On (مفعّل) وOff (معطّل) — الأخضر المعتمد لـ On والرمادي لـ Off — مع ضمان صحة aria-checked.",
    howToFix:"تأكد من أن CSS يغيّر لون Switch بين On/Off. أضف aria-checked للعناصر المخصصة وحدّثها عند كل تفاعل.",
    reason:"الحالتان السياقيتان On/Off مُطبَّقتان بشكل صحيح.",
    status:"pass",occurrences:0,issues:[]
  }
];

function normaliseIssueForPanel(issue,index) {
  return {
    ...issue,n:index+1,
    target:issue.selector||issue.domPath||`[data-pc-c23-id='${issue.id||index+1}']`,
    element:issue.elementLabel||issue.selector||"عنصر Switch",
    current:issue.actual||issue.evidence||"يتطلب مراجعة",
    suggested:issue.expected||"مطابقة مكوّن Switch الرسمي في كود المنصات",
    location:`${issue.category} · ${issue.selector||issue.domPath||"DOM"}`
  };
}

function createEmptyCriterion23Report() {
  return {criterion:"23",criterionName:CRITERION_23_NAME,criterionNameAr:CRITERION_23_NAME_AR,pageUrl:"—",pageTitle:"",scanDate:"",score:100,status:"Passed",summary:{...EMPTY_SUMMARY},issues:[]};
}

function buildStandardDataFromReport(report) {
  const safeReport=report||createEmptyCriterion23Report();
  const grouped=BASE_SUB_CRITERIA.map(item=>({...item,issues:[]}));

  (safeReport.issues||[]).forEach((issue,idx)=>{
    const pi=normaliseIssueForPanel(issue,idx);
    const target=grouped.find(g=>g.category===issue.category||g.requirement===issue.requirement)||grouped[0];
    target.issues.push(pi);
  });

  grouped.forEach(item=>{
    item.occurrences=item.issues.length;
    item.status=item.issues.length?"fail":"pass";
    if(item.issues.length) item.reason=`تم العثور على ${item.issues.length} عنصر يحتاج إلى معالجة ضمن هذا المتطلب.`;
  });

  const passed=grouped.filter(g=>g.status==="pass").length;
  const total=grouped.length;
  const tScore=Math.round((passed/total)*100);
  const tStatus=tScore===100?"Passed":tScore===0?"Failed":"Needs Review";
  const summary={...EMPTY_SUMMARY,...(safeReport.summary||{})};
  const scanDate=safeReport.scanDate||"";

  return {
    number:23,category:"عناصر",categoryColor:CATEGORY_COLORS["عناصر"],
    title:"مطابقة عنصر Switch لنظام كود المنصات",titleEn:CRITERION_23_NAME,
    description:"التأكد من أن عنصر Switch يطابق التصميم الرسمي في كود المنصات، بما يشمل الشكل الممدود، الحالات التفاعلية الأربع، والحالتين السياقيتين On/Off.",
    reference:"https://design.dga.gov.sa/guidelines/components/forms-and-inputs/switch | Figma: Components Library - Platforms Code",
    pageUrl:safeReport.pageUrl||"—",pageTitle:safeReport.pageTitle||"الصفحة الحالية",
    scanDate,scanDateFormatted:scanDate?new Date(scanDate).toLocaleString("ar-SA"):"—",
    totalElementsScanned:summary.totalSwitches||0,affectedElements:summary.switchesWithIssues||0,
    score:tScore,severityScore:typeof safeReport.score==="number"?safeReport.score:100,
    status:tStatus,summary,report:safeReport,subCriteria:grouped
  };
}

function getIssueKey(issue){return issue?.id||issue?.target||`issue-${issue?.n}`;}

function getEffectiveSubCriteria(data,ignoredIssues={}) {
  return data.subCriteria.map(criterion=>{
    const original=criterion.issues||[];
    const active=original.filter(i=>!ignoredIssues[getIssueKey(i)]);
    const wasPass=criterion.status==="pass";
    const isPass=wasPass||active.length===0;
    return {...criterion,status:isPass?"pass":"fail",issues:active,occurrences:wasPass?criterion.occurrences:active.length,reason:!wasPass&&active.length===0?"تم تجاهل جميع العناصر المخالفة لهذا المتطلب.":criterion.reason};
  });
}

function getCurrentCriterion23Report(){return window.CURRENT_C23_REPORT||createEmptyCriterion23Report();}
function setCurrentCriterion23Report(report){
  window.CURRENT_C23_REPORT=report||createEmptyCriterion23Report();
  window.STANDARD_DATA=buildStandardDataFromReport(window.CURRENT_C23_REPORT);
  return window.STANDARD_DATA;
}

const STANDARD_DATA=buildStandardDataFromReport(null);
window.CRITERION_23_NAME=CRITERION_23_NAME;
window.CRITERION_23_NAME_AR=CRITERION_23_NAME_AR;
window.EMPTY_SUMMARY=EMPTY_SUMMARY;
window.STANDARD_DATA=STANDARD_DATA;
window.createEmptyCriterion14Report=createEmptyCriterion23Report;
window.createEmptyCriterion23Report=createEmptyCriterion23Report;
window.buildStandardDataFromReport=buildStandardDataFromReport;
window.getCurrentCriterion14Report=getCurrentCriterion23Report;
window.getCurrentCriterion23Report=getCurrentCriterion23Report;
window.setCurrentCriterion14Report=setCurrentCriterion23Report;
window.setCurrentCriterion23Report=setCurrentCriterion23Report;
window.getIssueKey=getIssueKey;
window.getEffectiveSubCriteria=getEffectiveSubCriteria;
