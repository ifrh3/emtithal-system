// switch-audit.js — Criterion 23: Switch Design System Compliance
(function () {
  "use strict";

  const CRITERION      = "23";
  const CRITERION_NAME = "Ensure Switch follows the Platforms Code Design System";

  const CAT_BASE  = "Base Design Mismatch";
  const CAT_STATE = "Interactive State Issue";
  const CAT_CTX   = "Contextual State Issue";

  const REQ_BASE  = "Base Design Compliance";
  const REQ_STATE = "Interactive States Compliance";
  const REQ_CTX   = "Contextual States Compliance";

  // ── Utilities ──────────────────────────────────────────────────────────────
  function nowIso() { return new Date().toISOString(); }
  function cleanText(v, max=120) { return String(v||"").replace(/\s+/g," ").trim().slice(0,max); }
  function cssEscape(v) { if(window.CSS&&CSS.escape) return CSS.escape(v); return String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&"); }
  function cssNum(v) { const n=parseFloat(String(v||"").replace("px","")); return isFinite(n)?n:0; }

  function parseRgb(color) {
    const s=String(color||"").trim().toLowerCase();
    if(!s||s==="transparent"||s==="rgba(0, 0, 0, 0)") return {r:0,g:0,b:0,a:0};
    const m=s.match(/^rgba?\(([^)]+)\)$/);
    if(m){const p=m[1].split(/[,/ ]+/).map(parseFloat).filter(isFinite);return{r:p[0]||0,g:p[1]||0,b:p[2]||0,a:p.length>3?p[3]:1};}
    const h=s.match(/^#([0-9a-f]{3,8})$/i);
    if(h){let v=h[1];if(v.length===3||v.length===4)v=v.split("").map(c=>c+c).join("");return{r:parseInt(v.slice(0,2),16),g:parseInt(v.slice(2,4),16),b:parseInt(v.slice(4,6),16),a:v.length>=8?parseInt(v.slice(6,8),16)/255:1};}
    return {r:0,g:0,b:0,a:-1};
  }

  function rgbToHsl(c) {
    const r=c.r/255,g=c.g/255,b=c.b/255,max=Math.max(r,g,b),min=Math.min(r,g,b);
    let h=0,s=0;const l=(max+min)/2;
    if(max!==min){const d=max-min;s=l>0.5?d/(2-max-min):d/(max+min);switch(max){case r:h=(g-b)/d+(g<b?6:0);break;case g:h=(b-r)/d+2;break;case b:h=(r-g)/d+4;}h*=60;}
    return {h,s,l};
  }

  function hasVisibleFill(c) { return parseRgb(c).a>0.05; }

  function isApprovedColorFamily(color) {
    const c=parseRgb(color);
    if(c.a<=0.05) return true;
    if(c.a<0)     return true;
    const hsl=rgbToHsl(c);
    return (hsl.h>=100&&hsl.h<=175&&hsl.s>=0.18)||(hsl.s<=0.18)||(hsl.l>=0.85&&hsl.s<=0.2);
  }

  function isVisible(el) {
    if(!el||el.nodeType!==1) return false;
    const st=getComputedStyle(el);
    if(st.display==="none"||st.visibility==="hidden"||+st.opacity===0) return false;
    const r=el.getBoundingClientRect();
    return r.width>0&&r.height>0;
  }

  function isHiddenFromUsers(el) {
    if(!el) return true;
    const st=getComputedStyle(el),r=el.getBoundingClientRect();
    return st.display==="none"||st.visibility==="hidden"||+st.opacity===0||(r.width<=1&&r.height<=1&&/absolute|fixed/.test(st.position)&&cssNum(st.left)<-100);
  }

  function getDomPath(el) {
    const parts=[];let node=el;
    while(node&&node.nodeType===1&&node!==document.documentElement){
      let part=node.localName;
      if(node.id){parts.unshift(`#${cssEscape(node.id)}`);break;}
      const parent=node.parentElement;
      if(parent){const same=Array.from(parent.children).filter(c=>c.localName===node.localName);if(same.length>1)part+=`:nth-of-type(${same.indexOf(node)+1})`;}
      parts.unshift(part);node=parent;
    }
    return parts.join(" > ");
  }

  function getSelector(el) { if(el.id)return`#${cssEscape(el.id)}`;return getDomPath(el)||el.localName||"element"; }

  function elDesc(el) {
    const tag=el.localName||"element",id=el.id?`#${el.id}`:"";
    const cls=el.className&&typeof el.className==="string"?"."+el.className.trim().split(/\s+/).slice(0,2).join("."):"";
    const lbl=el.getAttribute("aria-label")||el.getAttribute("name")||el.getAttribute("id")||"";
    return `<${tag}${id}${cls}>${lbl?` "${cleanText(lbl,30)}"`:""}`;
  }

  let _seq=0;
  function buildIssue({requirement,category,severity,confidence,el,description,evidence,expected,actual,recommendation}) {
    _seq++;
    return {id:`C23-${String(_seq).padStart(3,"0")}`,requirement,category,severity,confidence,selector:getSelector(el),domPath:getDomPath(el),elementLabel:elDesc(el),href:"",description,evidence,expected,actual,recommendation};
  }

  // ── Detect Switch elements ─────────────────────────────────────────────────
  function detectSwitches() {
    const selectors = [
      "input[type='checkbox'][role='switch']",
      "[role='switch']",
      "[data-component*='switch' i]",
      "[data-testid*='switch' i]",
      "[class*='switch' i]:not(label):not(span)",
      "[class*='toggle' i]:not(label):not(span):not(button[class*='toggle-btn'])",
      "button[class*='switch' i]",
      "button[aria-checked]"
    ];
    const seen=new Set(), results=[];
    document.querySelectorAll(selectors.join(",")).forEach(el=>{
      if(seen.has(el)) return;
      seen.add(el);
      // Exclude checkboxes not explicitly marked as switch
      if(el.localName==="input"&&el.type==="checkbox"&&el.getAttribute("role")!=="switch") return;
      // Exclude navigation toggles, menu buttons
      if(/nav|menu|dropdown|collapse/i.test(el.className||"")) return;
      results.push(el);
    });
    return results;
  }

  function isNativeSwitch(el) {
    return el.localName==="input"&&el.type==="checkbox"&&el.getAttribute("role")==="switch";
  }

  // ── CSS state helpers ──────────────────────────────────────────────────────
  function splitSelectors(selectorText) {
    const parts=[];let cur="",depth=0;
    for(const ch of selectorText){if(ch==="("||ch==="[")depth++;if(ch===")"||ch==="]")depth=Math.max(0,depth-1);if(ch===","&&depth===0){parts.push(cur.trim());cur="";}else cur+=ch;}
    if(cur.trim())parts.push(cur.trim());return parts;
  }

  function stripPseudo(sel) { return sel.replace(/::?[a-zA-Z-]+(?:\([^)]*\))?/g,"").replace(/\s+/g," ").trim(); }

  function collectStateEvidence(el) {
    const states={hovered:false,focused:false,disabled:false};
    Array.from(document.styleSheets||[]).forEach(sheet=>{
      let rules;try{rules=sheet.cssRules;}catch(_){return;}
      Array.from(rules||[]).forEach(rule=>{
        if(!rule.selectorText)return;
        splitSelectors(rule.selectorText).forEach(selector=>{
          const lower=selector.toLowerCase(),matches=[];
          if(lower.includes(":hover"))    matches.push("hovered");
          if(lower.includes(":focus"))    matches.push("focused");
          if(lower.includes(":disabled")||lower.includes("[disabled")||lower.includes("[aria-disabled")||lower.includes(".disabled")) matches.push("disabled");
          if(!matches.length)return;
          const base=stripPseudo(selector);if(!base)return;
          try{if(el.matches(base))matches.forEach(s=>{states[s]=true;});}catch(_){}
        });
      });
    });
    if(el.hasAttribute("disabled")||el.getAttribute("aria-disabled")==="true")states.disabled=true;
    return states;
  }

  function findFocusSuppression(el) {
    const found=[];
    Array.from(document.styleSheets||[]).forEach(sheet=>{
      let rules;try{rules=sheet.cssRules;}catch(_){return;}
      const walk=list=>Array.from(list||[]).forEach(rule=>{
        if(rule.cssRules)return walk(rule.cssRules);
        if(!rule.selectorText||!rule.style)return;
        if(!rule.selectorText.toLowerCase().includes(":focus"))return;
        const base=stripPseudo(rule.selectorText);
        try{if(base&&el.matches(base)){const outline=rule.style.getPropertyValue("outline"),outlineW=rule.style.getPropertyValue("outline-width"),shadow=rule.style.getPropertyValue("box-shadow"),hasReplacement=shadow&&shadow!=="none";if((/none/i.test(outline)||outlineW==="0"||/^0/.test(outline))&&!hasReplacement)found.push(rule.selectorText);}}catch(_){}
      });
      walk(rules);
    });
    return found;
  }

  function runtimeFocusCheck(el) {
    if(isHiddenFromUsers(el))return{checked:false,visible:true,reason:"hidden"};
    const prev=document.activeElement,hadTab=el.hasAttribute("tabindex"),oldTab=el.getAttribute("tabindex");
    try{
      if(!hadTab&&["switch","button"].includes(el.getAttribute("role")||el.localName))el.setAttribute("tabindex","0");
      el.focus({preventScroll:true});
      if(document.activeElement!==el)return{checked:false,visible:true,reason:"not focusable"};
      const st=getComputedStyle(el);
      const outlineOk=cssNum(st.outlineWidth)>0&&st.outlineStyle!=="none"&&parseRgb(st.outlineColor).a>0;
      const shadowOk=st.boxShadow&&st.boxShadow!=="none"&&!/^rgba?\(0,0,0,0\)/.test(st.boxShadow);
      return{checked:true,visible:outlineOk||shadowOk,reason:`outline=${st.outlineWidth} ${st.outlineStyle}`};
    }catch(e){return{checked:false,visible:true,reason:e?.message||"focus failed"};}
    finally{if(!hadTab)el.removeAttribute("tabindex");else el.setAttribute("tabindex",oldTab);try{if(prev?.focus)prev.focus({preventScroll:true});}catch(_){}}
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 1 — Base Design Compliance
  // ══════════════════════════════════════════════════════════════════════════
  function auditBaseDesign(el, config, issues) {
    const st=getComputedStyle(el);
    const guard=config?.switch?.baseDesign||{};

    // 1-a: Inline style overrides
    const inline=el.getAttribute("style")||"";
    if(guard.disallowInlineStyleOverrides&&inline&&/background|border|border-radius|width|height|padding|box-shadow/i.test(inline)){
      issues.push(buildIssue({
        requirement:REQ_BASE,category:CAT_BASE,severity:"Medium",confidence:"High",el,
        description:"يوجد تنسيق مباشر (inline style) يعدّل شكل Switch الأساسي المعتمد في كود المنصات.",
        evidence:`style="${cleanText(inline,180)}"`,
        expected:"استخدام مكوّن Switch الرسمي دون تعديل على الشكل أو الأبعاد أو الألوان.",
        actual:"تم العثور على تنسيقات مباشرة تؤثر على التصميم الأساسي.",
        recommendation:"أزل التنسيقات المباشرة واستخدم رموز التصميم الرسمية من كود المنصات."
      }));
    }

    // 1-b: Non-pill shape — border-radius too small for a switch
    if(!isNativeSwitch(el)){
      const radius=Math.min(
        cssNum(st.borderTopLeftRadius),cssNum(st.borderTopRightRadius),
        cssNum(st.borderBottomLeftRadius),cssNum(st.borderBottomRightRadius)
      );
      const minR=guard.minBorderRadiusPx||10;
      const w=el.getBoundingClientRect().width;
      // Only flag if element is wide enough to be a switch track and radius is too small
      if(w>30&&radius<minR){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"High",confidence:"High",el,
          description:"شكل Switch لا يتبع النمط الممدود (pill/oval) المعتمد في كود المنصات — نصف القطر صغير جدًا.",
          evidence:`border-radius: ${radius}px; width: ${Math.round(w)}px`,
          expected:`border-radius ≥ ${minR}px لإعطاء الشكل الممدود المعتمد لـ Switch.`,
          actual:`border-radius: ${radius}px`,
          recommendation:"استخدم border-radius كافيًا لتحقيق الشكل الممدود (pill) المعتمد في كود المنصات."
        }));
      }
    }

    // 1-c: Non-approved background color
    const bg=st.backgroundColor;
    if(guard.disallowCustomBackground&&hasVisibleFill(bg)&&!isApprovedColorFamily(bg)){
      issues.push(buildIssue({
        requirement:REQ_BASE,category:CAT_BASE,severity:"High",confidence:"High",el,
        description:"لون خلفية Switch لا ينتمي إلى عائلة الألوان المعتمدة في كود المنصات.",
        evidence:`background-color: ${bg}`,
        expected:"الخلفية من عائلة الأخضر المعتمد أو المحايد/الرمادي حسب الحالة (On/Off).",
        actual:`background-color: ${bg}`,
        recommendation:"استبدل اللون برمز التصميم المعتمد (var(--color-…))."
      }));
    }

    // 1-d: Thumb (مقبض الزر) must exist inside custom switch
    if(!isNativeSwitch(el)){
      const thumbSignals=el.querySelector("[class*='thumb'],[class*='handle'],[class*='knob'],[class*='circle'],[class*='ball'],[class*='indicator']");
      const hasThumb=thumbSignals!==null||el.querySelector("span,div")!==null;
      if(guard.thumbMustExist&&!hasThumb){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"High",confidence:"Medium",el,
          description:"لم يتم العثور على مقبض (Thumb) داخل Switch — المقبض الدائري ضروري لتحقيق التصميم المعتمد.",
          evidence:"لا توجد عناصر فرعية تشير إلى وجود thumb/handle داخل Switch.",
          expected:"وجود عنصر مقبض دائري (thumb/knob) يتحرك بين On/Off.",
          actual:"Switch يبدو بدون مقبض مرئي.",
          recommendation:"أضف عنصر thumb داخل مكوّن Switch كما هو مُعرَّف في كود المنصات."
        }));
      }
    }

    // 1-e: Width/height ratio — switch should be wider than tall (pill shape)
    if(!isNativeSwitch(el)){
      const rect=el.getBoundingClientRect();
      if(rect.width>0&&rect.height>0&&rect.width<rect.height*1.3&&rect.width>10&&rect.height>10){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"Medium",confidence:"Medium",el,
          description:"نسبة عرض/ارتفاع Switch لا تتناسب مع الشكل الممدود المعتمد — يجب أن يكون العرض أكبر من الارتفاع بشكل واضح.",
          evidence:`width=${Math.round(rect.width)}px; height=${Math.round(rect.height)}px; ratio=${(rect.width/rect.height).toFixed(2)}`,
          expected:"نسبة العرض/الارتفاع ≥ 1.5 لتحقيق الشكل الممدود لـ Switch.",
          actual:`نسبة العرض/الارتفاع = ${(rect.width/rect.height).toFixed(2)}`,
          recommendation:"اضبط أبعاد Switch لتتوافق مع مواصفات كود المنصات."
        }));
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 2 — Interactive States (Default, Hovered, Focused, Disabled)
  // ══════════════════════════════════════════════════════════════════════════
  function auditInteractiveStates(el, config, issues) {
    const states=collectStateEvidence(el);
    const focusSup=findFocusSuppression(el);
    const focusRT=runtimeFocusCheck(el);
    const cfg=config?.switch?.interactiveStates||{};

    // 2-a: Focus not visible
    if(cfg.focusMustBeVisible!==false){
      if(focusSup.length>0||(focusRT.checked&&!focusRT.visible)){
        issues.push(buildIssue({
          requirement:REQ_STATE,category:CAT_STATE,severity:"Critical",confidence:"High",el,
          description:"حالة التركيز (Focused) لـ Switch غير ظاهرة أو تم تعطيل مؤشر التركيز.",
          evidence:focusSup.length?`focus suppression: ${focusSup.slice(0,3).join(" | ")}`:focusRT.reason,
          expected:"عند التركيز يظهر إطار واضح (outline/ring) حول Switch كما هو معتمد في كود المنصات.",
          actual:"لم يظهر مؤشر تركيز واضح أو وُجدت قاعدة CSS تزيله.",
          recommendation:"أعد تفعيل focus outline/ring المعتمد لـ Switch."
        }));
      }
    }

    // 2-b: Disabled still interactive
    if(cfg.disabledMustBeNonInteractive!==false){
      const isDisabledDOM=el.hasAttribute("disabled")||el.getAttribute("aria-disabled")==="true"||/(^|\s)(disabled|is-disabled)(\s|$)/i.test(el.className||"");
      const st=getComputedStyle(el);
      if(isDisabledDOM&&st.pointerEvents!=="none"&&el.tabIndex>=0&&!isNativeSwitch(el)){
        issues.push(buildIssue({
          requirement:REQ_STATE,category:CAT_STATE,severity:"High",confidence:"High",el,
          description:"Switch معلّم كمعطل (Disabled) لكنه ما زال تفاعليًا وقابلًا للتركيز.",
          evidence:`aria-disabled/disabled detected; pointer-events=${st.pointerEvents}; tabIndex=${el.tabIndex}`,
          expected:"Switch المعطل لا يكون قابلًا للنقر أو التركيز.",
          actual:"Switch يبدو معطلًا لكنه ما زال تفاعليًا.",
          recommendation:"أضف pointer-events:none وtabindex=-1 لـ Switch المعطل، أو استخدم disabled attribute."
        }));
      }
    }

    // 2-c: No hover/focus CSS evidence at all (custom switch only)
    if(!isNativeSwitch(el)&&isVisible(el)){
      const hasAny=states.hovered||states.focused||states.disabled;
      if(!hasAny){
        issues.push(buildIssue({
          requirement:REQ_STATE,category:CAT_STATE,severity:"Medium",confidence:"Medium",el,
          description:"لم يتم العثور على قواعد CSS للحالات التفاعلية (Hover, Focus, Disabled) لهذا Switch.",
          evidence:"لا توجد قواعد :hover/:focus/:disabled مطابقة للعنصر في أوراق الأنماط.",
          expected:"حالات Default, Hovered, Focused, Disabled جميعها مُعرَّفة في CSS كما في كود المنصات.",
          actual:"لم يتم العثور على قواعد الحالات التفاعلية.",
          recommendation:"أضف حالات التفاعل المعتمدة من مكوّن Switch في كود المنصات."
        }));
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 3 — Contextual States (On / Off)
  // ══════════════════════════════════════════════════════════════════════════
  function auditContextualStates(el, config, issues) {
    const cfg=config?.switch?.contextualStates||{};

    // Determine current state
    const ariaChecked=el.getAttribute("aria-checked");
    const isOn = el.checked===true||ariaChecked==="true"||el.getAttribute("data-state")==="checked"
      ||el.hasAttribute("data-checked")||/(^|\s)(is-on|switch-on|toggle-on|checked)(\s|$)/i.test(el.className||"");
    const isOff= el.checked===false||ariaChecked==="false"||el.getAttribute("data-state")==="unchecked"
      ||/(^|\s)(is-off|switch-off|toggle-off|unchecked)(\s|$)/i.test(el.className||"");

    // 3-a: role="switch" missing aria-checked
    if(el.getAttribute("role")==="switch"&&ariaChecked===null){
      issues.push(buildIssue({
        requirement:REQ_CTX,category:CAT_CTX,severity:"Critical",confidence:"High",el,
        description:"Switch مخصص يستخدم role='switch' بدون خاصية aria-checked — حالته (On/Off) غير معلنة للتقنيات المساعدة.",
        evidence:`role="switch" aria-checked missing`,
        expected:'aria-checked="true" أو aria-checked="false" يجب أن تكون موجودة وتُحدَّث عند التغيير.',
        actual:"aria-checked غير موجودة.",
        recommendation:'أضف aria-checked="false" كقيمة ابتدائية وحدّثها عند كل تفاعل.'
      }));
    }

    // 3-b: No visual differentiation between On and Off states (CSS check)
    // Look for CSS rules that change background-color based on state
    let hasOnOffCss=false;
    const onOffPatterns=/(checked|aria-checked|data-state|is-on|is-off|switch-on|switch-off|toggle-on|toggle-off)/i;
    Array.from(document.styleSheets||[]).forEach(sheet=>{
      try{Array.from(sheet.cssRules||[]).forEach(rule=>{
        if(rule.selectorText&&onOffPatterns.test(rule.selectorText)&&rule.style?.getPropertyValue("background-color"))hasOnOffCss=true;
      });}catch(_){}
    });

    if(!hasOnOffCss&&!isNativeSwitch(el)&&isVisible(el)){
      issues.push(buildIssue({
        requirement:REQ_CTX,category:CAT_CTX,severity:"High",confidence:"Medium",el,
        description:"لم يتم العثور على قواعد CSS تغيّر لون/مظهر Switch بين حالتي On وOff.",
        evidence:"لا توجد قواعد CSS تستهدف :checked/aria-checked/data-state لتغيير الخلفية.",
        expected:"الخلفية تتغير وضوحًا بين On (لون أخضر معتمد) وOff (رمادي معتمد).",
        actual:"لم يتم العثور على CSS يميّز بين On وOff بصريًا.",
        recommendation:"أضف CSS يغيّر لون خلفية Switch بين On/Off وفق رموز التصميم المعتمدة."
      }));
    }

    // 3-c: On state — visual indicator (color) should be approved green family
    if(isOn){
      const bg=getComputedStyle(el).backgroundColor;
      if(hasVisibleFill(bg)&&!isApprovedColorFamily(bg)){
        issues.push(buildIssue({
          requirement:REQ_CTX,category:CAT_CTX,severity:"Medium",confidence:"High",el,
          description:"لون Switch في حالة On لا ينتمي إلى عائلة الألوان المعتمدة (أخضر العلامة التجارية).",
          evidence:`background-color في حالة On: ${bg}`,
          expected:"حالة On تستخدم لون أخضر العلامة التجارية المعتمد من رموز التصميم.",
          actual:`background-color: ${bg}`,
          recommendation:"استبدل اللون برمز var(--color-primary) أو ما يعادله من رموز التصميم."
        }));
      }
    }

    // 3-d: Off state — thumb position or color should differ from On
    if(isOff&&!isNativeSwitch(el)){
      const bg=getComputedStyle(el).backgroundColor;
      // If bg is an approved green (On color) while element is in Off state — wrong
      if(hasVisibleFill(bg)){
        const c=parseRgb(bg),hsl=rgbToHsl(c);
        const isGreen=hsl.h>=100&&hsl.h<=175&&hsl.s>=0.4&&c.a>0.3;
        if(isGreen){
          issues.push(buildIssue({
            requirement:REQ_CTX,category:CAT_CTX,severity:"High",confidence:"High",el,
            description:"Switch في حالة Off يعرض لون On (أخضر) — الحالة البصرية لا تتطابق مع الحالة المنطقية.",
            evidence:`background-color: ${bg}; aria-checked=${ariaChecked||"null"}`,
            expected:"حالة Off تستخدم لون رمادي/محايد معتمد بينما حالة On تستخدم الأخضر.",
            actual:"Switch يعرض لونًا أخضر في حالة Off.",
            recommendation:"تأكد من ربط aria-checked بصحة بلون CSS الصحيح لكل حالة."
          }));
        }
      }
    }

    // 3-e: Click/keypress should toggle aria-checked (runtime check)
    if(el.getAttribute("role")==="switch"&&ariaChecked!==null){
      // Check if there's an event listener by looking for onclick attribute
      const hasOnclick=el.getAttribute("onclick")||el.getAttribute("data-toggle");
      // We can't fully check event listeners, but we look for click handler signals
      const parentHasToggle=el.closest("[data-toggle],[x-on\\:click],[\\@click],[v-on\\:click]");
      // If role=switch but no visible toggle mechanism found in markup (not definitive)
      // Only report as manual review if no signals at all
      if(!hasOnclick&&!parentHasToggle&&!isNativeSwitch(el)){
        issues.push(buildIssue({
          requirement:REQ_CTX,category:CAT_CTX,severity:"Manual Review",confidence:"Low",el,
          description:"تحقق يدوي مطلوب: تأكد من أن النقر على Switch يغيّر aria-checked بين true/false.",
          evidence:`role="switch" aria-checked="${ariaChecked}"`,
          expected:"كل نقرة تبدّل aria-checked وتحدّث المظهر البصري بين On/Off.",
          actual:"لم يتم التحقق آليًا من وجود معالج حدث للتبديل.",
          recommendation:"تأكد من ربط حدث click/keypress بتحديث aria-checked وفق الحالة الجديدة."
        }));
      }
    }
  }

  // ── Summary ────────────────────────────────────────────────────────────────
  function buildSummary(switches, allIssues) {
    const affected=new Set(allIssues.map(i=>i.selector||i.domPath));
    return {
      totalSwitches:        switches.length,
      nativeSwitches:       switches.filter(isNativeSwitch).length,
      customSwitches:       switches.filter(el=>!isNativeSwitch(el)).length,
      switchesWithIssues:   affected.size,
      issuesCount:          allIssues.length,
      baseDesignMismatch:   allIssues.filter(i=>i.category===CAT_BASE).length,
      interactiveStateIssue:allIssues.filter(i=>i.category===CAT_STATE).length,
      contextualStateIssue: allIssues.filter(i=>i.category===CAT_CTX).length,
      bySeverity:{Critical:allIssues.filter(i=>i.severity==="Critical").length,High:allIssues.filter(i=>i.severity==="High").length,Medium:allIssues.filter(i=>i.severity==="Medium").length,Low:allIssues.filter(i=>i.severity==="Low").length,"Manual Review":allIssues.filter(i=>i.severity==="Manual Review").length}
    };
  }

  function computeScore(issues,config) {
    const w={Critical:34,High:20,Medium:10,Low:5,"Manual Review":1,...(config?.scoring||{})};
    return Math.max(0,100-issues.reduce((s,i)=>s+(w[i.severity]||0),0));
  }

  // ── Main ───────────────────────────────────────────────────────────────────
  async function runAudit(config={}) {
    _seq=0;
    const switches=detectSwitches();
    const allIssues=[];
    switches.forEach(el=>{
      if(!isVisible(el))return;
      auditBaseDesign(el,config,allIssues);
      auditInteractiveStates(el,config,allIssues);
      auditContextualStates(el,config,allIssues);
    });
    const score=computeScore(allIssues,config);
    const hasCrit=allIssues.some(i=>i.severity==="Critical");
    const status=score===100?"Passed":(score<70||hasCrit)?"Failed":"Needs Review";
    return {criterion:CRITERION,criterionName:CRITERION_NAME,pageUrl:location.href,pageTitle:document.title,scanDate:nowIso(),score,status,summary:buildSummary(switches,allIssues),issues:allIssues};
  }

  // ── Highlight ──────────────────────────────────────────────────────────────
  function getHState(){if(!window.__pcC23HL)window.__pcC23HL={items:[],timer:null};return window.__pcC23HL;}

  function clearHighlights(){
    const st=getHState();if(st.timer){clearTimeout(st.timer);st.timer=null;}
    st.items.forEach(r=>{if(!r.el||!r.el.style)return;r.el.style.outline=r.outline;r.el.style.outlineOffset=r.outlineOffset;r.el.style.boxShadow=r.boxShadow;r.el.style.scrollMargin=r.scrollMargin;});
    st.items=[];document.querySelectorAll("[data-pc-c23-badge='1']").forEach(n=>n.remove());return true;
  }

  function findEl(selector,domPath){let el=null;if(selector){try{el=document.querySelector(selector);}catch(_){}}if(!el&&domPath){try{el=document.querySelector(domPath);}catch(_){}}return el;}

  function addBadge(el,label,index){
    const rect=el.getBoundingClientRect(),b=document.createElement("div");
    b.setAttribute("data-pc-c23-badge","1");b.textContent=`${index}. ${label||"C23"}`;
    b.style.cssText=["position:absolute",`top:${Math.max(8,rect.top+window.scrollY-26)}px`,`left:${Math.max(8,rect.left+window.scrollX)}px`,"z-index:2147483647","background:#b91c1c","color:#fff","font:600 10px system-ui,sans-serif","padding:2px 7px","border-radius:999px","box-shadow:0 2px 8px rgba(0,0,0,.3)","pointer-events:none"].join(";");
    document.documentElement.appendChild(b);
  }

  function highlightIssues(items,label){
    clearHighlights();const st=getHState(),seen=new Set(),els=[];
    (items||[]).forEach(item=>{const el=findEl(item.selector,item.domPath);if(!el||seen.has(el))return;seen.add(el);els.push({el,label:item.category||label||"C23"});});
    els.forEach((item,i)=>{const el=item.el;st.items.push({el,outline:el.style.outline,outlineOffset:el.style.outlineOffset,boxShadow:el.style.boxShadow,scrollMargin:el.style.scrollMargin});el.style.outline="3px solid #b91c1c";el.style.outlineOffset="3px";el.style.boxShadow="0 0 0 5px rgba(185,28,28,0.18)";el.style.scrollMargin="96px";addBadge(el,item.label,i+1);});
    if(els[0])els[0].el.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"});
    st.timer=window.setTimeout(()=>clearHighlights(),9000);return els.length;
  }

  function highlightIssue(selector,domPath,label){return highlightIssues([{selector,domPath,category:label}],label)>0;}

  window.PlatformsCodeSwitchAudit={runAudit,highlightIssue,highlightIssues,clearHighlights};
})();
