chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!chrome.sidePanel || !tab?.windowId) return;
  await chrome.sidePanel.open({ windowId: tab.windowId, tabId: tab.id }).catch(() => {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {});
  });
});

chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
  chrome.storage.session.set({ activeTabId: tabId, activeWindowId: windowId }).catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.active) {
    chrome.storage.session.set({ activeTabId: tabId, activeWindowId: tab.windowId }).catch(() => {});
  }
});
