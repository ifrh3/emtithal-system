// Emtithal website API bridge for Supabase RPC calls.
const EMTITHAL_API_DEFAULTS = {
  supabaseUrl: "https://wsexgnphxcuceyqquhzv.supabase.co",
  supabaseAnonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzZXhnbnBoeGN1Y2V5cXF1aHp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyMTU3NTMsImV4cCI6MjA5NDc5MTc1M30.0u9VgV4sPMs-PSdsBkc0cgW4yc-9wTXQkbbaKmfJ3QA",
  apiKey: "emt_live_sk_33dwmw6uwpyny7pc41pje833",
  websiteUrl: "https://emtithal-system.vercel.app/home/emtithal_public_home.html"
};
const EMTITHAL_EXTENSION_REPORT_NAME = "المعيار 20 - رفع الملفات";

function normaliseSupabaseUrl(url) {
  return String(url || "").trim().replace(/\/+$/, "");
}

function getReportPageUrl(report) {
  const value = String(report?.pageUrl || "").trim();
  return value && value !== "—" ? value : "";
}

function getHostFromUrl(url) {
  try {
    return new URL(url).hostname.replace(/^www\./i, "");
  } catch (_) {
    return "";
  }
}

function isSaudiWebsiteUrl(url) {
  const host = getHostFromUrl(url);
  return Boolean(host && /\.sa$/i.test(host));
}

function assertApiSettings() {
  const supabaseUrl = normaliseSupabaseUrl(EMTITHAL_API_DEFAULTS.supabaseUrl);
  const supabaseAnonKey = String(EMTITHAL_API_DEFAULTS.supabaseAnonKey || "").trim();
  const apiKey = String(EMTITHAL_API_DEFAULTS.apiKey || "").trim();

  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error("إعدادات Supabase الرسمية غير مكتملة داخل نسخة الإضافة.");
  }

  if (!apiKey) {
    throw new Error("مفتاح الربط الرسمي غير مدمج في نسخة الإضافة. أضيفيه في src/api-client.js قبل التوزيع.");
  }

  return { supabaseUrl, supabaseAnonKey, apiKey };
}

async function callEmtithalRpc(settings, functionName, payload) {
  const { supabaseUrl, supabaseAnonKey } = assertApiSettings(settings);
  const response = await fetch(`${supabaseUrl}/rest/v1/rpc/${functionName}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json",
      "apikey": supabaseAnonKey,
      "Authorization": `Bearer ${supabaseAnonKey}`
    },
    body: JSON.stringify(payload)
  });

  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (_) {
      data = { message: text };
    }
  }

  if (!response.ok) {
    const rawMessage = data?.message || data?.error_description || data?.hint || "";
    const message = /schema cache|submit_audit_report|submit_complaint|validate_api_key/i.test(rawMessage)
      ? "دوال ربط الإضافة غير مكتملة في Supabase. شغلي ملف fix_validate_api_key_rpc.sql في SQL Editor ثم أعيدي المحاولة."
      : rawMessage || `تعذر الاتصال بـ ${functionName}.`;
    throw new Error(message);
  }

  return data || {};
}

function buildComplaintPayload(settings, report, note, scanState) {
  const { apiKey } = assertApiSettings(settings);
  const data = buildStandardDataFromReport(report || createEmptyCriterion20Report());
  const pageUrl = getReportPageUrl(report) || data.pageUrl || "";
  const host = getHostFromUrl(pageUrl);
  const issueCount = data.summary?.issuesCount ?? report?.issues?.length ?? 0;
  const firstIssues = (report?.issues || [])
    .slice(0, 3)
    .map((issue, index) => `${index + 1}. ${issue.description || issue.actual || issue.category || "مشكلة غير محددة"}`);

  const noteParts = [
    String(note || "").trim(),
    `نتيجة الفحص: ${scanState === "before" ? "لم يبدأ الفحص" : `${data.score}% - ${data.status}`}`,
    `عدد المشاكل: ${issueCount}`,
    ...firstIssues
  ].filter(Boolean);

  return {
    p_api_key: apiKey,
    p_entity: host || report?.pageTitle || "Unknown website",
    p_category: data.category || "عناصر",
    p_standard: `المعيار ${data.number} - ${data.title}`,
    p_url: pageUrl,
    p_extension: EMTITHAL_EXTENSION_REPORT_NAME,
    p_violation: noteParts.join("\n")
  };
}

function buildAuditReportPayload(settings, report) {
  const { apiKey } = assertApiSettings(settings);
  const safeReport = report || createEmptyCriterion20Report();
  const data = buildStandardDataFromReport(safeReport);
  const pageUrl = getReportPageUrl(safeReport) || data.pageUrl || "";

  return {
    p_api_key: apiKey,
    p_platform_url: pageUrl || getHostFromUrl(pageUrl) || "unknown",
    p_report_data: {
      ...safeReport,
      extensionName: EMTITHAL_EXTENSION_REPORT_NAME,
      extensionDisplayName: EMTITHAL_EXTENSION_REPORT_NAME,
      extensionBrand: settings?.extName || "إمتثال",
      extensionKind: "criterion-20-fileupload",
      criterionNumber: "20",
      criterionTitle: data.title,
      submittedAt: new Date().toISOString(),
      score: data.score,
      status: data.status,
      pageUrl
    },
    p_score: Number(data.score) || 0
  };
}

function buildValidateApiKeyPayload(settings) {
  const { apiKey } = assertApiSettings(settings);
  return { p_api_key: apiKey };
}

async function validateEmtithalApiKey(settings) {
  const result = await callEmtithalRpc(settings, "validate_api_key", buildValidateApiKeyPayload(settings));
  if (result?.active === false) {
    throw new Error(result?.message || "تم إيقاف مفتاح الربط من منصة امتثال.");
  }
  return result;
}

async function submitComplaintToEmtithal(settings, report, note, scanState) {
  return callEmtithalRpc(settings, "submit_complaint", buildComplaintPayload(settings, report, note, scanState));
}

async function submitAuditReportToEmtithal(settings, report) {
  return callEmtithalRpc(settings, "submit_audit_report", buildAuditReportPayload(settings, report));
}

window.EMTITHAL_API_DEFAULTS = EMTITHAL_API_DEFAULTS;
window.isSaudiWebsiteUrl = isSaudiWebsiteUrl;
window.validateEmtithalApiKey = validateEmtithalApiKey;
window.submitComplaintToEmtithal = submitComplaintToEmtithal;
window.submitAuditReportToEmtithal = submitAuditReportToEmtithal;
