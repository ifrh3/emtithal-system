// fileupload-audit.js — Criterion 20: File Upload Design System Compliance
(function () {
  "use strict";

  const CRITERION      = "20";
  const CRITERION_NAME = "Ensure File Upload follows the Platforms Code Design System";

  const CAT_BASE  = "Base Design Mismatch";
  const CAT_STATE = "Interactive State Issue";
  const CAT_CTX   = "Contextual State Issue";
  const CAT_ITEM  = "File Item Display Issue";
  const CAT_ERR   = "Error Message Issue";

  const REQ_BASE  = "Base Design Compliance";
  const REQ_STATE = "Interactive States Compliance";
  const REQ_CTX   = "Contextual States Compliance";
  const REQ_ITEM  = "File Name and Status Display";
  const REQ_ERR   = "Error Messages Compliance";

  // ── Utilities ──────────────────────────────────────────────────────────────
  function nowIso() { return new Date().toISOString(); }
  function cleanText(v,max=120){ return String(v||"").replace(/\s+/g," ").trim().slice(0,max); }
  function cssEscape(v){ if(window.CSS&&CSS.escape) return CSS.escape(v); return String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&"); }
  function cssNum(v){ const n=parseFloat(String(v||"").replace("px","")); return isFinite(n)?n:0; }

  function parseRgb(color){
    const s=String(color||"").trim().toLowerCase();
    if(!s||s==="transparent"||s==="rgba(0, 0, 0, 0)") return {r:0,g:0,b:0,a:0};
    const m=s.match(/^rgba?\(([^)]+)\)$/);
    if(m){const p=m[1].split(/[,/ ]+/).map(parseFloat).filter(isFinite);return{r:p[0]||0,g:p[1]||0,b:p[2]||0,a:p.length>3?p[3]:1};}
    const h=s.match(/^#([0-9a-f]{3,8})$/i);
    if(h){let v=h[1];if(v.length===3||v.length===4)v=v.split("").map(c=>c+c).join("");return{r:parseInt(v.slice(0,2),16),g:parseInt(v.slice(2,4),16),b:parseInt(v.slice(4,6),16),a:v.length>=8?parseInt(v.slice(6,8),16)/255:1};}
    return {r:0,g:0,b:0,a:-1};
  }
  function rgbToHsl(c){
    const r=c.r/255,g=c.g/255,b=c.b/255,max=Math.max(r,g,b),min=Math.min(r,g,b);
    let h=0,s=0;const l=(max+min)/2;
    if(max!==min){const d=max-min;s=l>0.5?d/(2-max-min):d/(max+min);switch(max){case r:h=(g-b)/d+(g<b?6:0);break;case g:h=(b-r)/d+2;break;case b:h=(r-g)/d+4;}h*=60;}
    return {h,s,l};
  }
  function isApprovedColor(color){
    const c=parseRgb(color);if(c.a<=0.05||c.a<0)return true;
    const hsl=rgbToHsl(c);
    return (hsl.h>=100&&hsl.h<=175&&hsl.s>=0.15)||(hsl.s<=0.2)||(hsl.l>=0.82&&hsl.s<=0.25);
  }
  function hasVisibleColor(c){return parseRgb(c).a>0.05;}

  function isVisible(el){
    if(!el||el.nodeType!==1)return false;
    const st=getComputedStyle(el);
    if(st.display==="none"||st.visibility==="hidden"||+st.opacity===0)return false;
    const r=el.getBoundingClientRect();return r.width>0&&r.height>0;
  }
  function getDomPath(el){
    const parts=[];let node=el;
    while(node&&node.nodeType===1&&node!==document.documentElement){
      let part=node.localName;
      if(node.id){parts.unshift(`#${cssEscape(node.id)}`);break;}
      const parent=node.parentElement;
      if(parent){const same=Array.from(parent.children).filter(c=>c.localName===node.localName);if(same.length>1)part+=`:nth-of-type(${same.indexOf(node)+1})`;}
      parts.unshift(part);node=parent;
    }
    return parts.join(" > ");
  }
  function getSelector(el){if(el.id)return`#${cssEscape(el.id)}`;return getDomPath(el)||el.localName||"element";}
  function elDesc(el){
    const tag=el.localName||"el",id=el.id?`#${el.id}`:"";
    const cls=el.className&&typeof el.className==="string"?"."+el.className.trim().split(/\s+/).slice(0,2).join("."):"";
    const txt=cleanText(el.textContent||"",30);
    return `<${tag}${id}${cls}>${txt?` "${txt}"`:""}`;
  }

  let _seq=0;
  function buildIssue({requirement,category,severity,confidence,el,description,evidence,expected,actual,recommendation}){
    _seq++;
    return {id:`C20-${String(_seq).padStart(3,"0")}`,requirement,category,severity,confidence,selector:getSelector(el),domPath:getDomPath(el),elementLabel:elDesc(el),href:"",description,evidence,expected,actual,recommendation};
  }

  // ── Detect File Upload components ─────────────────────────────────────────
  function detectFileUploads(){
    const selectors=[
      "input[type='file']",
      "[data-component*='file-upload' i]","[data-component*='dropzone' i]","[data-component*='drop-zone' i]",
      "[data-testid*='file-upload' i]","[data-testid*='dropzone' i]","[data-testid*='drop-zone' i]",
      "[class*='dropzone' i]","[class*='drop-zone' i]","[class*='file-upload' i]","[class*='file-input' i]",
      "[class*='upload-area' i]","[class*='drag-drop' i]","[class*='drag-area' i]"
    ];
    const seen=new Set(),results=[];
    document.querySelectorAll(selectors.join(",")).forEach(el=>{
      if(seen.has(el))return;
      seen.add(el);
      // For hidden file inputs, get parent wrapper if it's a styled dropzone
      if(el.localName==="input"&&el.type==="file"){
        const parent=el.closest("[class*='dropzone' i],[class*='drop-zone' i],[class*='upload' i],[class*='file-input' i]");
        if(parent&&!seen.has(parent)){seen.add(parent);results.push(parent);}
        else results.push(el);
      } else {
        results.push(el);
      }
    });
    return results;
  }

  function getDropZone(el){
    // If el is a file input, find its container
    if(el.localName==="input"&&el.type==="file"){
      return el.closest("[class*='dropzone' i],[class*='drop-zone' i],[class*='upload' i]")||el.parentElement;
    }
    return el;
  }

  function findFileInput(el){
    if(el.localName==="input"&&el.type==="file")return el;
    return el.querySelector("input[type='file']");
  }

  // ── CSS state helpers ──────────────────────────────────────────────────────
  function splitSelectors(selectorText){
    const parts=[];let cur="",depth=0;
    for(const ch of selectorText){if(ch==="("||ch==="[")depth++;if(ch===")"||ch==="]")depth=Math.max(0,depth-1);if(ch===","&&depth===0){parts.push(cur.trim());cur="";}else cur+=ch;}
    if(cur.trim())parts.push(cur.trim());return parts;
  }
  function stripPseudo(sel){return sel.replace(/::?[a-zA-Z-]+(?:\([^)]*\))?/g,"").replace(/\s+/g," ").trim();}

  function hasCssForState(el,stateKeywords){
    let found=false;
    Array.from(document.styleSheets||[]).forEach(sheet=>{
      try{Array.from(sheet.cssRules||[]).forEach(rule=>{
        if(!rule.selectorText)return;
        splitSelectors(rule.selectorText).forEach(selector=>{
          if(!stateKeywords.some(kw=>selector.toLowerCase().includes(kw)))return;
          const base=stripPseudo(selector);
          try{if(base&&el.matches(base))found=true;}catch(_){}
        });
      });}catch(_){}
    });
    return found;
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 1 — Base Design Compliance
  // Drop zone shape, icon, title, helper text, browse button
  // ══════════════════════════════════════════════════════════════════════════
  function auditBaseDesign(el,config,issues){
    const guard=config?.fileUpload?.baseDesign||{};
    const zone=getDropZone(el);
    const st=getComputedStyle(zone);

    // 1-a: Inline style overrides
    const inline=zone.getAttribute("style")||"";
    if(guard.disallowInlineStyleOverrides&&inline&&/border|background|color|padding|width|height/i.test(inline)){
      issues.push(buildIssue({
        requirement:REQ_BASE,category:CAT_BASE,severity:"Medium",confidence:"High",el:zone,
        description:"منطقة رفع الملفات تحتوي على تنسيقات مباشرة (inline style) قد تعدل التصميم الأساسي المعتمد في كود المنصات.",
        evidence:`style="${cleanText(inline,180)}"`,
        expected:"استخدام مكوّن File Upload الرسمي بدون تعديلات مباشرة.",
        actual:"تم العثور على inline style.",
        recommendation:"أزل التنسيقات المباشرة واستخدم مكوّن File Upload الرسمي من كود المنصات."
      }));
    }

    // 1-b: Drop zone must have dashed/dotted border
    if(guard.dropZoneMustHaveBorder){
      const borderStyle=st.borderStyle||st.borderTopStyle;
      const borderWidth=cssNum(st.borderWidth||st.borderTopWidth);
      const hasDashedBorder=["dashed","dotted"].includes(borderStyle)&&borderWidth>0;
      // Also accept if there's a CSS outline or box-shadow
      const hasOutlineAlt=st.outline&&st.outline!=="none"&&st.outline!=="0px none";
      if(!hasDashedBorder&&!hasOutlineAlt){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"High",confidence:"Medium",el:zone,
          description:"منطقة السحب والإفلات (Drop Zone) تفتقر إلى الحدود المتقطعة (dashed/dotted) المعتمدة في كود المنصات.",
          evidence:`border-style: ${borderStyle||"none"}; border-width: ${borderWidth}px`,
          expected:"Drop Zone يجب أن تكون له حدود متقطعة (dashed) واضحة بلون من عائلة الألوان المعتمدة.",
          actual:`border-style: ${borderStyle||"none"}`,
          recommendation:"أضف border: 1px dashed var(--color-border) للـ Drop Zone وفق تصميم كود المنصات."
        }));
      }
    }

    // 1-c: Non-approved border color
    const borderColor=st.borderColor||st.borderTopColor;
    if(borderColor&&hasVisibleColor(borderColor)&&!isApprovedColor(borderColor)){
      issues.push(buildIssue({
        requirement:REQ_BASE,category:CAT_BASE,severity:"Medium",confidence:"High",el:zone,
        description:"لون حدود منطقة رفع الملفات لا ينتمي إلى عائلة الألوان المعتمدة في كود المنصات.",
        evidence:`border-color: ${borderColor}`,
        expected:"الحدود من عائلة الأخضر المعتمد أو الرمادي المحايد.",
        actual:`border-color: ${borderColor}`,
        recommendation:"استخدم var(--color-border) أو var(--color-primary) من رموز التصميم."
      }));
    }

    // 1-d: Must have icon (SVG/img inside zone)
    if(guard.mustHaveIcon){
      const hasIcon=zone.querySelector("svg,img,[class*='icon' i],[class*='upload-icon' i]")!==null;
      if(!hasIcon){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"Medium",confidence:"Medium",el:zone,
          description:"منطقة رفع الملفات لا تحتوي على أيقونة — التصميم المعتمد يتطلب أيقونة الرفع (document/upload icon).",
          evidence:"لم يتم العثور على svg أو img أو عنصر أيقونة داخل منطقة الرفع.",
          expected:"أيقونة رفع ملف واضحة كما هو معتمد في كود المنصات.",
          actual:"لا توجد أيقونة.",
          recommendation:"أضف أيقونة الرفع الرسمية (SVG) من مكتبة أيقونات كود المنصات."
        }));
      }
    }

    // 1-e: Must have title/heading text
    if(guard.mustHaveTitle){
      const headingEl=zone.querySelector("h1,h2,h3,h4,h5,h6,[class*='title' i],[class*='heading' i],[class*='label' i]");
      const hasTitle=headingEl!==null||(zone.textContent||"").trim().length>10;
      if(!hasTitle){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"Medium",confidence:"Medium",el:zone,
          description:"منطقة رفع الملفات لا تحتوي على عنوان توضيحي — التصميم المعتمد يتطلب عنوانًا مثل 'اسحب وأفلت الملفات هنا'.",
          evidence:"لم يتم العثور على عنوان أو نص توضيحي رئيسي.",
          expected:"عنوان واضح مثل 'اسحب وأفلت الملفات هنا للرفع'.",
          actual:"لا يوجد عنوان.",
          recommendation:"أضف عنوانًا وصفيًا داخل منطقة الرفع وفق نص كود المنصات."
        }));
      }
    }

    // 1-f: Must have browse/تصفح button
    if(guard.mustHaveBrowseButton){
      const btnEl=zone.querySelector("button,[role='button'],[class*='browse' i],[class*='تصفح' i]");
      const hasBrowse=btnEl!==null||/browse|تصفح|اختر/i.test(zone.textContent||"");
      if(!hasBrowse){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"High",confidence:"Medium",el:zone,
          description:"منطقة رفع الملفات لا تحتوي على زر 'تصفح الملفات' — المستخدمون الذين لا يستخدمون السحب والإفلات يحتاجونه.",
          evidence:"لم يتم العثور على زر browse/تصفح داخل منطقة الرفع.",
          expected:"زر 'تصفح الملفات' أو 'Browse Files' كما هو معتمد في كود المنصات.",
          actual:"لا يوجد زر تصفح.",
          recommendation:"أضف زر تصفح الملفات المعتمد من مكوّن File Upload في كود المنصات."
        }));
      }
    }

    // 1-g: Must have helper text (file size limit, accepted types)
    if(guard.mustHaveHelperText){
      const text=zone.textContent||"";
      const hasSizeInfo=/mb|kb|ميجا|كيلو|maximum|الحد|حجم|size/i.test(text);
      const hasTypeInfo=/jpg|png|pdf|jpeg|svg|xlsx|doc|الصيغ|نوع|format|type/i.test(text);
      if(!hasSizeInfo&&!hasTypeInfo){
        issues.push(buildIssue({
          requirement:REQ_BASE,category:CAT_BASE,severity:"Medium",confidence:"Medium",el:zone,
          description:"منطقة رفع الملفات لا توضح حد الحجم أو أنواع الملفات المقبولة — النص المساعد غائب أو غير كافٍ.",
          evidence:`text: "${cleanText(text,80)}"`,
          expected:"نص مساعد يذكر الحد الأقصى للحجم وأنواع الملفات المقبولة (مثل: 2MB، jpg/png/pdf).",
          actual:"لم يتم العثور على معلومات الحجم أو النوع.",
          recommendation:"أضف نصًا مساعدًا يوضح حد الحجم وأنواع الملفات المقبولة وفق تصميم كود المنصات."
        }));
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 2 — Interactive States (Default, Drag+Hover, Disabled)
  // ══════════════════════════════════════════════════════════════════════════
  function auditInteractiveStates(el,config,issues){
    const zone=getDropZone(el);
    const cfg=config?.fileUpload?.interactiveStates||{};
    const fileInput=findFileInput(el);

    // 2-a: Drag+Hover state — CSS must change border/background
    const hasDragCss=hasCssForState(zone,[":hover","dragover","drag-over","drag-hover","dragging","is-over","drop-active","dropover"]);
    if(cfg.dragHoverMustChangeBorder&&!hasDragCss){
      issues.push(buildIssue({
        requirement:REQ_STATE,category:CAT_STATE,severity:"Medium",confidence:"Medium",el:zone,
        description:"لم يتم العثور على CSS لحالة السحب والتمرير (Drag + Hover) — يجب أن تتغير حدود منطقة الرفع عند السحب فوقها.",
        evidence:"لا توجد قواعد CSS لحالات :hover/dragover/drag-over مطابقة للعنصر.",
        expected:"عند السحب فوق المنطقة تتغير حدودها إلى اللون الأخضر المعتمد مع خلفية خفيفة.",
        actual:"لم يتم العثور على CSS للحالة Drag+Hover.",
        recommendation:"أضف CSS لحالة Drag+Hover يغيّر border-color وbackground-color وفق تصميم كود المنصات."
      }));
    }

    // 2-b: Disabled state
    const isDisabled=fileInput?.hasAttribute("disabled")||fileInput?.getAttribute("aria-disabled")==="true"
      ||zone.hasAttribute("disabled")||zone.getAttribute("aria-disabled")==="true"
      ||/(^|\s)(disabled|is-disabled)(\s|$)/i.test(zone.className||"");
    const hasDisabledCss=hasCssForState(zone,[":disabled","[disabled]","aria-disabled","\.disabled","is-disabled"]);

    if(cfg.disabledMustBeNonInteractive&&!hasDisabledCss){
      issues.push(buildIssue({
        requirement:REQ_STATE,category:CAT_STATE,severity:"Medium",confidence:"Medium",el:zone,
        description:"لم يتم العثور على CSS لحالة المعطل (Disabled) — يجب أن يظهر مؤشر التحميل المعطل بمظهر مختلف (شفاف/رمادي).",
        evidence:"لا توجد قواعد CSS لحالة Disabled مطابقة للعنصر.",
        expected:"حالة Disabled تعرض منطقة الرفع بخلفية رمادية وحدود منقطة خفيفة مع cursor: not-allowed.",
        actual:"لم يتم العثور على CSS للحالة Disabled.",
        recommendation:"أضف CSS للحالة Disabled يتضمن opacity أو background-color مختلف وcursor:not-allowed."
      }));
    }

    // 2-c: If currently disabled — check it's non-interactive
    if(isDisabled){
      const st=getComputedStyle(zone);
      const stillClickable=st.pointerEvents!=="none"&&(fileInput&&!fileInput.disabled);
      if(stillClickable){
        issues.push(buildIssue({
          requirement:REQ_STATE,category:CAT_STATE,severity:"High",confidence:"High",el:zone,
          description:"منطقة رفع الملفات معلّمة كمعطلة لكنها ما زالت قابلة للتفاعل.",
          evidence:`aria-disabled/disabled detected; pointer-events=${st.pointerEvents}`,
          expected:"منطقة الرفع المعطلة يجب ألا تقبل أي تفاعل (pointer-events:none).",
          actual:"pointer-events لا تزال تسمح بالتفاعل.",
          recommendation:"أضف pointer-events:none وdisabled attribute لعنصر input عند تعطيل المكوّن."
        }));
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 3 — Contextual States (Uploaded / Not Uploaded)
  // ══════════════════════════════════════════════════════════════════════════
  function auditContextualStates(el,config,issues){
    const zone=getDropZone(el);
    const cfg=config?.fileUpload?.contextualStates||{};

    // Look for file items (uploaded state indicators)
    const fileItemsSelectors=[
      "[class*='file-item' i]","[class*='file-list' i]","[class*='uploaded-file' i]",
      "[class*='attachment' i]","[class*='file-row' i]","[class*='upload-item' i]"
    ];
    const container=zone.closest("form,section,div,[class*='upload-container' i],[class*='file-upload' i]")||zone.parentElement;
    const fileItems=container?container.querySelectorAll(fileItemsSelectors.join(",")):[]; 

    // 3-a: Check if uploaded state shows file name
    if(cfg.uploadedMustShowFileName&&fileItems.length>0){
      fileItems.forEach(item=>{
        const hasFileName=/\.\w{2,4}(\s|$)|اسم الملف/i.test(item.textContent||"");
        const hasNameEl=item.querySelector("[class*='file-name' i],[class*='filename' i],[class*='name' i]");
        if(!hasFileName&&!hasNameEl){
          issues.push(buildIssue({
            requirement:REQ_CTX,category:CAT_CTX,severity:"High",confidence:"Medium",el:item,
            description:"عنصر الملف المرفوع لا يعرض اسم الملف بوضوح — التصميم المعتمد يتطلب عرض الاسم دائمًا.",
            evidence:`item text: "${cleanText(item.textContent||"",80)}"`,
            expected:"عرض اسم الملف مع امتداده بوضوح في عنصر الملف المرفوع.",
            actual:"لم يتم العثور على اسم ملف في عنصر الرفع.",
            recommendation:"أضف عرضًا لاسم الملف في عنصر الملف المرفوع."
          }));
        }
      });
    }

    // 3-b: Uploaded state must show remove/delete option
    if(cfg.uploadedMustShowRemoveOption&&fileItems.length>0){
      fileItems.forEach(item=>{
        const hasRemove=item.querySelector("[class*='remove' i],[class*='delete' i],[class*='close' i],[aria-label*='remove' i],[aria-label*='حذف' i],[aria-label*='إزالة' i]")
          ||/×|✕|✗|remove|delete|حذف|إزالة/i.test(item.innerHTML||"");
        if(!hasRemove){
          issues.push(buildIssue({
            requirement:REQ_CTX,category:CAT_CTX,severity:"High",confidence:"Medium",el:item,
            description:"عنصر الملف المرفوع لا يوفر خيار الإزالة/الحذف — التصميم المعتمد يتطلب زر إزالة واضح.",
            evidence:`item: "${elDesc(item)}"`,
            expected:"زر إزالة (×) أو حذف ظاهر في كل عنصر ملف مرفوع.",
            actual:"لم يتم العثور على خيار الإزالة.",
            recommendation:"أضف زر إزالة لكل عنصر ملف مرفوع مع aria-label='إزالة الملف'."
          }));
        }
      });
    }

    // 3-c: No visual CSS distinction between Uploaded vs Not Uploaded states
    const hasUploadedCss=hasCssForState(zone,["uploaded","has-file","has-files","file-selected","is-uploaded","not-empty"]);
    if(!hasUploadedCss){
      issues.push(buildIssue({
        requirement:REQ_CTX,category:CAT_CTX,severity:"Low",confidence:"Low",el:zone,
        description:"لم يتم العثور على CSS يميّز بين حالة 'تم الرفع' و'لم يتم الرفع' — قد يكون المظهر متطابقًا في الحالتين.",
        evidence:"لا توجد قواعد CSS لحالات .uploaded/.has-file/.file-selected في أوراق الأنماط.",
        expected:"مظهر مختلف لمنطقة الرفع بعد اختيار ملف (حالة Uploaded).",
        actual:"لم يتم العثور على CSS للحالتين.",
        recommendation:"أضف class للحالة Uploaded يغيّر مظهر المنطقة أو أخفيها وأظهر قائمة الملفات."
      }));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 4 — File Name, Status, and Remove Option
  // عرض اسم الملف وحالته (Uploading/Completed/Failed) وخيار الإزالة
  // ══════════════════════════════════════════════════════════════════════════
  function auditFileItemDisplay(el,config,issues){
    const cfg=config?.fileUpload?.fileItem||{};
    const container=el.closest("form,section,[class*='upload-container' i],[class*='file-upload' i]")||el.parentElement;
    if(!container) return;

    const fileItemsSelectors=[
      "[class*='file-item' i]","[class*='file-list' i]","[class*='uploaded-file' i]",
      "[class*='attachment' i]","[class*='file-row' i]","[class*='upload-item' i]"
    ];
    const fileItems=Array.from(container.querySelectorAll(fileItemsSelectors.join(",")));
    if(!fileItems.length) return;

    fileItems.forEach(item=>{
      // 4-a: Status indicator (Uploading/Completed/Failed)
      if(cfg.mustShowStatus){
        const statusKeywords=["uploading","completed","failed","جارٍ","مكتمل","فشل","✓","✗","⚠","error","success","loading"];
        const hasStatus=statusKeywords.some(kw=>item.textContent?.toLowerCase().includes(kw.toLowerCase()))
          ||item.querySelector("[class*='status' i],[class*='progress' i],[class*='success' i],[class*='error' i],[class*='fail' i]")!==null;
        if(!hasStatus){
          issues.push(buildIssue({
            requirement:REQ_ITEM,category:CAT_ITEM,severity:"High",confidence:"Medium",el:item,
            description:"عنصر الملف لا يعرض حالة الرفع (جارٍ التحميل / مكتمل / فشل) — المستخدم لا يعرف ما يحدث.",
            evidence:`item text: "${cleanText(item.textContent||"",80)}"`,
            expected:"عرض حالة واضحة: جارٍ التحميل (spinner) / مكتمل (✓ أخضر) / فشل (✗ أحمر).",
            actual:"لم يتم العثور على مؤشر حالة.",
            recommendation:"أضف مؤشر حالة لكل عنصر ملف يعكس حالة الرفع الحالية."
          }));
        }
      }

      // 4-b: Status icon/color (أيقونة حالة الملف المرفوع)
      const statusIcon=item.querySelector("[class*='status-icon' i],[class*='file-status' i],[class*='upload-status' i]");
      const hasColorIndicator=item.querySelector("[style*='color'],[class*='success' i],[class*='error' i],[class*='fail' i],[class*='warning' i]");
      if(!statusIcon&&!hasColorIndicator){
        issues.push(buildIssue({
          requirement:REQ_ITEM,category:CAT_ITEM,severity:"Medium",confidence:"Medium",el:item,
          description:"عنصر الملف يفتقر إلى أيقونة حالة الملف المرفوع (أيقونة نجاح/فشل) كما هو معتمد في كود المنصات.",
          evidence:`item: "${elDesc(item)}"`,
          expected:"أيقونة ✓ خضراء لـ Completed، أيقونة ! حمراء لـ Failed، spinner لـ Uploading.",
          actual:"لم يتم العثور على أيقونة حالة.",
          recommendation:"أضف أيقونة حالة ملونة لكل عنصر ملف مرفوع وفق تصميم كود المنصات."
        }));
      }
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 5 — Error Messages
  // رسائل الخطأ للحجم وNوع الملف وفشل الرفع
  // ══════════════════════════════════════════════════════════════════════════
  function auditErrorMessages(el,config,issues){
    const cfg=config?.fileUpload?.errorMessages||{};
    const container=el.closest("form,section,[class*='upload-container' i],[class*='file-upload' i]")||el.parentElement||document.body;

    // Look for error messages related to this upload
    const errorSelectors=[
      "[class*='error' i]","[class*='alert' i]","[role='alert']","[aria-live='assertive']",
      "[class*='warning' i]","[class*='invalid' i]","[class*='validation' i]"
    ];
    const errorEls=Array.from(container.querySelectorAll(errorSelectors.join(",")));
    const errorText=errorEls.map(e=>e.textContent||"").join(" ");

    // 5-a: Error messages for failed uploads
    const hasFailedUploadEl=container.querySelector("[class*='fail' i],[class*='error' i],[class*='failed' i],[class*='فشل' i]");
    if(hasFailedUploadEl){
      const hasErrorMsg=errorEls.length>0&&errorText.trim().length>5;
      if(!hasErrorMsg){
        issues.push(buildIssue({
          requirement:REQ_ERR,category:CAT_ERR,severity:"High",confidence:"High",el:hasFailedUploadEl,
          description:"يوجد ملف فاشل الرفع لكن لا توجد رسالة خطأ واضحة توضح السبب.",
          evidence:`failed element: "${elDesc(hasFailedUploadEl)}"`,
          expected:"رسالة خطأ واضحة تشرح سبب الفشل ومثال لطريقة المعالجة.",
          actual:"لم يتم العثور على رسالة خطأ.",
          recommendation:"أضف رسالة خطأ تشرح سبب فشل الرفع مع إرشادات للمعالجة."
        }));
      }
    }

    // 5-b: Check if error messages mention file size when relevant
    const hasSizeError=/تجاوز|حجم|size|mb|ميجا|كبير|exceed|too large|limit/i.test(errorText);
    const hasSizeMention=/mb|ميجا|maximum|الحد الأقصى/i.test((container.textContent||"")); 
    if(cfg.mustCoverSizeLimit&&hasSizeMention&&errorEls.length>0&&!hasSizeError){
      // Only flag if there are error elements but no size mention in them
      const hasAnyError=errorEls.some(e=>(e.textContent||"").trim().length>0);
      if(hasAnyError){
        issues.push(buildIssue({
          requirement:REQ_ERR,category:CAT_ERR,severity:"Medium",confidence:"Medium",el:errorEls[0]||el,
          description:"رسائل الخطأ الموجودة لا تذكر تجاوز حد الحجم — يجب أن توضح رسالة الخطأ متى يكون الملف أكبر من المسموح.",
          evidence:`error text: "${cleanText(errorText,100)}"`,
          expected:"رسالة خطأ تذكر الحد الأقصى للحجم مثل: 'حجم الملف تجاوز 2 ميجابايت'.",
          actual:"رسائل الخطأ لا تذكر سبب تجاوز الحجم.",
          recommendation:"أضف رسالة خطأ خاصة بتجاوز الحجم تذكر الحد المسموح به."
        }));
      }
    }

    // 5-c: Error messages for unsupported file types
    const hasTypeError=/نوع|صيغة|format|type|unsupported|غير مدعوم|مسموح/i.test(errorText);
    const hasTypeMention=/jpg|png|pdf|jpeg|الصيغ المدعومة|supported formats/i.test(container.textContent||"");
    if(cfg.mustCoverUnsupportedType&&hasTypeMention&&errorEls.length>0&&!hasTypeError){
      const hasAnyError=errorEls.some(e=>(e.textContent||"").trim().length>0);
      if(hasAnyError){
        issues.push(buildIssue({
          requirement:REQ_ERR,category:CAT_ERR,severity:"Medium",confidence:"Medium",el:errorEls[0]||el,
          description:"رسائل الخطأ لا تذكر نوع الملف غير المدعوم — يجب أن توضح رسالة الخطأ أنواع الملفات المسموحة.",
          evidence:`error text: "${cleanText(errorText,100)}"`,
          expected:"رسالة خطأ واضحة مثل: 'نوع الملف غير مدعوم، يُسمح فقط بـ jpg/png/pdf'.",
          actual:"رسائل الخطأ لا تذكر سبب رفض نوع الملف.",
          recommendation:"أضف رسالة خطأ خاصة بأنواع الملفات غير المدعومة تذكر الأنواع المقبولة."
        }));
      }
    }

    // 5-d: Error messages must be descriptive (not just generic)
    if(errorEls.length>0){
      errorEls.forEach(errEl=>{
        const txt=(errEl.textContent||"").trim();
        if(txt.length>0&&txt.length<8){
          issues.push(buildIssue({
            requirement:REQ_ERR,category:CAT_ERR,severity:"Medium",confidence:"High",el:errEl,
            description:"رسالة الخطأ قصيرة جدًا وغير وصفية — التصميم المعتمد يتطلب رسائل واضحة مع إرشادات للمعالجة.",
            evidence:`error text: "${txt}"`,
            expected:"رسالة خطأ وصفية تشرح السبب وتقدم إرشادات للمعالجة.",
            actual:`رسالة قصيرة: "${txt}"`,
            recommendation:"وسّع رسالة الخطأ لتشرح السبب وتقدم مثالاً على الحل."
          }));
        }
      });
    }
  }

  // ── Summary ────────────────────────────────────────────────────────────────
  function buildSummary(elements,allIssues){
    const affected=new Set(allIssues.map(i=>i.selector||i.domPath));
    return {
      totalFileUploads:     elements.length,
      visibleUploads:       elements.filter(isVisible).length,
      elementsWithIssues:   affected.size,
      issuesCount:          allIssues.length,
      baseDesignMismatch:   allIssues.filter(i=>i.category===CAT_BASE).length,
      interactiveStateIssue:allIssues.filter(i=>i.category===CAT_STATE).length,
      contextualStateIssue: allIssues.filter(i=>i.category===CAT_CTX).length,
      fileItemDisplayIssue: allIssues.filter(i=>i.category===CAT_ITEM).length,
      errorMessageIssue:    allIssues.filter(i=>i.category===CAT_ERR).length,
      bySeverity:{Critical:allIssues.filter(i=>i.severity==="Critical").length,High:allIssues.filter(i=>i.severity==="High").length,Medium:allIssues.filter(i=>i.severity==="Medium").length,Low:allIssues.filter(i=>i.severity==="Low").length,"Manual Review":allIssues.filter(i=>i.severity==="Manual Review").length}
    };
  }

  function computeScore(issues,config){
    const w={Critical:34,High:20,Medium:10,Low:5,"Manual Review":1,...(config?.scoring||{})};
    return Math.max(0,100-issues.reduce((s,i)=>s+(w[i.severity]||0),0));
  }

  // ── Main ───────────────────────────────────────────────────────────────────
  async function runAudit(config={}){
    _seq=0;
    const elements=detectFileUploads();
    const allIssues=[];
    elements.forEach(el=>{
      if(!isVisible(el)&&el.localName!=="input")return;
      auditBaseDesign(el,config,allIssues);
      auditInteractiveStates(el,config,allIssues);
      auditContextualStates(el,config,allIssues);
      auditFileItemDisplay(el,config,allIssues);
      auditErrorMessages(el,config,allIssues);
    });
    const score=computeScore(allIssues,config);
    const hasCrit=allIssues.some(i=>i.severity==="Critical");
    const status=score===100?"Passed":(score<70||hasCrit)?"Failed":"Needs Review";
    return {criterion:CRITERION,criterionName:CRITERION_NAME,pageUrl:location.href,pageTitle:document.title,scanDate:nowIso(),score,status,summary:buildSummary(elements,allIssues),issues:allIssues};
  }

  // ── Highlight ──────────────────────────────────────────────────────────────
  function getHState(){if(!window.__pcC20HL)window.__pcC20HL={items:[],timer:null};return window.__pcC20HL;}
  function clearHighlights(){
    const st=getHState();if(st.timer){clearTimeout(st.timer);st.timer=null;}
    st.items.forEach(r=>{if(!r.el||!r.el.style)return;r.el.style.outline=r.outline;r.el.style.outlineOffset=r.outlineOffset;r.el.style.boxShadow=r.boxShadow;r.el.style.scrollMargin=r.scrollMargin;});
    st.items=[];document.querySelectorAll("[data-pc-c20-badge='1']").forEach(n=>n.remove());return true;
  }
  function findEl(selector,domPath){let el=null;if(selector){try{el=document.querySelector(selector);}catch(_){}}if(!el&&domPath){try{el=document.querySelector(domPath);}catch(_){}}return el;}
  function addBadge(el,label,index){
    const rect=el.getBoundingClientRect(),b=document.createElement("div");
    b.setAttribute("data-pc-c20-badge","1");b.textContent=`${index}. ${label||"C20"}`;
    b.style.cssText=["position:absolute",`top:${Math.max(8,rect.top+window.scrollY-26)}px`,`left:${Math.max(8,rect.left+window.scrollX)}px`,"z-index:2147483647","background:#b91c1c","color:#fff","font:600 10px system-ui,sans-serif","padding:2px 7px","border-radius:999px","box-shadow:0 2px 8px rgba(0,0,0,.3)","pointer-events:none"].join(";");
    document.documentElement.appendChild(b);
  }
  function highlightIssues(items,label){
    clearHighlights();const st=getHState(),seen=new Set(),els=[];
    (items||[]).forEach(item=>{const el=findEl(item.selector,item.domPath);if(!el||seen.has(el))return;seen.add(el);els.push({el,label:item.category||label||"C20"});});
    els.forEach((item,i)=>{const el=item.el;st.items.push({el,outline:el.style.outline,outlineOffset:el.style.outlineOffset,boxShadow:el.style.boxShadow,scrollMargin:el.style.scrollMargin});el.style.outline="3px solid #b91c1c";el.style.outlineOffset="3px";el.style.boxShadow="0 0 0 5px rgba(185,28,28,0.18)";el.style.scrollMargin="96px";addBadge(el,item.label,i+1);});
    if(els[0])els[0].el.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"});
    st.timer=window.setTimeout(()=>clearHighlights(),9000);return els.length;
  }
  function highlightIssue(selector,domPath,label){return highlightIssues([{selector,domPath,category:label}],label)>0;}

  window.PlatformsCodeFileUploadAudit={runAudit,highlightIssue,highlightIssues,clearHighlights};
})();
