// data.js — Criterion 20: File Upload Design System Compliance
const CRITERION_20_NAME    = "Ensure File Upload follows the Platforms Code Design System";
const CRITERION_20_NAME_AR = "التأكد من توافق عنصر رفع الملفات مع مبادئ التصميم الموحد (كود المنصات)";
const CATEGORY_COLORS = {"أساسات":"#E5E500","قوالب":"#E49EDD","عناصر":"#94DCF8","التجربة":"#9DA6F3"};

const EMPTY_SUMMARY = {
  totalFileUploads:0,visibleUploads:0,elementsWithIssues:0,issuesCount:0,
  baseDesignMismatch:0,interactiveStateIssue:0,contextualStateIssue:0,
  fileItemDisplayIssue:0,errorMessageIssue:0,
  bySeverity:{Critical:0,High:0,Medium:0,Low:0,"Manual Review":0}
};

const BASE_SUB_CRITERIA = [
  {
    id:"base-design-compliance",requirement:"Base Design Compliance",category:"Base Design Mismatch",
    title:"مطابقة التصميم الأساسي لمكوّن رفع الملفات",
    description:"التحقق من أن منطقة رفع الملفات تستخدم الحدود المتقطعة، الأيقونة، العنوان، النص المساعد (الحجم/النوع)، وزر تصفح الملفات كما هو معتمد في كود المنصات.",
    howToFix:"استخدم مكوّن File Upload الرسمي من كود المنصات. تأكد من وجود Drop Zone بحدود متقطعة، أيقونة الرفع، عنوان، نص مساعد وزر تصفح.",
    reason:"لم يتم العثور على مخالفات مؤكدة في التصميم الأساسي.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"interactive-states-compliance",requirement:"Interactive States Compliance",category:"Interactive State Issue",
    title:"تطبيق الحالات التفاعلية (Default, Drag+Hover, Disabled)",
    description:"التحقق من تطبيق الحالات التفاعلية الثلاث: الافتراضي (Default)، السحب والتمرير (Drag+Hover) بتغيير الحدود للأخضر، والمعطل (Disabled) بمظهر رمادي غير تفاعلي.",
    howToFix:"أضف CSS للحالات: :hover/dragover لتغيير border-color للأخضر، وحالة Disabled بـ opacity وcursor:not-allowed.",
    reason:"تم العثور على أدلة كافية على الحالات التفاعلية المطلوبة.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"contextual-states-compliance",requirement:"Contextual States Compliance",category:"Contextual State Issue",
    title:"تطبيق الحالات السياقية (Uploaded / Not Uploaded)",
    description:"التحقق من وجود فرق بصري واضح بين حالة 'تم الرفع' (Uploaded) وحالة 'لم يتم الرفع' (Not Uploaded)، مع عرض اسم الملف وزر الإزالة في الحالة المرفوعة.",
    howToFix:"أضف class للحالة Uploaded يغيّر مظهر منطقة الرفع. تأكد من عرض اسم الملف وزر الإزالة في قائمة الملفات.",
    reason:"الحالتان السياقيتان مُطبَّقتان بشكل صحيح.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"file-item-display",requirement:"File Name and Status Display",category:"File Item Display Issue",
    title:"عرض اسم الملف وحالته وخيار الإزالة",
    description:"التحقق من أن كل ملف مرفوع يعرض: اسم الملف بوضوح، حالة الرفع (جارٍ التحميل/مكتمل/فشل) مع أيقونة ملونة، وخيار الإزالة.",
    howToFix:"أضف عرض اسم الملف، أيقونة حالة (✓ أخضر/✗ أحمر/spinner)، وزر إزالة لكل عنصر في قائمة الملفات.",
    reason:"عناصر الملفات تعرض المعلومات المطلوبة بشكل صحيح.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"error-messages-compliance",requirement:"Error Messages Compliance",category:"Error Message Issue",
    title:"رسائل الخطأ الواضحة (حجم، نوع، فشل الرفع)",
    description:"التحقق من وجود رسائل خطأ وصفية واضحة في حالات: فشل الرفع، تجاوز حد الحجم، أو نوع الملف غير المدعوم — مع إرشادات للمعالجة.",
    howToFix:"أضف رسائل خطأ محددة لكل حالة: 'حجم الملف تجاوز 2MB'، 'نوع الملف غير مدعوم، يُسمح بـ jpg/png/pdf'، مع مثال للحل.",
    reason:"لم يتم العثور على مخالفات مؤكدة في رسائل الخطأ.",
    status:"pass",occurrences:0,issues:[]
  }
];

function normaliseIssueForPanel(issue,index){
  return {...issue,n:index+1,target:issue.selector||issue.domPath||`[data-pc-c20-id='${issue.id||index+1}']`,element:issue.elementLabel||issue.selector||"عنصر رفع الملفات",current:issue.actual||issue.evidence||"يتطلب مراجعة",suggested:issue.expected||"مطابقة مكوّن File Upload الرسمي في كود المنصات",location:`${issue.category} · ${issue.selector||issue.domPath||"DOM"}`};
}

function createEmptyCriterion20Report(){
  return {criterion:"20",criterionName:CRITERION_20_NAME,criterionNameAr:CRITERION_20_NAME_AR,pageUrl:"—",pageTitle:"",scanDate:"",score:100,status:"Passed",summary:{...EMPTY_SUMMARY},issues:[]};
}

function buildStandardDataFromReport(report){
  const safeReport=report||createEmptyCriterion20Report();
  const grouped=BASE_SUB_CRITERIA.map(item=>({...item,issues:[]}));
  (safeReport.issues||[]).forEach((issue,idx)=>{
    const pi=normaliseIssueForPanel(issue,idx);
    const target=grouped.find(g=>g.category===issue.category||g.requirement===issue.requirement)||grouped[0];
    target.issues.push(pi);
  });
  grouped.forEach(item=>{
    item.occurrences=item.issues.length;item.status=item.issues.length?"fail":"pass";
    if(item.issues.length) item.reason=`تم العثور على ${item.issues.length} مشكلة تحتاج إلى معالجة ضمن هذا المتطلب.`;
  });
  const passed=grouped.filter(g=>g.status==="pass").length;
  const tScore=Math.round((passed/grouped.length)*100);
  const tStatus=tScore===100?"Passed":tScore===0?"Failed":"Needs Review";
  const summary={...EMPTY_SUMMARY,...(safeReport.summary||{})};
  const scanDate=safeReport.scanDate||"";
  return {
    number:20,category:"عناصر",categoryColor:CATEGORY_COLORS["عناصر"],
    title:"مطابقة عنصر رفع الملفات لنظام كود المنصات",titleEn:CRITERION_20_NAME,
    description:"التأكد من توافق مكوّن رفع الملفات مع كود المنصات — التصميم، الحالات التفاعلية والسياقية، عرض الملفات، ورسائل الخطأ.",
    reference:"https://design.dga.gov.sa/guidelines/components/file-upload",
    pageUrl:safeReport.pageUrl||"—",pageTitle:safeReport.pageTitle||"الصفحة الحالية",
    scanDate,scanDateFormatted:scanDate?new Date(scanDate).toLocaleString("ar-SA"):"—",
    totalElementsScanned:summary.totalFileUploads||0,affectedElements:summary.elementsWithIssues||0,
    score:tScore,severityScore:typeof safeReport.score==="number"?safeReport.score:100,
    status:tStatus,summary,report:safeReport,subCriteria:grouped
  };
}

function getIssueKey(issue){return issue?.id||issue?.target||`issue-${issue?.n}`;}
function getEffectiveSubCriteria(data,ignoredIssues={}){
  return data.subCriteria.map(criterion=>{
    const original=criterion.issues||[],active=original.filter(i=>!ignoredIssues[getIssueKey(i)]);
    const wasPass=criterion.status==="pass",isPass=wasPass||active.length===0;
    return {...criterion,status:isPass?"pass":"fail",issues:active,occurrences:wasPass?criterion.occurrences:active.length,reason:!wasPass&&active.length===0?"تم تجاهل جميع المشاكل لهذا المتطلب.":criterion.reason};
  });
}
function getCurrentCriterion20Report(){return window.CURRENT_C20_REPORT||createEmptyCriterion20Report();}
function setCurrentCriterion20Report(report){window.CURRENT_C20_REPORT=report||createEmptyCriterion20Report();window.STANDARD_DATA=buildStandardDataFromReport(window.CURRENT_C20_REPORT);return window.STANDARD_DATA;}

const STANDARD_DATA=buildStandardDataFromReport(null);
window.CRITERION_20_NAME=CRITERION_20_NAME;window.CRITERION_20_NAME_AR=CRITERION_20_NAME_AR;
window.EMPTY_SUMMARY=EMPTY_SUMMARY;window.STANDARD_DATA=STANDARD_DATA;
window.createEmptyCriterion14Report=createEmptyCriterion20Report;
window.createEmptyCriterion20Report=createEmptyCriterion20Report;
window.buildStandardDataFromReport=buildStandardDataFromReport;
window.getCurrentCriterion14Report=getCurrentCriterion20Report;
window.getCurrentCriterion20Report=getCurrentCriterion20Report;
window.setCurrentCriterion14Report=setCurrentCriterion20Report;
window.setCurrentCriterion20Report=setCurrentCriterion20Report;
window.getIssueKey=getIssueKey;window.getEffectiveSubCriteria=getEffectiveSubCriteria;
