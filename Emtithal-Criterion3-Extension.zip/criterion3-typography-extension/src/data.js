// data.js — Criterion 3: Typography Design System Compliance

const CRITERION_3_NAME    = "Ensure Typography follows the Platforms Code Design System";
const CRITERION_3_NAME_AR = "ضمان أن الخطوط والأوزان تتماشى مع نظام التصميم الموحد (كود المنصات)";

const CATEGORY_COLORS = {
  Foundations: "#E5E500",
  Templates: "#E49EDD",
  Components: "#94DCF8",
  Experience: "#9DA6F3",
  "أساسات": "#E5E500",
  "قوالب": "#E49EDD",
  "عناصر": "#94DCF8",
  "التجربة": "#9DA6F3"
};

const EMPTY_SUMMARY = {
  totalElements: 0,
  elementsWithIssues: 0,
  issuesCount: 0,
  fontFamilyMismatch: 0,
  fontWeightMismatch: 0
};

// ── Sub-criteria matching the 2 typography requirements ────────────────────
const BASE_SUB_CRITERIA = [
  {
    id: "font-family-compliance",
    requirement: "Font Family Compliance",
    category: "Font Family Mismatch",
    title: "نوع الخط المعتمد",
    description: "يتحقق من أن نوع الخط المستخدم في عناصر الصفحة هو خط IBM Plex Sans Arabic المعتمد لكود المنصات أو أحد مسمياته المستعارة المقبولة.",
    howToFix: "قم بتعيين الخط المعتمد 'IBM Plex Sans Arabic' في أنماط CSS لجميع عناصر الصفحة.",
    reason: "لم يتم العثور على خطوط غير معتمدة في الصفحة.",
    status: "pass",
    occurrences: 0,
    issues: []
  },
  {
    id: "font-weight-compliance",
    requirement: "Font Weight Compliance",
    category: "Font Weight Mismatch",
    title: "أوزان الخطوط المعتمدة",
    description: "يتحقق من أن الأوزان المستخدمة للخطوط تقتصر على الأوزان المعتمدة: 400 (Regular)، 500 (Medium)، 600 (SemiBold)، 700 (Bold).",
    howToFix: "اضبط أوزان الخطوط في الأنماط لتكون ضمن الأوزان الأربعة المعتمدة فقط، وتفادى الأوزان المخصصة الأخرى.",
    reason: "جميع أوزان الخطوط المستخدمة صحيحة ومتوافقة.",
    status: "pass",
    occurrences: 0,
    issues: []
  }
];

// ── Normalise raw issue for the panel ─────────────────────────────────────
function normaliseIssueForPanel(issue, index) {
  const requirement = issue.requirement || "Font Family Compliance";
  return {
    ...issue,
    n:         index + 1,
    target:    issue.selector || issue.domPath || `[data-pc-c3-id='${issue.id||index+1}']`,
    element:   issue.linkText ? `نص «${issue.linkText}»` : "عنصر بدون نص مرئي",
    current:   issue.actual   || issue.evidence || "يتطلب مراجعة",
    suggested: issue.expected || "مطابقة الخطوط والأوزان الرسمية في كود المنصات",
    location:  `${issue.category || "Criterion 3"} · ${issue.selector||issue.domPath||"DOM"}`,
    requirement
  };
}

function createEmptyCriterion3Report() {
  return {
    criterion:      "3",
    criterionName:  CRITERION_3_NAME,
    criterionNameAr: CRITERION_3_NAME_AR,
    pageUrl:        "—",
    pageTitle:      "",
    scanDate:       "",
    score:          100,
    status:         "Passed",
    summary:        {...EMPTY_SUMMARY},
    issues:         []
  };
}

function buildStandardDataFromReport(report) {
  const safeReport = report || createEmptyCriterion3Report();
  const grouped    = BASE_SUB_CRITERIA.map(item => ({...item, issues:[]}));

  (safeReport.issues||[]).forEach((issue,idx) => {
    const pi     = normaliseIssueForPanel(issue, idx);
    const target = grouped.find(g => g.category===issue.category || g.requirement===issue.requirement) || grouped[0];
    target.issues.push(pi);
  });

  grouped.forEach(item => {
    item.occurrences = item.issues.length;
    item.status      = item.issues.length ? "fail" : "pass";
    if (item.issues.length) item.reason = `تم العثور على ${item.issues.length} عنصر يحتاج إلى معالجة أو مراجعة ضمن هذا المتطلب.`;
  });

  const summary = {...EMPTY_SUMMARY,...(safeReport.summary||{})};
  const totalElements = summary.totalElements || 0;
  const elementsWithIssues = summary.elementsWithIssues || 0;
  const tScore  = totalElements > 0 ? Math.round(((totalElements - elementsWithIssues) / totalElements) * 100) : 100;
  const tStatus = tScore===100?"Passed":tScore>=70?"Needs Review":"Failed";

  const scanDate = safeReport.scanDate||"";

  return {
    number:             3,
    category:           "أساسات",
    categoryColor:      CATEGORY_COLORS["أساسات"],
    title:              "مطابقة نوع الخط ووزنه لكود المنصات",
    titleEn:            CRITERION_3_NAME,
    description:        "التأكد من أن خطوط الصفحة مطابقة لنوع الخط المعتمد (IBM Plex Sans Arabic) وضمن أوزان الخطوط المسموح بها في كود المنصات.",
    reference:          "Figma: Foundations - Platforms Code (Community).fig / design-system-config.json",
    pageUrl:            safeReport.pageUrl||"—",
    pageTitle:          safeReport.pageTitle||"الصفحة الحالية",
    scanDate,
    scanDateFormatted:  scanDate ? new Date(scanDate).toLocaleString("ar-SA") : "—",
    totalElementsScanned: totalElements,
    affectedElements:   elementsWithIssues,
    score:              tScore,
    severityScore:      typeof safeReport.score==="number"?safeReport.score:100,
    status:             tStatus,
    summary,
    report:             safeReport,
    subCriteria:        grouped
  };
}

function getIssueKey(issue) {
  return issue?.id||issue?.target||`issue-${issue?.n}`;
}

function getEffectiveSubCriteria(data, ignoredIssues={}) {
  return data.subCriteria.map(criterion=>{
    const original  = criterion.issues||[];
    const active    = original.filter(i=>!ignoredIssues[getIssueKey(i)]);
    const wasPass   = criterion.status==="pass";
    const isPass    = wasPass||active.length===0;
    return {
      ...criterion,
      status:      isPass?"pass":"fail",
      issues:      active,
      occurrences: wasPass?criterion.occurrences:active.length,
      reason:      !wasPass&&active.length===0?"تم تجاهل جميع العناصر المخالفة لهذا المتطلب.":criterion.reason
    };
  });
}

function getCurrentCriterion3Report() {
  return window.CURRENT_C3_REPORT || createEmptyCriterion3Report();
}
function setCurrentCriterion3Report(report) {
  window.CURRENT_C3_REPORT = report || createEmptyCriterion3Report();
  window.STANDARD_DATA = buildStandardDataFromReport(window.CURRENT_C3_REPORT);
  return window.STANDARD_DATA;
}

const STANDARD_DATA = buildStandardDataFromReport(null);

// Window properties for extension scripts compatibility
window.CRITERION_3_NAME        = CRITERION_3_NAME;
window.CRITERION_3_NAME_AR     = CRITERION_3_NAME_AR;
window.EMPTY_SUMMARY            = EMPTY_SUMMARY;
window.STANDARD_DATA            = STANDARD_DATA;
window.createEmptyCriterion3Report    = createEmptyCriterion3Report;
window.buildStandardDataFromReport     = buildStandardDataFromReport;
window.getCurrentCriterion3Report     = getCurrentCriterion3Report;
window.setCurrentCriterion3Report     = setCurrentCriterion3Report;
window.getIssueKey                     = getIssueKey;
window.getEffectiveSubCriteria         = getEffectiveSubCriteria;
