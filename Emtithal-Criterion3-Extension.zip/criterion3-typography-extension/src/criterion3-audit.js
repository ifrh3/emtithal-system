(function () {
  const CRITERION = "3";
  const CRITERION_NAME = "Ensure Typography follows the Platforms Code Design System";
  
  const APPROVED_FONT = "ibm plex sans arabic";
  const ALLOWED_WEIGHTS = [400, 500, 600, 700];
  
  const ACCEPTED_ALIASES = [
    "ibm plex sans arabic",
    "ibm-plex-sans-arabic",
    "ibmplexsansarabic",
    "ibm plex",
    "plex",
    "regularfont",
    "boldfont",
    "mediumfont",
    "lightfont",
    "semiboldfont",
    "sdaregular",
    "sda-regular",
    "sda-bold",
    "sda-medium",
    "sda-light",
    "sda",
    "regular",
    "bold",
    "medium",
    "light"
  ];
  
  const ALIAS_WEIGHTS_MAP = {
    regularfont: 400,
    regular: 400,
    lightfont: 300,
    light: 300,
    mediumfont: 500,
    medium: 500,
    semiboldfont: 600,
    boldfont: 700,
    bold: 700,
    "sda-bold": 700,
    "sda-regular": 400,
    "sda-medium": 500,
    ibmplexsansarabic: 400
  };

  function nowIso() { return new Date().toISOString(); }

  function cleanText(value, max = 160) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, max);
  }

  function cssEscape(value) {
    if (window.CSS && typeof CSS.escape === "function") return CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }

  function getDomPath(el) {
    const path = [];
    let node = el;
    while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.documentElement) {
      let part = node.localName;
      if (node.id) {
        part += `#${cssEscape(node.id)}`;
        path.unshift(part);
        break;
      }
      const parent = node.parentElement;
      if (parent) {
        const same = Array.from(parent.children).filter(child => child.localName === node.localName);
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(node) + 1})`;
      }
      path.unshift(part);
      node = parent;
    }
    return path.join(" > ");
  }

  function getSelector(el, index) {
    if (el.id) return `#${cssEscape(el.id)}`;
    const href = el.getAttribute("href");
    if (href) {
      const hrefSelector = `${el.localName}[href='${cssEscape(href)}']`;
      try { if (document.querySelectorAll(hrefSelector).length === 1) return hrefSelector; } catch (_) {}
    }
    return `${getDomPath(el) || el.localName || "element"}`;
  }

  function isElementVisible(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isHiddenFromUsers(el) {
    if (!el) return true;
    const style = getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    const visuallyHidden = rect.width <= 1 && rect.height <= 1 && /absolute|fixed/.test(style.position) && (parseFloat(style.left) < -100 || parseFloat(style.clipPath) > 0 || style.clip !== "auto");
    return style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0 || visuallyHidden;
  }

  const cleanFontName = (fontValue) => {
    if (!fontValue) return "";
    let firstFont = fontValue.split(",")[0];
    let cleaned = firstFont.replace(/["']/g, "");
    return cleaned.toLowerCase().trim();
  };

  const isIBMPlex = (fontName) => {
    if (!fontName) return false;
    if (fontName.includes("ibm plex sans arabic")) return true;
    const normalized = fontName.replace(/\s+/g, "");
    return (
      ACCEPTED_ALIASES.some(alias =>
        normalized.includes(alias.replace(/\s+/g, ""))
      ) || normalized.includes("ibmplex")
    );
  };

  function checkFontFamily(el) {
    const computed = window.getComputedStyle(el);
    let family = computed.getPropertyValue("font-family") || computed.fontFamily || "";

    if (family.includes("var(")) {
      const varName = family.match(/var\(\s*(--[^,)]+)/);
      if (varName && varName[1]) {
        const root = window.getComputedStyle(document.documentElement);
        const varValue = root.getPropertyValue(varName[1]).trim();
        if (varValue) family = varValue;
      }
    }

    const actualFont = cleanFontName(family);
    const ok = isIBMPlex(actualFont);

    return {
      ok,
      actualFont,
      rawFont: family,
      message: ok
        ? `✔ الخط مطابق (${actualFont})`
        : `❌ الخط غير مطابق (${actualFont}) — يجب أن يكون من نوع "${APPROVED_FONT}" أو Alias`
    };
  }

  function checkFontWeight(weight, fontCleaned) {
    const aliasWeight = ALIAS_WEIGHTS_MAP[fontCleaned];
    let evaluatedWeight = weight;
    if (aliasWeight) evaluatedWeight = aliasWeight;

    const ok = ALLOWED_WEIGHTS.includes(evaluatedWeight);
    return {
      ok,
      evaluatedWeight,
      message: ok
        ? "✔ وزن الخط صحيح"
        : `❌ وزن الخط غير مسموح (${weight}) — المسموح: ${ALLOWED_WEIGHTS.join(", ")}`
    };
  }

  function scanElement(el, index) {
    const cs = window.getComputedStyle(el);
    const rawFontFamily = cs.getPropertyValue("font-family") || cs.fontFamily || "";
    const fontFamily = cleanFontName(rawFontFamily);
    const fontSize = parseFloat(cs.getPropertyValue("font-size") || cs.fontSize);
    const fontWeight = parseInt(cs.getPropertyValue("font-weight") || cs.fontWeight);
    const lineHeight = parseFloat(cs.getPropertyValue("line-height") || cs.lineHeight);

    const fontCheck = checkFontFamily(el);
    const weightCheck = checkFontWeight(fontWeight, fontFamily);

    return {
      el,
      index,
      text: el.textContent.trim().substring(0, 90),
      selector: getSelector(el, index),
      domPath: getDomPath(el),
      fontFamily: fontCheck.actualFont,
      rawFontFamily: fontCheck.rawFont,
      fontSize,
      fontWeight: weightCheck.evaluatedWeight,
      rawFontWeight: fontWeight,
      lineHeight,
      checks: {
        font: fontCheck,
        weight: weightCheck
      }
    };
  }

  function scanPage() {
    const elements = document.querySelectorAll(
      "h1,h2,h3,h4,h5,h6,p,span,a,li,td,th,button,label"
    );

    const results = [];
    let idx = 1;
    elements.forEach(el => {
      if (!el.textContent.trim()) return;
      if (!isElementVisible(el) || isHiddenFromUsers(el)) return;

      // Exclude widget tools and accessibility scripts
      if (el.closest(':not(body):not(html)[class*="muneer-"], :not(body):not(html)[id*="muneer-"], [id*="userway"], [class*="accessibe"]')) {
        return;
      }

      results.push(scanElement(el, idx++));
    });
    return results;
  }

  function buildIssue({ id, requirement, category, severity, confidence, element, description, evidence, expected, actual, recommendation }) {
    return {
      id,
      requirement,
      category,
      severity,
      confidence,
      linkText: element.text, // keep key name linkText as standard data template expects it
      selector: element.selector,
      domPath: element.domPath,
      href: "",
      description,
      evidence,
      expected,
      actual,
      recommendation
    };
  }

  async function runAudit(config = {}) {
    const scanned = scanPage();
    const issues = [];

    scanned.forEach(item => {
      if (!item.checks.font.ok) {
        issues.push(buildIssue({
          id: `C3-FONT-${item.index}-FAMILY`,
          requirement: "Font Family Compliance",
          category: "Font Family Mismatch",
          severity: "High",
          confidence: "High",
          element: item,
          description: `العنصر يستخدم خطًا غير معتمد: «${item.fontFamily}». يجب استخدام الخط المعتمد 'IBM Plex Sans Arabic' أو أحد مسمياته المستعارة المعتمدة.`,
          evidence: `font-family: ${item.rawFontFamily}`,
          expected: "ibm plex sans arabic",
          actual: item.fontFamily || "None",
          recommendation: "تغيير قيمة font-family في أنماط العنصر لتطابق خط كود المنصات المعتمد."
        }));
      }
      
      if (item.checks.font.ok && !item.checks.weight.ok) {
        issues.push(buildIssue({
          id: `C3-WEG-${item.index}-WEIGHT`,
          requirement: "Font Weight Compliance",
          category: "Font Weight Mismatch",
          severity: "Medium",
          confidence: "High",
          element: item,
          description: `وزن الخط المستخدم (${item.rawFontWeight}) غير مسموح به في كود المنصات للخط المعتمد.`,
          evidence: `font-weight: ${item.rawFontWeight}; font-family: ${item.fontFamily}`,
          expected: "400, 500, 600, 700",
          actual: String(item.rawFontWeight),
          recommendation: "اضبط وزن الخط (font-weight) للعنصر ليكون من الأوزان الأربعة المسموح بها (400، 500، 600، 700) وأزل أي أوزان أخرى غير معتمدة."
        }));
      }
    });

    const total = scanned.length;
    const affectedSet = new Set(issues.map(iss => iss.selector));
    const elementsWithIssues = affectedSet.size;
    const score = total > 0 ? Math.round(((total - elementsWithIssues) / total) * 100) : 100;

    return {
      criterion: CRITERION,
      criterionName: CRITERION_NAME,
      pageUrl: location.href,
      scanDate: nowIso(),
      score,
      status: score === 100 ? "Passed" : score >= 70 ? "Needs Review" : "Failed",
      summary: {
        totalElements: total,
        elementsWithIssues: elementsWithIssues,
        issuesCount: issues.length,
        fontFamilyMismatch: issues.filter(iss => iss.category === "Font Family Mismatch").length,
        fontWeightMismatch: issues.filter(iss => iss.category === "Font Weight Mismatch").length
      },
      issues
    };
  }

  function getHighlightState() {
    if (!window.__pcC3Highlights) {
      window.__pcC3Highlights = { items: [], timer: null };
    }
    return window.__pcC3Highlights;
  }

  function clearHighlights() {
    const state = getHighlightState();
    if (state.timer) {
      clearTimeout(state.timer);
      state.timer = null;
    }
    state.items.forEach(record => {
      const el = record.el;
      if (!el || !el.style) return;
      el.style.outline = record.outline;
      el.style.outlineOffset = record.outlineOffset;
      el.style.boxShadow = record.boxShadow;
      el.style.scrollMargin = record.scrollMargin;
    });
    state.items = [];
    document.querySelectorAll("[data-pc-c3-highlight-badge='1']").forEach(node => node.remove());
    return true;
  }

  function findElement(selector, domPath) {
    let el = null;
    if (selector) { try { el = document.querySelector(selector); } catch (_) {} }
    if (!el && domPath) { try { el = document.querySelector(domPath); } catch (_) {} }
    return el;
  }

  function addBadge(el, label, index, color = "#b91c1c") {
    const rect = el.getBoundingClientRect();
    const badge = document.createElement("div");
    badge.setAttribute("data-pc-c3-highlight-badge", "1");
    badge.textContent = `${index}. ${label || "معيار 3"}`;
    badge.style.cssText = [
      "position:absolute",
      `top:${Math.max(8, rect.top + window.scrollY - 28)}px`,
      `left:${Math.max(8, rect.left + window.scrollX)}px`,
      "z-index:2147483647",
      `background:${color}`,
      "color:#fff",
      "font:600 11px system-ui,-apple-system,Segoe UI,sans-serif",
      "padding:3px 7px",
      "border-radius:999px",
      "box-shadow:0 4px 16px rgba(0,0,0,.25)",
      "pointer-events:none"
    ].join(";");
    document.documentElement.appendChild(badge);
  }

  function highlightIssues(items, label) {
    clearHighlights();
    const state = getHighlightState();
    const seen = new Set();
    const elements = [];

    (items || []).forEach(item => {
      const el = findElement(item.selector, item.domPath);
      if (!el || seen.has(el)) return;
      seen.add(el);
      
      let badgeLabel = "خطأ في الخط";
      let color = "#b91c1c";
      if (item.category === "Font Weight Mismatch") {
        badgeLabel = "خطأ في الوزن";
        color = "#d97706";
      }
      
      elements.push({ el, label: badgeLabel, color });
    });

    elements.forEach((item, index) => {
      const el = item.el;
      state.items.push({
        el,
        outline: el.style.outline,
        outlineOffset: el.style.outlineOffset,
        boxShadow: el.style.boxShadow,
        scrollMargin: el.style.scrollMargin
      });
      el.style.outline = `3px solid ${item.color}`;
      el.style.outlineOffset = "3px";
      el.style.boxShadow = `0 0 0 5px ${item.color === "#b91c1c" ? "rgba(185, 28, 28, 0.18)" : "rgba(217, 119, 6, 0.18)"}`;
      el.style.scrollMargin = "96px";
      addBadge(el, item.label, index + 1, item.color);
    });

    if (elements[0]) {
      elements[0].el.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    }

    state.timer = window.setTimeout(() => clearHighlights(), 9000);
    return elements.length;
  }

  function highlightIssue(selector, domPath, label) {
    const category = label === "نوع الخط المعتمد" ? "Font Family Mismatch" : "Font Weight Mismatch";
    return highlightIssues([{ selector, domPath, category }], label) > 0;
  }

  window.PlatformsCodeCriterion3 = { runAudit, highlightIssue, highlightIssues, clearHighlights };
})();
