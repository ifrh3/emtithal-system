// Extension App — Criterion 3: Typography Compliance
const { useState, useEffect, useRef, useMemo } = React;

const DEFAULT_SETTINGS = {
  extName: "إمتثال - فحص معيار 3 للخطوط", extGlyph: "خ", extLogo: "assets/images/emttthal-logo.png",
  lang: "ar", theme: "light", notifications: true, autoScroll: true,
  clearOnClose: true, format: "PDF",
  incLink: true, incTime: true, incDetails: true, incElements: true, incRecs: true, incExec: true,
  autoSubmitReports: false
};

// ---------- Issue Report Modal ----------
function IssueReportModal({ onClose, settings, report, scanState }) {
  const [note, setNote] = useState("");
  const [submitState, setSubmitState] = useState("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [receipt, setReceipt] = useState(null);
  const data = buildStandardDataFromReport(report || createEmptyCriterion3Report());
  const statusLabel = data.status === "Passed" ? "امتثال كامل" : data.status === "Failed" ? "غير ممتثل" : "امتثال جزئي";

  const handleSubmit = async () => {
    setErrorMessage("");
    setSubmitState("sending");
    try {
      const result = await window.submitComplaintToEmtithal(settings, report, note, scanState);
      setReceipt(result);
      setSubmitState("sent");
    } catch (error) {
      setErrorMessage(error?.message || "تعذر إرسال البلاغ إلى موقع امتثال.");
      setSubmitState("error");
    }
  };

  if (submitState === "sent") {
    return (
      <div className="modal-backdrop" onClick={onClose}>
        <div className="modal" onClick={e=>e.stopPropagation()} style={{width:420}}>
          <div className="modal-body" style={{textAlign:"center",padding:"32px 24px"}}>
            <div style={{width:48,height:48,borderRadius:"50%",background:"var(--success-soft)",color:"var(--success)",display:"grid",placeItems:"center",margin:"0 auto 12px"}}>{SP_Icon.bigCheck}</div>
            <h3 style={{margin:0,fontSize:16}}>تم إرسال البلاغ</h3>
            <p style={{fontSize:13,color:"var(--text-3)",marginTop:8,lineHeight:1.6}}>
              تم حفظ البلاغ في موقع امتثال بنجاح{receipt?.id ? `، رقم البلاغ: ${receipt.id}` : ""}.
            </p>
          </div>
          <div className="modal-foot"><button className="btn primary" onClick={onClose}>إغلاق</button></div>
        </div>
      </div>
    );
  }
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e=>e.stopPropagation()}>
        <div className="modal-head">
          <h3>إبلاغ عن مشكلة</h3>
          <button className="sp-iconbtn" onClick={onClose}>{SP_Icon.close}</button>
        </div>
        <div className="modal-body">
          <p style={{marginTop:0,fontSize:12,color:"var(--text-3)"}}>
            استخدم هذه النافذة للإبلاغ عن خلل في فحص الخطوط أو نتيجة غير دقيقة. سيتم إرسال البلاغ إلى موقع امتثال عبر مفتاح الربط الرسمي المدمج في نسخة الإضافة.
          </p>
          <div className="field"><label>رابط الصفحة</label><input readOnly value={data.pageUrl||"—"}/></div>
          <div className="field"><label>المعيار</label><input readOnly value={`${data.number} — ${data.title}`}/></div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
            <div className="field"><label>وقت الفحص</label><input readOnly value={data.scanDateFormatted||"—"}/></div>
            <div className="field"><label>نتيجة الفحص</label><input readOnly value={scanState==="before"?"لم يبدأ الفحص":`${data.score}% — ${statusLabel}`}/></div>
          </div>
          <div className="field">
            <label>ملاحظتك <span style={{color:"var(--text-3)",fontWeight:400}}>(اختياري)</span></label>
            <textarea placeholder="مثال: عنصر نصي لم يُكتشف، أو الفحص لم يتعرف على نوع خط بديل..." value={note} onChange={e=>setNote(e.target.value)}/>
          </div>
          {errorMessage && <div className="api-error" role="alert">{errorMessage}</div>}
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={onClose} disabled={submitState === "sending"}>إلغاء</button>
          <button className="btn primary" onClick={handleSubmit} disabled={submitState === "sending"}>
            {submitState === "sending" ? "جار الإرسال..." : "إرسال البلاغ"}
          </button>
        </div>
      </div>
    </div>
  );
}

function ExtensionShell() {
  const [settings,     setSettings]     = useState(DEFAULT_SETTINGS);
  const [view,         setView]         = useState("browser");
  const [scanState,    setScanState]    = useState("before");
  const [scanProgress, setScanProgress] = useState(0);
  const [highlighted,  setHighlighted]  = useState(false);
  const [ignoredIssues,setIgnoredIssues]= useState({});
  const [report,       setReport]       = useState(createEmptyCriterion3Report());
  const [standardData, setStandardData] = useState(buildStandardDataFromReport(null));
  const [toast,        setToast]        = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [showFlag,     setShowFlag]     = useState(false);
  const [reportSubmitState, setReportSubmitState] = useState("idle");
  const toastTimer = useRef(null);

  const flashToast = (msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(()=>setToast(null), 2600);
  };

  useEffect(()=>{
    document.documentElement.setAttribute("data-theme", settings.theme||"light");
  }, [settings.theme]);

  // ── Score calculation ─────────────────────────────────────────────────────
  const applyTemplateCalc = (rawReport) => {
    const data = buildStandardDataFromReport(rawReport);
    const norm = {
      ...rawReport,
      score:            data.score,
      status:           data.status,
      severityScore:    typeof rawReport?.score==="number"?rawReport.score:undefined,
      calculationMethod:"element-pass-ratio",
      calculationNote:  "score = (totalElements - elementsWithIssues) / totalElements * 100"
    };
    return { report:norm, data:buildStandardDataFromReport(norm) };
  };

  const getScanState = (data) => {
    if (!data.summary||data.summary.totalElements===0) return "n/a";
    if (data.score===100) return "full";
    if (data.score===0)   return "none";
    return "partial";
  };

  const updateReport = (nextReport) => {
    const norm = applyTemplateCalc(nextReport);
    setCurrentCriterion3Report(norm.report);
    setReport(norm.report);
    setStandardData(norm.data);
    setIgnoredIssues({});
    if (chrome?.storage?.local) {
      chrome.storage.local.set({criterion3LastReport:norm.report}).catch(()=>{});
    }
    return norm.data;
  };

  const rebuildSummary = (base, active) => {
    const b = base?.summary||{};
    const affected = new Set((active||[]).map(i=>i.selector||i.domPath));
    return {
      ...b,
      elementsWithIssues: affected.size,
      issuesCount:          active.length,
      fontFamilyMismatch:   active.filter(i=>i.category==="Font Family Mismatch").length,
      fontWeightMismatch:   active.filter(i=>i.category==="Font Weight Mismatch").length
    };
  };

  const createEffectiveReport = (baseReport, ignoredMap) => {
    const active   = (baseReport?.issues||[]).filter(i=>!ignoredMap[getIssueKey(i)]);
    const filtered = {...(baseReport||createEmptyCriterion3Report()), issues:active, summary:rebuildSummary(baseReport,active)};
    return applyTemplateCalc(filtered).report;
  };

  const effectiveReport = useMemo(()=>createEffectiveReport(report,ignoredIssues),[report,ignoredIssues]);

  useEffect(()=>{
    if(!chrome?.storage?.local) return;
    chrome.storage.local.get(["criterion3LastReport", "criterion3Settings"]).then(r=>{
      if (r.criterion3Settings) {
        const { apiKey, supabaseUrl, supabaseAnonKey, ...safeSettings } = r.criterion3Settings;
        setSettings(prev => ({ ...prev, ...safeSettings }));
      }
      if(r.criterion3LastReport) updateReport(r.criterion3LastReport);
    }).catch(()=>{});
  },[]);

  useEffect(()=>{
    if(scanState!=="scanning") return;
    setScanProgress(0); let n=0;
    const t=setInterval(()=>{ n++; setScanProgress(Math.min(n,4)); if(n>=4) clearInterval(t); },350);
    return ()=>clearInterval(t);
  }, [scanState]);

  // ── Helpers ───────────────────────────────────────────────────────────────
  const loadConfig = async () => {
    try {
      const res = await fetch(chrome.runtime.getURL("design-system-config.json"));
      if(!res.ok) throw new Error();
      return await res.json();
    } catch(_) {
      return {
        criterion: "3",
        typography: {
          approvedFont: "ibm plex sans arabic",
          allowedWeights: [400, 500, 600, 700]
        }
      };
    }
  };

  const getActiveTab  = async () => { const t=await chrome.tabs.query({active:true,currentWindow:true}); return t&&t[0]; };
  const getTabUrl     = tab => tab?.url||tab?.pendingUrl||"";
  const canScanTab    = tab => { if(!tab||!tab.id) return false; const u=getTabUrl(tab); if(!u) return true; return /^(https?:|file:)/i.test(u); };
  const getUnsupMsg   = tab => {
    const u=getTabUrl(tab);
    if(!tab||!tab.id) return "لم يتم العثور على تبويب نشط.";
    if(/^(chrome:|edge:|about:|devtools:|chrome-extension:)/i.test(u)) return "لا يمكن فحص صفحات المتصفح الداخلية. افتح موقعًا عاديًا http/https ثم أعد الفحص.";
    return "لا يمكن فحص هذه الصفحة. افتح موقعًا http أو https ثم أعد المحاولة.";
  };

  const ensureApiKeyActive = async () => {
    if (!window.validateEmtithalApiKey) {
      throw new Error("تعذر التحقق من حالة مفتاح الربط. أعد تحميل الإضافة بعد تشغيل ملف fix_validate_api_key_rpc.sql.");
    }
    try {
      await window.validateEmtithalApiKey(settings);
    } catch (error) {
      throw new Error(error?.message || "تم إيقاف مفتاح الربط من منصة امتثال.");
    }
  };

  const submitReportToWebsite = async (targetReport = effectiveReport, options = {}) => {
    const silent = Boolean(options.silent);
    setReportSubmitState("sending");
    try {
      await ensureApiKeyActive();
      const result = await window.submitAuditReportToEmtithal(settings, targetReport);
      setReportSubmitState("sent");
      if (!silent) flashToast(result?.message || "تم إرسال التقرير إلى موقع امتثال");
      return result;
    } catch (error) {
      setReportSubmitState("error");
      if (!silent) flashToast(error?.message || "تعذر إرسال التقرير إلى موقع امتثال");
      throw error;
    } finally {
      setTimeout(() => setReportSubmitState("idle"), 2600);
    }
  };

  const openProjectWebsite = async () => {
    const url = window.EMTITHAL_API_DEFAULTS?.websiteUrl || "https://emtithal-system.vercel.app/home/emtithal_public_home.html";
    try {
      if (chrome?.tabs?.create) {
        await chrome.tabs.create({ url });
      } else {
        window.open(url, "_blank", "noopener");
      }
    } catch (_) {
      window.open(url, "_blank", "noopener");
    }
  };

  // ── Scan ──────────────────────────────────────────────────────────────────
  const startScan = async () => {
    setErrorMessage("");
    if (highlighted) { await clearPageHL(); setHighlighted(false); }
    setScanState("scanning");
    try {
      await ensureApiKeyActive();
      const [tab,config] = await Promise.all([getActiveTab(),loadConfig()]);
      if(!canScanTab(tab)) throw new Error(getUnsupMsg(tab));

      await chrome.scripting.executeScript({target:{tabId:tab.id},files:["src/criterion3-audit.js"]});

      const results = await chrome.scripting.executeScript({
        target:{tabId:tab.id},
        func: async(cfg)=>{
          if(!window.PlatformsCodeCriterion3?.runAudit) throw new Error("لم يتم تحميل محرك فحص الخطوط والأوزان.");
          return window.PlatformsCodeCriterion3.runAudit(cfg);
        },
        args:[config]
      });

      const nextReport = results?.[0]?.result;
      if(!nextReport) throw new Error("لم يتم إرجاع نتيجة الفحص من الصفحة.");
      const nextData = updateReport(nextReport);
      setScanState(getScanState(nextData));
      flashToast("تم فحص خطوط الصفحة محليًا بنجاح");
      if (settings.autoSubmitReports && window.EMTITHAL_API_DEFAULTS?.apiKey && window.isSaudiWebsiteUrl?.(nextReport.pageUrl)) {
        submitReportToWebsite(nextReport, { silent: true }).catch(error => console.warn("Auto report submit failed", error?.message || error));
      }
    } catch(error) {
      const raw = error?.message||"تعذر فحص الصفحة الحالية.";
      const friendly = raw.includes("Cannot access contents")||raw.includes("Missing host permission")
        ? "لا يملك الإكستنشن صلاحية قراءة هذه الصفحة. أعد تحميل الإضافة من chrome://extensions."
        : raw.includes("extensions gallery")
          ? "لا يمكن فحص صفحات Chrome Web Store."
          : raw;
      setErrorMessage(friendly); setScanState("error");
      flashToast("تعذر إكمال الفحص");
      console.error("Criterion 3 scan failed", error);
    }
  };

  const cancelScan = ()=>{ setScanState("before"); setScanProgress(0); };

  // ── Highlight ─────────────────────────────────────────────────────────────
  const ensureScript = async tabId => chrome.scripting.executeScript({target:{tabId},files:["src/criterion3-audit.js"]});

  const runHighlight = async (issues, label) => {
    const active=(issues||[]).filter(Boolean);
    if(!active.length){ flashToast("لا توجد مشاكل قابلة للتمييز"); return false; }
    try {
      const tab=await getActiveTab();
      if(!canScanTab(tab)) throw new Error();
      await ensureScript(tab.id);
      const result=await chrome.scripting.executeScript({
        target:{tabId:tab.id},
        func:(items,lbl)=>{
          if(!window.PlatformsCodeCriterion3) return 0;
          return window.PlatformsCodeCriterion3.highlightIssues(
            items.map(i=>({selector:i.selector,domPath:i.domPath,category:i.category,id:i.id})), lbl
          );
        },
        args:[active,label||"Typography"]
      });
      const cnt=result?.[0]?.result||0;
      if(cnt>0){ flashToast(`تم تمييز ${cnt} عنصر في الصفحة`); return true; }
      flashToast("تعذر العثور على العناصر في الصفحة"); return false;
    }catch(_){ flashToast("تعذر تمييز العناصر"); return false; }
  };

  const clearPageHL = async ()=>{
    try{const tab=await getActiveTab();if(!canScanTab(tab))return;await ensureScript(tab.id);await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>window.PlatformsCodeCriterion3?.clearHighlights?.()});}catch(_){}
  };

  const locateIssue = async(target,issue)=>{
    const found=issue||(effectiveReport.issues||[]).find(i=>i.selector===target||i.domPath===target||i.target===target);
    if(!found) return flashToast("لم يتم العثور على العنصر");
    const ok=await runHighlight([found],found.category);
    if(ok) flashToast("تم الانتقال إلى العنصر وتمييزه مؤقتًا");
  };

  const highlightAll = async()=>{
    const active=effectiveReport.issues||[];
    if(!active.length) return flashToast("لا توجد مشاكل");
    if(highlighted){ await clearPageHL(); setHighlighted(false); flashToast("تم إخفاء التمييز"); return; }
    const ok=await runHighlight(active,"مشاكل معيار 3");
    setHighlighted(ok);
  };

  const highlightGroup = async item=>{
    const gi=(item.issues||[]).filter(i=>!ignoredIssues[getIssueKey(i)]);
    const ok=await runHighlight(gi,item.title||item.category);
    setHighlighted(ok||highlighted);
  };

  const ignoreIssue = issue=>{
    setIgnoredIssues(prev=>({...prev,[getIssueKey(issue)]:true}));
    if(highlighted){ clearPageHL(); setHighlighted(false); }
    flashToast("تم تجاهل المشكلة وإخفاؤها من القائمة والحساب");
  };

  const stripSensitiveSettings = (source = {}) => {
    const { apiKey, supabaseUrl, supabaseAnonKey, ...safeSettings } = source;
    return safeSettings;
  };

  const persistSettings = (nextSettings) => {
    if (chrome?.storage?.local) {
      chrome.storage.local.set({ criterion3Settings: stripSensitiveSettings(nextSettings) }).catch(() => {});
    }
  };

  const setSetting = (k,v)=>{
    setSettings(prev => {
      const next = typeof k === "object" ? { ...prev, ...k } : { ...prev, [k]: v };
      persistSettings(next);
      return next;
    });
  };

  // ── Export ────────────────────────────────────────────────────────────────
  const dlBlob=(content,mime,name)=>{
    const b=new Blob([content],{type:mime}),u=URL.createObjectURL(b),a=document.createElement("a");
    a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1200);
  };
  const esc=v=>String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");

  const buildFilename=(fmt,r)=>{
    const stamp=new Date().toISOString().replace(/[:.]/g,"-");
    let host="page"; try{host=new URL(r?.pageUrl||"").hostname||host;}catch(_){}
    return `criterion03-typography-${host.replace(/[^a-zA-Z0-9.-]+/g,"-")}-${stamp}.${fmt.toLowerCase()}`;
  };

  const buildJsonReport=(r)=>{
    const data=buildStandardDataFromReport(r), s=r.summary||{};
    return {
      _schema:"imtithal-typography-audit-v1", _generated:new Date().toISOString(),
      criterion:{ id:"3", nameAr:CRITERION_3_NAME_AR, nameEn:CRITERION_3_NAME, category:"أساسات", categoryColor:"#E5E500" },
      page:{ url:r.pageUrl, title:r.pageTitle||"", scanDate:r.scanDate, scanDateFormatted:data.scanDateFormatted },
      result:{ score:data.score, severityScore:r.severityScore, status:data.status, complianceLabel:data.status==="Passed"?"ممتثل":data.status==="Failed"?"غير ممتثل":"امتثال جزئي" },
      requirements:data.subCriteria.map(req=>({id:req.id,requirement:req.requirement,title:req.title,status:req.status,issueCount:req.issues.length,occurrences:req.occurrences})),
      summary:{ totalElements:s.totalElements||0, elementsWithIssues:s.elementsWithIssues||0, issuesCount:s.issuesCount||0, fontFamilyMismatch:s.fontFamilyMismatch||0, fontWeightMismatch:s.fontWeightMismatch||0 },
      issues:(r.issues||[]).map(i=>({id:i.id,requirement:i.requirement,category:i.category,severity:i.severity,confidence:i.confidence,selector:i.selector,domPath:i.domPath,elementLabel:i.linkText,description:i.description,evidence:i.evidence,expected:i.expected,actual:i.actual,recommendation:i.recommendation}))
    };
  };

  const buildCsv=(r)=>{
    const s=r.summary||{};
    const header=[
      ["section","field","value"],
      ["summary","criterion","3"],["summary","criterion_name",r.criterionName],
      ["summary","page_url",r.pageUrl],["summary","page_title",r.pageTitle||""],
      ["summary","scan_date",r.scanDate],["summary","score",r.score],["summary","status",r.status],
      ["summary","total_elements",s.totalElements],["summary","elements_with_issues",s.elementsWithIssues],
      ["summary","issues_count",s.issuesCount],
      ["summary","font_family_mismatch",s.fontFamilyMismatch],
      ["summary","font_weight_mismatch",s.fontWeightMismatch],
      [],
      ["id","requirement","category","severity","confidence","element","selector","description","evidence","expected","actual","recommendation"]
    ];
    const rows=(r.issues||[]).map(i=>[i.id,i.requirement,i.category,i.severity,i.confidence,i.linkText,i.selector||i.domPath,i.description,i.evidence,i.expected,i.actual,i.recommendation]);
    return "\ufeff"+(([...header,...rows]).map(row=>row.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\n"));
  };

  const buildPdfHtml=(r)=>{
    const data=buildStandardDataFromReport(r), s=r.summary||{}, issues=r.issues||[];
    const stLbl=data.status==="Passed"?"امتثال كامل":data.status==="Failed"?"غير ممتثل":"امتثال جزئي";
    const logoUrl=settings.extLogo?chrome.runtime.getURL(settings.extLogo):"";
    const rows=issues.length?issues.map(i=>`<tr><td>${esc(i.id)}</td><td>${esc(i.category)}</td><td>${esc(i.severity)}</td><td>${esc(i.linkText||"—")}</td><td dir="ltr">${esc(i.selector||"—")}</td><td>${esc(i.description||"—")}</td><td>${esc(i.recommendation||"—")}</td></tr>`).join("")
      :`<tr><td colspan="7">لا توجد مشاكل مكتشفة.</td></tr>`;

    return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير معيار 3 - الخطوط والأوزان</title>
<style>*{box-sizing:border-box}body{margin:0;background:#eef0f4;color:#0f172a;font-family:"IBM Plex Sans Arabic","Segoe UI",Tahoma,Arial,sans-serif;line-height:1.7}.page{max-width:980px;margin:24px auto;background:#fff;border:1px solid #e2e6ee;border-radius:14px;overflow:hidden}.head{display:flex;align-items:center;gap:16px;justify-content:space-between;padding:24px 28px;border-bottom:2px solid #E5E500}.brand{display:flex;align-items:center;gap:12px}.logo{width:110px;height:48px;object-fit:contain;border:1px solid #e2e6ee;border-radius:10px;background:#fff}.title h1{margin:0;font-size:22px}.score{display:flex;gap:18px;align-items:center;margin:22px 28px;padding:18px;border:1px solid #e2e6ee;border-radius:12px;background:#f6f8fb}.pct{font-size:42px;font-weight:800;color:#b45309}.pct.pass{color:#047857}.pct.fail{color:#b91c1c}.section{padding:0 28px 24px}.section h2{font-size:14px;color:#64748b;border-bottom:1px solid #e2e6ee;padding-bottom:6px;margin:24px 0 10px;text-transform:uppercase;letter-spacing:.06em}dl{display:grid;grid-template-columns:170px 1fr;gap:6px 14px;margin:0}dt{color:#64748b}dd{margin:0}table{width:100%;border-collapse:collapse;margin-top:8px;table-layout:fixed}th,td{border-bottom:1px solid #e2e6ee;padding:8px 10px;text-align:start;vertical-align:top;font-size:12px;word-break:break-word}th{background:#f6f8fb;color:#475569;font-weight:700}.bar{position:sticky;top:0;background:#1a1e2e;color:#fff;padding:10px 16px;display:flex;gap:8px;align-items:center;justify-content:space-between}.bar button{border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}@media print{body{background:#fff}.page{margin:0;max-width:none;border:0;border-radius:0}.bar{display:none}tr{break-inside:avoid}}</style></head><body>
<div class="bar"><span>تقرير معيار 3 — الخطوط والأوزان — جاهز للطباعة</span><button onclick="window.print()">طباعة / حفظ PDF</button></div>
<main class="page">
  <header class="head">
    <div class="brand">${logoUrl?`<img class="logo" src="${esc(logoUrl)}" alt="${esc(settings.extName)}">`:""}<div class="title"><h1>تقرير فحص الامتثال</h1><div>${esc(settings.extName)} · معيار 3 — ${esc(data.title)}</div></div></div>
    <div style="font-size:12px;color:#64748b;text-align:end">${esc(data.scanDateFormatted||"—")}<br>الحالة: ${esc(stLbl)}</div>
  </header>
  <div class="score"><div class="pct ${data.status==="Passed"?"pass":data.status==="Failed"?"fail":""}">${esc(data.score)}%</div><div><strong>${esc(stLbl)}</strong><br><span>تم فحص ${esc(s.totalElements||0)} نصوص. عدد المشاكل: ${esc(s.issuesCount||0)}.</span></div></div>
  <section class="section"><h2>معلومات الفحص</h2><dl>
    <dt>المعيار</dt><dd>3 — Typography — Platforms Code Design System</dd>
    <dt>رابط الصفحة</dt><dd dir="ltr">${esc(r.pageUrl)}</dd>
    <dt>عنوان الصفحة</dt><dd>${esc(r.pageTitle||"—")}</dd>
    <dt>وقت الفحص</dt><dd>${esc(data.scanDateFormatted||"—")}</dd>
    <dt>إجمالي العناصر المفحوصة</dt><dd>${esc(s.totalElements||0)}</dd>
    <dt>عناصر بها مشاكل</dt><dd>${esc(s.elementsWithIssues||0)}</dd>
  </dl></section>
  <section class="section"><h2>توزيع المشاكل</h2><table><thead><tr><th>الفئة</th><th>العدد</th></tr></thead><tbody>
    <tr><td>Font Family Mismatch</td><td>${esc(s.fontFamilyMismatch||0)}</td></tr>
    <tr><td>Font Weight Mismatch</td><td>${esc(s.fontWeightMismatch||0)}</td></tr>
  </tbody></table></section>
  <section class="section"><h2>تفاصيل المشاكل</h2>
    <table><thead><tr><th>ID</th><th>الفئة</th><th>الشدة</th><th>العنصر</th><th>المحدد</th><th>الوصف</th><th>التوصية</th></tr></thead>
    <tbody>${rows}</tbody></table>
  </section>
</main>
<script>setTimeout(function(){window.focus();window.print();},350);</script>
</body></html>`;
  };

  const openPdf=(r)=>{
    const html=buildPdfHtml(r), win=window.open("","_blank","width=980,height=720");
    if(!win){window.print();return false;}
    win.document.open();win.document.write(html);win.document.close();return true;
  };

  const handleDownload=(format,currentReport)=>{
    const r=currentReport||effectiveReport;
    const isSaudi = window.isSaudiWebsiteUrl?.(r?.pageUrl);
    const fmt = isSaudi ? (format||settings.format||"PDF") : "PDF";
    try {
      if(fmt==="JSON"){ dlBlob(JSON.stringify(buildJsonReport(r),null,2),"application/json;charset=utf-8",buildFilename("json",r)); flashToast("تم تنزيل تقرير JSON"); }
      else if(fmt==="CSV"){ dlBlob(buildCsv(r),"text/csv;charset=utf-8",buildFilename("csv",r)); flashToast("تم تنزيل تقرير CSV"); }
      else {
        const ok=openPdf(r);
        flashToast(isSaudi ? (ok?"تم فتح تقرير PDF وجار إرسال النتيجة":"تم فتح نافذة الطباعة وجار إرسال النتيجة") : (ok?"تم فتح تقرير PDF":"تم فتح نافذة الطباعة"));
      }
      if (isSaudi && window.EMTITHAL_API_DEFAULTS?.apiKey) {
        submitReportToWebsite(r).catch(() => {});
      }
    }catch(err){ console.error(err); flashToast("تعذر إصدار التقرير"); }
  };

  return (
    <div className="extension-root" data-screen-label="Criterion 3 Typography Extension">
      <div className="extension-panel-shell">
        {view==="browser" && (
          <SidePanel
            state={scanState} onScan={startScan} onCancel={cancelScan}
            highlighted={highlighted} onToggleHighlight={highlightAll}
            onOpenSettings={()=>setView("options")} onOpenReport={()=>setView("report")}
            onOpenFlag={()=>setShowFlag(true)}
            onOpenWebsite={openProjectWebsite}
            onLocateElement={highlightGroup} onLocateOne={locateIssue}
            extName={settings.extName} extLogo={settings.extLogo} extGlyph={settings.extGlyph}
            scanProgress={scanProgress} ignoredIssues={ignoredIssues} onIgnoreIssue={ignoreIssue}
            data={standardData} errorMessage={errorMessage}
          />
        )}
        {view==="options" && (
          <OptionsPage settings={settings} onChange={setSetting}
            onSave={()=>flashToast("تم حفظ الإعدادات")}
            onReset={()=>{ setSettings(DEFAULT_SETTINGS); persistSettings(DEFAULT_SETTINGS); flashToast("تمت إعادة ضبط الإعدادات"); }}
            onBack={()=>setView("browser")}/>
        )}
        {view==="report" && (
          <ReportPreview format={settings.format} onChangeFormat={f=>setSetting("format",f)}
            onBack={()=>setView("browser")} onDownload={handleDownload}
            onSubmitReport={targetReport => submitReportToWebsite(targetReport || effectiveReport).catch(() => {})}
            reportSubmitState={reportSubmitState}
            canSubmitReport={Boolean(window.EMTITHAL_API_DEFAULTS?.apiKey && window.isSaudiWebsiteUrl?.(effectiveReport?.pageUrl))}
            settings={settings} report={effectiveReport}/>
        )}
      </div>
      {showFlag && (
        <IssueReportModal
          onClose={()=>setShowFlag(false)}
          settings={settings}
          report={effectiveReport}
          scanState={scanState}
        />
      )}
      {toast && <div className="toast">{SP_Icon.check} {toast}</div>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<ExtensionShell />);
