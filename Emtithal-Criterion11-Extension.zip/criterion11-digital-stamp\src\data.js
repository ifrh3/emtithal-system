const EMPTY_SUMMARY = {
  totalElementsScanned: 0,
  issuesCount: 0,
  missingStamp: 0,
  placementIssues: 0,
  linkIssues: 0,
  secondaryIssues: 0
};

const STANDARD_DATA = {
  criterion: "11",
  number: 11,
  category: "عناصر",
  categoryColor: "#3B82F6",
  title: "الختم الرقمي (Digital Stamp)",
  description: "التأكد من تطبيق عنصر الختم الرقمي مع معايير التصميم الموحد (كود المنصات).",
  subCriteria: [
    {
      id: "11-1",
      title: "التواجد والمكان السليم",
      description: "يجب وضع الختم في أعلى الصفحة.",
      howToFix: "ضع الختم الرقمي داخل عنصر الترويسة (Header) أو في الجزء العلوي من الصفحة.",
      reason: "الختم غير موجود في أعلى الصفحة.",
      occurrences: 0,
      status: "fail",
      issues: []
    },
    {
      id: "11-2",
      title: "رابط الشهادة",
      description: "التأكد من ربط رقم الشهادة بالصفحة الخاصة بها بشكل صحيح.",
      howToFix: "أضف رابطاً (href) صالحاً ينقل المستخدم لصفحة شهادة الاعتماد.",
      reason: "لا يوجد رابط مرتبط بالختم الرقمي.",
      occurrences: 0,
      status: "fail",
      issues: []
    },
    {
      id: "11-3",
      title: "العناصر الثانوية",
      description: "الالتزام بعدم تجاوز عنصرين كحد أقصى بجانب الختم الأيسر.",
      howToFix: "قم بإزالة العناصر الزائدة بجانب الختم لكي لا تتجاوز عنصرين (مثل أزرار المشاركة).",
      reason: "تجاوز الحد الأقصى المسموح للعناصر بجوار الختم.",
      occurrences: 0,
      status: "fail",
      issues: []
    }
  ],
  reference: "https://design.dga.gov.sa/guidelines/components/content-display/digital-stamp"
};

function createEmptyCriterion11Report() {
  return {
    criterion: "11",
    criterionName: STANDARD_DATA.title,
    pageUrl: "",
    scanDate: new Date().toISOString(),
    score: 0,
    status: "Failed",
    issues: [],
    summary: { ...EMPTY_SUMMARY }
  };
}

function buildStandardDataFromReport(report) {
  if (!report) {
    return { ...STANDARD_DATA, totalElementsScanned: 0, scanDateFormatted: null };
  }
  const cloned = JSON.parse(JSON.stringify(STANDARD_DATA));
  cloned.pageUrl = report.pageUrl || "";
  cloned.scanDateFormatted = report.scanDate ? new Date(report.scanDate).toLocaleString("ar-SA") : "";
  cloned.score = report.score ?? 0;
  cloned.status = report.status || "Failed";
  cloned.totalElementsScanned = report.summary?.totalElementsScanned || 0;
  
  const issues = report.issues || [];
  
  const req1Issues = issues.filter(iss => iss.id === "DS-001" || iss.id === "DS-002");
  const req2Issues = issues.filter(iss => iss.id === "DS-003");
  const req3Issues = issues.filter(iss => iss.id === "DS-004");

  cloned.subCriteria[0].issues = req1Issues;
  cloned.subCriteria[0].occurrences = req1Issues.length;
  cloned.subCriteria[0].status = req1Issues.length > 0 ? "fail" : "pass";

  cloned.subCriteria[1].issues = req2Issues;
  cloned.subCriteria[1].occurrences = req2Issues.length;
  cloned.subCriteria[1].status = req2Issues.length > 0 ? "fail" : "pass";

  cloned.subCriteria[2].issues = req3Issues;
  cloned.subCriteria[2].occurrences = req3Issues.length;
  cloned.subCriteria[2].status = req3Issues.length > 0 ? "fail" : "pass";

  return cloned;
}

function getCurrentCriterion11Report() {
  return window.CURRENT_AUDIT_REPORT || window.STANDARD_DATA?.report || createEmptyCriterion11Report();
}

function setCurrentCriterion11Report(report) {
  window.CURRENT_AUDIT_REPORT = report || createEmptyCriterion11Report();
  window.STANDARD_DATA = buildStandardDataFromReport(window.CURRENT_AUDIT_REPORT);
  return window.STANDARD_DATA;
}

function getIssueKey(issue) {
  return issue?.id || issue?.target || issue?.selector || issue?.domPath || `issue-${issue?.n}`;
}

function getEffectiveSubCriteria(data, ignoredIssues = {}) {
  return data.subCriteria.map((criterion) => {
    const originalIssues = criterion.issues || [];
    const activeIssues = originalIssues.filter(
      (issue) => !ignoredIssues[getIssueKey(issue)]
    );
    const wasPass = criterion.status === "pass";
    const isPass = wasPass || activeIssues.length === 0;

    return {
      ...criterion,
      status: isPass ? "pass" : "fail",
      issues: activeIssues,
      occurrences: wasPass ? criterion.occurrences : activeIssues.length,
      reason:
        !wasPass && activeIssues.length === 0
          ? "تم تجاهل جميع المشاكل المؤكدة لهذا المتطلب."
          : criterion.reason
    };
  });
}

window.STANDARD_DATA = STANDARD_DATA;
window.EMPTY_SUMMARY = EMPTY_SUMMARY;
window.createEmptyCriterion11Report = createEmptyCriterion11Report;
window.buildStandardDataFromReport = buildStandardDataFromReport;
window.getCurrentCriterion11Report = getCurrentCriterion11Report;
window.setCurrentCriterion11Report = setCurrentCriterion11Report;
window.getIssueKey = getIssueKey;
window.getEffectiveSubCriteria = getEffectiveSubCriteria;
