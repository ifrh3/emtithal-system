(function () {
  if (window.PlatformsCodeCriterion11) return;

  const CSS_HINTS = [
    "digital-stamp", "dga-stamp", "stamp-container", "dga-digital-stamp"
  ];

  function getElementXPath(element) {
    if (element && element.id) return `//*[@id="${element.id}"]`;
    return getPathTo(element);
  }

  function getPathTo(element) {
    if (element.tagName === 'HTML') return '/HTML[1]';
    if (element === document.body) return '/HTML[1]/BODY[1]';
    let ix = 0;
    let siblings = element.parentNode ? element.parentNode.childNodes : [];
    for (let i = 0; i < siblings.length; i++) {
      let sibling = siblings[i];
      if (sibling === element) return getPathTo(element.parentNode) + '/' + element.tagName + '[' + (ix + 1) + ']';
      if (sibling.nodeType === 1 && sibling.tagName === element.tagName) ix++;
    }
    return '';
  }

  function findDigitalStamp() {
    // Strategy 1: Look by known classes
    for (const cls of CSS_HINTS) {
      const el = document.querySelector(`.${cls}, [class*="${cls}"]`);
      if (el) return el;
    }
    
    // Strategy 2: Look for an anchor linking to DGA certificate
    const links = Array.from(document.querySelectorAll('a'));
    for (const link of links) {
      if (link.href && (link.href.includes('dga.gov.sa/certificate') || link.href.includes('trust.dga.gov.sa'))) {
        return link;
      }
    }

    // Strategy 3: Look for an image that looks like a stamp
    const images = Array.from(document.querySelectorAll('img'));
    for (const img of images) {
      const src = (img.src || '').toLowerCase();
      const alt = (img.alt || '').toLowerCase();
      if ((src.includes('dga') && src.includes('stamp')) || alt.includes('ختم') || alt.includes('stamp')) {
        return img.closest('a') || img; // Return the wrapping link if it exists
      }
    }

    // Strategy 4: Look for the official government banner text
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while ((node = walker.nextNode())) {
      if (node.nodeValue.includes("موقع حكومي رسمي")) {
        let el = node.parentElement;
        // Go up to find the banner container
        let banner = el.closest('header, nav, [class*="banner"], [class*="header"]') || el.parentElement;
        // if the banner is too large (like the whole body), stick to the smaller element
        if (banner.tagName === 'BODY' || banner.tagName === 'HTML') return el;
        return banner;
      }
    }

    return null; // Not found
  }

  function auditStamp() {
    const issues = [];
    const stampEl = findDigitalStamp();

    if (!stampEl) {
      // Major failure: Stamp is missing
      issues.push({
        id: "DS-001",
        requirementId: "11",
        category: "Missing Element",
        severity: "عالي",
        confidence: "High",
        elementText: "الختم الرقمي",
        selector: "body",
        domPath: "/HTML/BODY",
        description: "لم يتم العثور على الختم الرقمي (Digital Stamp) في الصفحة.",
        evidence: "الختم إلزامي لجميع المنصات الحكومية بحسب كود المنصات.",
        expected: "وجود الختم الرقمي الخاص بهيئة الحكومة الرقمية",
        actual: "غير موجود"
      });
      return { issues, totalElementsScanned: 1 };
    }

    const path = getElementXPath(stampEl);
    const rect = stampEl.getBoundingClientRect();
    const isAtTop = rect.top < 300 || !!stampEl.closest('header');

    // 1. Check if at the top
    if (!isAtTop) {
      issues.push({
        id: "DS-002",
        requirementId: "11",
        category: "Placement",
        severity: "متوسط",
        confidence: "High",
        elementText: stampEl.innerText?.substring(0, 30) || "صورة الختم",
        selector: stampEl.className ? `.${stampEl.className.split(' ')[0]}` : stampEl.tagName.toLowerCase(),
        domPath: path,
        description: "يجب وضع الختم في أعلى الصفحة (Header).",
        evidence: `مكان الختم الحالي يبعد ${Math.round(rect.top)}px عن الأعلى.`,
        expected: "الختم في أعلى الصفحة",
        actual: "الختم ليس في المكان المخصص له"
      });
    }

    // 2. Check Certificate Link
    let hasValidLink = false;
    if (stampEl.tagName === 'A' && stampEl.href && (stampEl.href.includes('http') || stampEl.href.startsWith('/'))) {
      hasValidLink = true;
    } else {
      const allLinks = Array.from(stampEl.querySelectorAll('a'));
      for (const link of allLinks) {
        if (link.href && (link.href.includes('http') || link.href.startsWith('/') || link.href.includes('trust.dga'))) {
          hasValidLink = true;
          break;
        }
      }
    }
    
    // Fallback if the expanded menu is outside the stampEl DOM tree
    if (!hasValidLink) {
      const docLinks = Array.from(document.querySelectorAll('a'));
      for (const link of docLinks) {
        if (link.href && (link.href.includes('trust.dga.gov.sa') || link.href.includes('dga.gov.sa/certificate'))) {
          hasValidLink = true;
          break;
        }
        // If the link text is a long number (certificate number)
        if (link.innerText && /\d{8,}/.test(link.innerText.trim()) && link.href) {
          hasValidLink = true;
          break;
        }
      }
    }

    if (!hasValidLink) {
      issues.push({
        id: "DS-003",
        requirementId: "11",
        category: "Missing Link",
        severity: "عالي",
        confidence: "High",
        elementText: stampEl.innerText?.substring(0, 30) || "الختم الرقمي",
        selector: stampEl.className ? `.${stampEl.className.split(' ')[0]}` : stampEl.tagName.toLowerCase(),
        domPath: path,
        description: "التأكد من ربط رقم الشهادة بالصفحة الخاصة بها بشكل صحيح.",
        evidence: "عنصر الختم لا يحتوي على رابط (href) فعّال.",
        expected: "يجب أن يكون الختم قابلاً للضغط وينقل لصفحة الشهادة",
        actual: "رابط مفقود أو غير فعّال"
      });
    }

    // 3. Check secondary elements
    const container = stampEl.parentElement;
    if (container) {
      // Find siblings that are buttons or links
      const siblings = Array.from(container.children).filter(child => child !== stampEl && (child.tagName === 'A' || child.tagName === 'BUTTON' || child.getAttribute('role') === 'button'));
      
      if (siblings.length > 2) {
        issues.push({
          id: "DS-004",
          requirementId: "11",
          category: "Excessive Secondary Elements",
          severity: "متوسط",
          confidence: "High",
          elementText: container.innerText?.substring(0, 30) || "حاوية الختم",
          selector: container.className ? `.${container.className.split(' ')[0]}` : container.tagName.toLowerCase(),
          domPath: getElementXPath(container),
          description: "تجاوز الحد الأقصى للعناصر الثانوية بجانب الختم.",
          evidence: `تم العثور على ${siblings.length} عناصر ثانوية، والحد الأقصى هو 2.`,
          expected: "عنصرين ثانويين كحد أقصى بجوار الختم (أدوات وصول/مشاركة)",
          actual: `${siblings.length} عناصر`
        });
      }
    }

    return { issues, totalElementsScanned: 1 };
  }

  function runAudit(config) {
    const { issues, totalElementsScanned } = auditStamp();
    const score = issues.length > 0 ? (issues.length > 2 ? 0 : 50) : 100;
    const status = score === 100 ? "Passed" : (score === 0 ? "Failed" : "Partial");

    return {
      criterion: "11",
      criterionName: "الختم الرقمي",
      pageUrl: window.location.href,
      scanDate: new Date().toISOString(),
      score: score,
      status: status,
      issues: issues,
      summary: {
        totalElementsScanned: totalElementsScanned,
        issuesCount: issues.length,
        missingStamp: issues.filter(i => i.id === "DS-001").length,
        placementIssues: issues.filter(i => i.id === "DS-002").length,
        linkIssues: issues.filter(i => i.id === "DS-003").length,
        secondaryIssues: issues.filter(i => i.id === "DS-004").length
      }
    };
  }

  let overlays = [];
  function highlightIssues(items, label) {
    clearHighlights();
    let highlightedCount = 0;
    items.forEach(item => {
      let target = null;
      if (item.id === "DS-001") {
        // Highlight the whole body top if missing
        target = document.body;
      } else if (item.selector && item.selector !== 'body') {
        try { target = document.querySelector(item.selector); } catch(e){}
      }
      if (!target && item.domPath) {
        try {
          const res = document.evaluate(item.domPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
          target = res.singleNodeValue;
        } catch(e){}
      }
      if (target) {
        const rect = target.getBoundingClientRect();
        const overlay = document.createElement('div');
        overlay.className = 'dga-audit-overlay';
        overlay.style.position = 'absolute';
        overlay.style.left = (rect.left + window.scrollX) + 'px';
        overlay.style.top = (rect.top + window.scrollY) + 'px';
        overlay.style.width = Math.max(rect.width, 50) + 'px';
        overlay.style.height = Math.max(rect.height, 50) + 'px';
        overlay.style.border = '3px solid #b91c1c';
        overlay.style.backgroundColor = 'rgba(185, 28, 28, 0.1)';
        overlay.style.pointerEvents = 'none';
        overlay.style.zIndex = '999999';
        
        const badge = document.createElement('div');
        badge.textContent = item.id;
        badge.style.position = 'absolute';
        badge.style.top = '-24px';
        badge.style.left = '0';
        badge.style.background = '#b91c1c';
        badge.style.color = '#fff';
        badge.style.fontSize = '12px';
        badge.style.padding = '2px 6px';
        badge.style.borderRadius = '4px';
        overlay.appendChild(badge);
        
        document.body.appendChild(overlay);
        overlays.push(overlay);
        highlightedCount++;
        
        if (highlightedCount === 1) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    });
    return highlightedCount;
  }

  function clearHighlights() {
    overlays.forEach(o => o.remove());
    overlays = [];
    document.querySelectorAll('.dga-audit-overlay').forEach(el => el.remove());
  }

  window.PlatformsCodeCriterion11 = {
    runAudit,
    highlightIssues,
    highlightIssue: (selector, domPath) => highlightIssues([{selector, domPath}], "مشكلة مفردة"),
    clearHighlights
  };
})();
