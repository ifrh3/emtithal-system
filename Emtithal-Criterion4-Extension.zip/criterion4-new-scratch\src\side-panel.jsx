// Side Panel — the compliance extension panel
const { useState, useEffect, useMemo, useRef } = React;

// ---------- Inline icons ----------
const Icon = {
  close: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  minus: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  settings: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  info: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>,
  check: <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
  x: <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>,
  scan: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><line x1="3" y1="12" x2="21" y2="12"/></svg>,
  highlight: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 12h6"/><path d="M16 12h6"/><path d="M12 2v6"/><path d="M12 16v6"/><circle cx="12" cy="12" r="3"/></svg>,
  download: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>,
  chev: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"/></svg>,
  arrow: <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>,
  link: <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>,
  copy: <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>,
  flag: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>,
  globe: <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>,
  alert: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
bigCheck: <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>,
shield: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
};

// ---------- Donut Chart ----------
function Donut({ percent, status, size = 130 }) {
  const stroke = 14;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const dash = c * (Math.max(0, Math.min(100, percent || 0)) / 100);
  const color = {
    success: "var(--success)",
    partial: "var(--warning)",
    fail: "var(--error)",
    idle: "#cbd5e1"
  }[status] || "#cbd5e1";

  return (
    <div className="result-donut" style={{position: "relative", width: size, height: size}}>
      <svg width={size} height={size} style={{transform: "rotate(-90deg)"}}>
        <circle cx={size/2} cy={size/2} r={r} stroke="var(--surface-3)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size/2} cy={size/2} r={r}
          stroke={color}
          strokeWidth={stroke} fill="none"
          strokeDasharray={`${dash} ${c}`}
          strokeLinecap="round"
          style={{transition: "stroke-dasharray 0.6s ease, stroke 0.4s"}}
        />
      </svg>
      <div style={{
        position: "absolute", inset: 0,
        display: "flex", flexDirection: "column",
        alignItems: "center", justifyContent: "center"
      }}>
        <div className="result-percent">
          {percent == null ? "—" : `${percent}%`}
        </div>
        <div style={{fontSize: 10, color: "var(--text-3)", letterSpacing: "0.04em", marginTop: 2}}>
          نسبة الامتثال
        </div>
      </div>
    </div>
  );
}

function criterionToneStyles(color) {
  const safe = color || "#94DCF8";
  return {
    "--std-color": safe,
    "--std-soft": hexToRgba(safe, 0.24),
    "--std-ink": readableInk(safe)
  };
}

function hexToRgba(hex, alpha) {
  const value = String(hex || "").replace("#", "");
  const full = value.length === 3 ? value.split("").map(ch => ch + ch).join("") : value.padEnd(6, "0");
  const num = parseInt(full.slice(0, 6), 16);
  if (Number.isNaN(num)) return `rgba(148, 220, 248, ${alpha})`;
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function readableInk(hex) {
  const value = String(hex || "").replace("#", "");
  const full = value.length === 3 ? value.split("").map(ch => ch + ch).join("") : value.padEnd(6, "0");
  const num = parseInt(full.slice(0, 6), 16);
  if (Number.isNaN(num)) return "#0f172a";
  const r = (num >> 16) & 255;
  const g = (num >> 8) & 255;
  const b = num & 255;
  const yiq = (r * 299 + g * 587 + b * 114) / 1000;
  return yiq >= 150 ? "#0f172a" : "#ffffff";
}

// ---------- Sub-criteria item ----------
function SubItem({ item, open, onToggle, onLocate, onHighlight, onIgnore }) {
  return (
    <div className={"sub-item " + item.status + (open ? " open" : "")}>
      <button className="sub-head" onClick={onToggle}>
        <div className="sub-status-icon">
          {item.status === "pass" ? Icon.check : Icon.x}
        </div>
        <div className="sub-text">
          <div className="sub-title">{item.title}</div>
          <div className="sub-meta">
            <span className={"sub-badge " + (item.status === "pass" ? "success" : "")}>
              {item.status === "pass" ? "ناجح" : "غير ناجح"}
            </span>
            <span>·</span>
            <span>{item.occurrences} {item.status === "pass" ? "تحقق" : "تكرار"}</span>
          </div>
        </div>
        <div className="sub-chevron">{Icon.chev}</div>
      </button>
      {open && (
        <div className="sub-detail">
          <h5>وصف المعيار</h5>
          <div>{item.description}</div>

          <h5>{item.status === "pass" ? "سبب النجاح" : "سبب الفشل"}</h5>
          <div>{item.reason}</div>

          <h5>كيفية تحقيق المعيار</h5>
          <div>{item.howToFix}</div>

          {item.issues && item.issues.length > 0 && (
            <>
              <h5>العناصر المخالفة ({item.issues.length})</h5>
              <div className="issue-list">
                {item.issues.map(iss => (
                  <div key={iss.n} className="issue">
                    <div className="num">{iss.n}</div>
                    <div className="issue-body">
                      <strong>{iss.element}</strong>
                      <div style={{color: "var(--text-3)", marginTop: 2}}>{iss.location}</div>
                      <div className="issue-meta">
                        <span className="kbd bad">{iss.severity || "—"}</span>
                        <span className="kbd">{iss.confidence || "—"}</span>
                      </div>
                      <div style={{fontSize: 11, color: "var(--text-3)", lineHeight: 1.6, marginTop: 6}}>
                        {iss.description || iss.current}
                      </div>
                      {iss.evidence && (
                        <div style={{fontSize: 11, color: "var(--text-3)", lineHeight: 1.6, marginTop: 6}}>
                          الدليل: {iss.evidence}
                        </div>
                      )}
                      <div className="issue-meta">
                        <span className="kbd bad">{iss.actual || iss.current}</span>
                        <span style={{color:"var(--text-muted)"}}>←</span>
                        <span className="kbd ok">{iss.expected || iss.suggested}</span>
                      </div>
                      <div className="issue-meta" style={{marginTop:6}}>
                        <span className="kbd">{iss.target}</span>
                        <button className="detail-btn" onClick={() => onLocate(iss.target, iss)}>
                          {Icon.arrow} انتقل
                        </button>
                        {onIgnore && (
                          <button className="detail-btn" onClick={() => onIgnore(iss)}>
                            {Icon.minus} تجاهل
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          <div className="detail-actions">
            {item.issues && item.issues.length > 0 && (
              <button className="detail-btn" onClick={() => onHighlight(item)}>
                {Icon.highlight} تمييز عناصر هذا المعيار
              </button>
            )}
            <a className="ref" href="#" onClick={(e)=>e.preventDefault()}>
              {Icon.link} المرجع الرسمي
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- Side Panel ----------
function SidePanel({
  state, onScan, onCancel,
  highlighted, onToggleHighlight,
  onOpenSettings, onOpenReport, onOpenFlag,
  onLocateElement, onLocateOne,
  onPartialInfo,
  ignoredIssues = {}, onIgnoreIssue,
  extName, extLogo, extGlyph, scanProgress,
  data: inputData, errorMessage
}) {
  const [filter, setFilter] = useState("all");
  const [openId, setOpenId] = useState(null);

  const data = inputData || STANDARD_DATA;
  const categoryTone = criterionToneStyles(data.categoryColor);

  // Compute counts
// Compute counts after ignored issues
const effectiveItems = useMemo(
  () => getEffectiveSubCriteria(data, ignoredIssues),
  [data, ignoredIssues]
);

const failCount = effectiveItems.filter(s => s.status === "fail").length;
const passCount = effectiveItems.filter(s => s.status === "pass").length;

const activeIssueCount = effectiveItems.reduce(
  (a, s) => a + (s.issues?.length || 0),
  0
);

  // Override based on state for "full compliance" / "fail" / etc.
  const view = useMemo(() => {
    if (state === "full") {
      return {
        percent: 100, status: "success",
        statusText: "امتثال كامل",
        passCount: data.subCriteria.length, failCount: 0,
        elements: data.totalElementsScanned, affected: 0,
        items: data.subCriteria.map(s => ({...s, status: "pass", issues: []})),
      };
    }
    if (state === "none") {
      return {
        percent: 0, status: "fail",
        statusText: "الصفحة غير ممتثلة لهذا المعيار",
        passCount: 0, failCount: data.subCriteria.length,
        elements: data.totalElementsScanned, affected: data.totalElementsScanned,
        items: data.subCriteria.map(s => ({...s, status: "fail"})),
      };
    }
    if (state === "partial") {
      const ratio = data.subCriteria.length
        ? Math.round((passCount / data.subCriteria.length) * 100)
        : 100;
      const isFullAfterIgnore = failCount === 0;

      return {
        percent: ratio,
        status: isFullAfterIgnore ? "success" : "partial",
        statusText: isFullAfterIgnore ? "امتثال كامل" : "امتثال جزئي",
        passCount,
        failCount,
        elements: data.totalElementsScanned,
        affected: activeIssueCount,
        items: effectiveItems,
      };
    }
    return null;
 }, [state, data, effectiveItems, passCount, failCount, activeIssueCount]);

  // Filter subcriteria
  const filtered = useMemo(() => {
    if (!view) return [];
    if (filter === "fail") return view.items.filter(s => s.status === "fail");
    if (filter === "pass") return view.items.filter(s => s.status === "pass");
    return view.items;
  }, [view, filter]);

  // Auto-set filter when state changes
  useEffect(() => {
    if (state === "partial") setFilter("fail");
    else if (state === "full") setFilter("all");
    else if (state === "none") setFilter("fail");
    else setFilter("all");
    setOpenId(null);
  }, [state]);

  // Header status
  const headerStatus = (() => {
    if (state === "before") return { dot: "", text: "لم يتم الفحص بعد" };
    if (state === "scanning") return { dot: "scanning", text: "جاري فحص الصفحة..." };
    if (state === "full") return { dot: "success", text: "الصفحة ممتثلة بالكامل" };
    if (state === "partial" && failCount === 0) {
      return { dot: "success", text: "الصفحة ممتثلة بالكامل" };
    }

    if (state === "partial") return { dot: "partial", text: "تم الفحص — امتثال جزئي" };
    if (state === "none") return { dot: "fail", text: "الصفحة غير ممتثلة" };
    if (state === "error") return { dot: "fail", text: "تعذر فحص الصفحة" };
    if (state === "n/a") return { dot: "", text: "غير قابل للتطبيق" };
    return { dot: "", text: "—" };
  })();

  return (
    <div className="sp">
      {/* HEADER */}
      <div className="sp-header" style={categoryTone}>
        <div className="sp-brand">
          <div className="sp-logo" title="رابط الموقع الرئيسي">
            {extLogo ? (
              <img src={extLogo} alt={extName} className="app-logo-img" />
            ) : (
              extGlyph
            )}
          </div>
          <div className="sp-brand-text">
            <div className="sp-title">إمتثال</div>
            <div className="sp-subtitle">فحص معايير كود المنصات</div>
          </div>
          <button className="sp-iconbtn" title="الإعدادات" onClick={onOpenSettings}>{Icon.settings}</button>
          <button className="sp-iconbtn" title="تصغير">{Icon.minus}</button>
          <button className="sp-iconbtn danger" title="إغلاق اللوحة">{Icon.close}</button>
        </div>
        <div className="sp-status-row">
          <span className={"sp-status-dot " + headerStatus.dot}></span>
          <span>{headerStatus.text}</span>
          <span style={{ flex: 1 }}></span>
          <span style={{ fontSize: 11, padding: "2px 7px", borderRadius: 4, background: data.categoryColor, color: categoryTone["--std-ink"], fontWeight: 600 }}>
            {data.category}
          </span>
        </div>
      </div>
      {/* BODY */}
      <div className="sp-body">
        {/* Standard info card — shown in all states */}
        <div className="card std-card" style={categoryTone}>
          <div className="std-head">
            <span className="std-num" style={{ background: categoryTone["--std-soft"], color: categoryTone["--std-ink"] }}>معيار {data.number.toString().padStart(2,"0")}</span>
            <span className="std-cat" style={{ background: categoryTone["--std-soft"] }}>{data.category}</span>
          </div>
          <div className="std-title">{data.title}</div>
          <div style={{fontSize: 12, color: "var(--text-3)", lineHeight: 1.6, marginBottom: 8}}>
            {data.description}
          </div>
          <dl className="std-meta">
            <dt>الصفحة</dt>
            <dd>{data.pageUrl} <button className="sp-iconbtn" style={{display:"inline-grid",width:18,height:18,marginInlineStart:4,verticalAlign:"middle"}} title="نسخ">{Icon.copy}</button></dd>
            <dt>وقت الفحص</dt>
            <dd style={{fontFamily: "var(--font)"}}>{state === "before" ? "—" : (data.scanDateFormatted || "—")}</dd>
          </dl>
        </div>

        {/* === STATE: BEFORE === */}
        {state === "before" && (
          <>
            <button className="scan-btn" onClick={onScan}>
              {Icon.scan} فحص الصفحة
            </button>
            <div className="hint">
              <span className="ico">{Icon.info}</span>
              <div>
                اضغط على <strong>فحص الصفحة</strong> للتحقق من امتثالها لمعيار <strong>{data.title}</strong>. الفحص يتم محليًا في متصفحك ولا تُرسل بيانات الصفحة لأي خادم خارجي.
              </div>
            </div>

            <div className="actions">
              <button className="action" disabled>{Icon.highlight} تمييز المشاكل</button>
              <button className="action" disabled>{Icon.download} الرفع والتصدير</button>
            </div>
          </>
        )}

        {/* === STATE: SCANNING === */}
        {state === "scanning" && (
          <>
            <button className="scan-btn" disabled>
              <span className="scan-spinner"></span>
              جاري فحص الصفحة...
            </button>
            <div className="scan-progress">
              <div style={{fontSize: 13, fontWeight: 600}}>تحليل عناصر الصفحة</div>
              <div style={{fontSize: 11, color: "var(--text-3)", marginTop: 2}}>
                قد يستغرق هذا بضع ثوانٍ حسب حجم الصفحة
              </div>
              <div className="stages">
                {[
                  "اكتشاف الأزرار",
                  "قراءة computed styles",
                  "فحص التصميم والحالات",
                  "تجهيز تقرير معيار 4"
                ].map((label, i) => {
                  const cls =
                    i < scanProgress ? "stage done"
                    : i === scanProgress ? "stage active"
                    : "stage";
                  return <div key={i} className={cls}><span className="stage-ico"></span>{label}</div>;
                })}
              </div>
              <div className="progress-bar">
                <div className="fill" style={{width: `${(scanProgress/4)*100}%`}}></div>
              </div>
              <button
                style={{marginTop: 12, fontSize: 11, color: "var(--text-3)", background: "none", border: "none"}}
                onClick={onCancel}
              >إلغاء الفحص</button>
            </div>
            <div className="actions">
              <button className="action" disabled>{Icon.highlight} تمييز المشاكل</button>
              <button className="action" disabled>{Icon.download} الرفع والتصدير</button>
            </div>
          </>
        )}

        {/* === STATE: ERROR === */}
        {state === "error" && (
          <>
            <div className="empty-state error">
              <div className="icon-wrap">{Icon.alert}</div>
              <div className="title">تعذر فحص الصفحة</div>
              <div className="desc">
                {errorMessage || "لا يمكن الوصول إلى محتوى الصفحة الحالية. قد تكون محمية أو لا تسمح بالفحص. حاول إعادة الفحص، أو أبلغ عن المشكلة إذا استمرت."}
              </div>
            </div>
            <button className="scan-btn" onClick={onScan}>
              {Icon.scan} إعادة المحاولة
            </button>
            <button className="action" onClick={onOpenFlag}>{Icon.flag} إبلاغ عن مشكلة</button>
          </>
        )}

        {/* === STATE: N/A === */}
        {state === "n/a" && (
          <>
            <div className="empty-state">
              <div className="icon-wrap">{Icon.info}</div>
              <div className="title">غير قابل للتطبيق</div>
              <div className="desc">
                لم يتم العثور على عناصر تنطبق عليها شروط هذا المعيار في الصفحة الحالية.
              </div>
            </div>
            <button className="scan-btn secondary" onClick={onScan}>
              {Icon.scan} إعادة فحص الصفحة
            </button>
            <button className="action" onClick={onOpenReport}>{Icon.download} الرفع والتصدير</button>
          </>
        )}

        {/* === STATES: FULL / PARTIAL / NONE === */}
        {view && (
          <>
            <div className="card result-card">
              <Donut percent={view.percent} status={view.status} />
              <div className={"result-status " + view.status}>
                {view.status === "success" && Icon.check}
                {view.status !== "success" && (view.status === "fail" ? Icon.x : Icon.alert)}
                {view.statusText}
              </div>
              {view.status === "success" && (
                <div style={{fontSize: 12, color: "var(--text-3)", marginTop: 8, lineHeight: 1.6}}>
                  الصفحة ممتثلة بالكامل لمعيار <strong style={{color: "var(--text)"}}>{data.title}</strong>.
                </div>
              )}
            </div>

            {/* Summary stats */}
            <div className="summary-grid">
              <div className="stat success">
                <div className="top"><span className="dot"></span>تم اجتيازها</div>
                <div className="num">{view.passCount}</div>
              </div>
              <div className="stat fail">
                <div className="top"><span className="dot"></span>لم يتم اجتيازها</div>
                <div className="num">{view.failCount}</div>
              </div>
              <div className="stat neutral">
                <div className="top"><span className="dot"></span>إجمالي العناصر المفحوصة</div>
                <div className="num">{data.summary?.totalElementsScanned ?? view.elements}</div>
              </div>
              <div className="stat fail">
                <div className="top"><span className="dot"></span>عناصر / مخالفات مسافات</div>
                <div className="num">{data.summary ? `${data.summary.totalElementsScanned || 0}/${data.summary.issuesCount || 0}` : view.affected}</div>
              </div>
            </div>

            {/* Action buttons */}
            <div className="actions">
              <button
                className={"action" + (highlighted ? " active" : "")}
                onClick={onToggleHighlight}
                disabled={view.failCount === 0}
              >
                {Icon.highlight}
                {highlighted ? "إخفاء التمييز" : "تمييز أماكن المشاكل"}
              </button>
              <button className="action" onClick={onOpenReport}>
                {Icon.download} الرفع والتصدير
              </button>
            </div>

            <button className="scan-btn secondary" onClick={onScan}>
              {Icon.scan} إعادة فحص الصفحة
            </button>

            {/* Filters */}
            <div className="filters">
              {[
                { id: "all", label: "الكل", count: view.items.length },
                { id: "fail", label: "المشاكل", count: view.failCount },
                { id: "pass", label: "الناجحة", count: view.passCount }
              ].map(f => (
                <button
                  key={f.id}
                  className={"filter-btn" + (filter === f.id ? " active" : "")}
                  onClick={() => setFilter(f.id)}
                >
                  {f.label}
                  <span className="filter-count">{f.count}</span>
                </button>
              ))}
            </div>

            {/* Sub-criteria list */}
            <div className="sublist">
              {filtered.map(item => (
                <SubItem
  key={item.id}
  item={item}
  open={openId === item.id}
  onToggle={() => setOpenId(openId === item.id ? null : item.id)}
  onLocate={onLocateOne}
  onHighlight={() => onLocateElement(item)}
  onIgnore={onIgnoreIssue}
/>
              ))}
              {filtered.length === 0 && (
                <div style={{textAlign:"center", padding: "24px 16px", color: "var(--text-3)", fontSize: 12, background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 10}}>
                  {filter === "fail" ? "لا توجد مشاكل في هذا الفحص — أحسنت!" : "لا توجد عناصر مطابقة"}
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* FOOTER */}
      <div className="sp-footer">
        <div className="links">
          <button title="الإعدادات" onClick={onOpenSettings}>
            {Icon.settings} الإعدادات
          </button>
          <button title="إبلاغ عن مشكلة" onClick={onOpenFlag}>
            {Icon.flag} إبلاغ
          </button>
          <button title="الموقع الرئيسي" onClick={() => window.open("https://emtithal-system.vercel.app/home/emtithal_public_home.html", "_blank")}>
            {Icon.globe} الموقع
          </button>
        </div>
        <div className="ver">v1.0.0</div>
      </div>
    </div>
  );
}

window.SidePanel = SidePanel;
window.Donut = Donut;
window.SP_Icon = Icon;
