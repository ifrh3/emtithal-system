const EMPTY_SUMMARY = {
  totalElementsScanned: 0,
  spacingViolations: 0,
  layoutViolations: 0,
  elementsWithIssues: 0,
  invalidSpacingValues: 0,
  hardcodedSpacing: 0,
  invalidGapValues: 0,
  issuesCount: 0
};

const STANDARD_DATA = {
  criterion: "4",
  number: 4,
  category: "أساسات",
  categoryColor: "#E5E500",
  title: "المسافات والتخطيط (Layout & Spacing)",
  description: "التأكد من تطبيق أرقام المسافات على الصفحة كما في نظام التصميم الموحد.",
  subCriteria: [
    {
      id: "req-1",
      title: "الالتزام بوحدات القياس المعتمدة",
      description: "الالتزام بوحدات القياس المعتمدة في كود المنصات (مثل 4px, 8px, 16px...) عند تحديد المسافات بين العناصر.",
      howToFix: "استخدم مضاعفات الرقم 4 و 8 في المسافات.",
      reason: "تم العثور على هوامش أو حشوات لا تتبع نظام مضاعفات 4.",
      occurrences: 0,
      status: "fail",
      issues: []
    },
    {
      id: "req-2",
      title: "الالتزام باستخدام رموز المسافات (Design Tokens)",
      description: "الالتزام باستخدام رموز المسافات للتصميم (Global Spacing Design Tokens). مع الالتزام بعدم استخدام المسافات المخصصة للعناصر.",
      howToFix: "استبدل القيم الثابتة (مثل margin: 10px) بمتغيرات CSS معتمدة.",
      reason: "تم رصد مسافات ثابتة بدلاً من الاعتماد على Design Tokens.",
      occurrences: 0,
      status: "fail",
      issues: []
    },
    {
      id: "req-3",
      title: "استخدام المسافات البينية (Gap) للشبكات",
      description: "استخدام خاصية gap لترتيب العناصر في قوائم Flexbox أو الشبكات Grid بدلاً من استخدام الهوامش المعقدة.",
      howToFix: "تأكد من استخدام خاصية gap ومضاعفات الـ 4.",
      reason: "تم رصد استخدام Flex/Grid بدون Gap صحيح أو بقيم لا تتبع المضاعفات.",
      occurrences: 0,
      status: "fail",
      issues: []
    }
  ],
  reference: "https://design.dga.gov.sa/guidelines/foundations/layout-and-spacing"
};

function createEmptyCriterion4Report() {
  return {
    criterion: "4",
    criterionName: STANDARD_DATA.title,
    pageUrl: "",
    scanDate: new Date().toISOString(),
    score: 0,
    status: "Failed",
    issues: [],
    summary: { ...EMPTY_SUMMARY }
  };
}

function buildStandardDataFromReport(report) {
  if (!report) {
    return { ...STANDARD_DATA, totalElementsScanned: 0, scanDateFormatted: null };
  }
  const cloned = JSON.parse(JSON.stringify(STANDARD_DATA));
  cloned.pageUrl = report.pageUrl || "";
  cloned.scanDateFormatted = report.scanDate ? new Date(report.scanDate).toLocaleString("ar-SA") : "";
  cloned.score = report.score ?? 0;
  cloned.status = report.status || "Failed";
  cloned.totalElementsScanned = report.summary?.totalElementsScanned || 0;
  
  const issues = report.issues || [];
  
  const req1Issues = issues.filter(iss => iss.requirementId === "req-1");
  const req2Issues = issues.filter(iss => iss.requirementId === "req-2");
  const req3Issues = issues.filter(iss => iss.requirementId === "req-3");

  cloned.subCriteria[0].issues = req1Issues;
  cloned.subCriteria[0].occurrences = req1Issues.length;
  cloned.subCriteria[0].status = req1Issues.length > 0 ? "fail" : "pass";

  cloned.subCriteria[1].issues = req2Issues;
  cloned.subCriteria[1].occurrences = req2Issues.length;
  cloned.subCriteria[1].status = req2Issues.length > 0 ? "fail" : "pass";

  cloned.subCriteria[2].issues = req3Issues;
  cloned.subCriteria[2].occurrences = req3Issues.length;
  cloned.subCriteria[2].status = req3Issues.length > 0 ? "fail" : "pass";

  return cloned;
}

function getCurrentCriterion4Report() {
  return window.CURRENT_AUDIT_REPORT || window.STANDARD_DATA?.report || createEmptyCriterion4Report();
}

function setCurrentCriterion4Report(report) {
  window.CURRENT_AUDIT_REPORT = report || createEmptyCriterion4Report();
  window.STANDARD_DATA = buildStandardDataFromReport(window.CURRENT_AUDIT_REPORT);
  return window.STANDARD_DATA;
}

function getIssueKey(issue) {
  return issue?.id || issue?.target || issue?.selector || issue?.domPath || `issue-${issue?.n}`;
}

function getEffectiveSubCriteria(data, ignoredIssues = {}) {
  return data.subCriteria.map((criterion) => {
    const originalIssues = criterion.issues || [];
    const activeIssues = originalIssues.filter(
      (issue) => !ignoredIssues[getIssueKey(issue)]
    );
    const wasPass = criterion.status === "pass";
    const isPass = wasPass || activeIssues.length === 0;

    return {
      ...criterion,
      status: isPass ? "pass" : "fail",
      issues: activeIssues,
      occurrences: wasPass ? criterion.occurrences : activeIssues.length,
      reason:
        !wasPass && activeIssues.length === 0
          ? "تم تجاهل جميع المشاكل المؤكدة لهذا المتطلب."
          : criterion.reason
    };
  });
}

window.STANDARD_DATA = STANDARD_DATA;
window.EMPTY_SUMMARY = EMPTY_SUMMARY;
window.createEmptyCriterion4Report = createEmptyCriterion4Report;
window.buildStandardDataFromReport = buildStandardDataFromReport;
window.getCurrentCriterion4Report = getCurrentCriterion4Report;
window.setCurrentCriterion4Report = setCurrentCriterion4Report;
window.getIssueKey = getIssueKey;
window.getEffectiveSubCriteria = getEffectiveSubCriteria;
