// Extension App - real active-tab Criterion 4 Button audit while preserving the template panel style
const { useState, useEffect, useRef, useMemo } = React;

function ComplaintForm({ onBack, onSubmit, isSubmitting }) {
  const [violation, setViolation] = useState("");
  return (
    <div className="report-shell">
      <div className="report-page" style={{minHeight: "100%", padding: 20}}>
        <div className="report-toolbar" style={{padding: 0, paddingBottom: 16, borderBottom: "1px solid var(--border)", marginBottom: 16}}>
          <div className="left" style={{display: "flex", gap: 12, alignItems: "center"}}>
            <button className="btn" onClick={onBack}>← العودة</button>
            <span style={{fontWeight: 600}}>إبلاغ عن مشكلة</span>
          </div>
        </div>
        <h2>تفاصيل البلاغ</h2>
        <p style={{color: "var(--text-3)", fontSize: 14}}>يرجى وصف المشكلة التي واجهتك في هذه الصفحة وسيتم رفعها تلقائياً للمنصة.</p>
        <textarea 
          value={violation}
          onChange={(e) => setViolation(e.target.value)}
          placeholder="اكتب وصف المشكلة هنا..."
          style={{width: "100%", height: 150, padding: 12, borderRadius: 8, border: "1px solid var(--border)", marginTop: 12, resize: "vertical", fontFamily: "inherit"}}
        />
        <button 
          className="btn primary" 
          style={{marginTop: 16, width: "100%", padding: 12}}
          onClick={() => onSubmit(violation)}
          disabled={!violation.trim() || isSubmitting}
        >
          {isSubmitting ? "جاري الإرسال..." : "إرسال البلاغ"}
        </button>
      </div>
    </div>
  );
}

const DEFAULT_SETTINGS = {
  extName: "امتثال",
  extGlyph: "ف",
  extLogo: "assets/images/emttthal-logo.png",
  lang: "ar",
  theme: "light",
  notifications: true,
  autoScroll: true,
  clearOnClose: true,
  format: "PDF",
  incLink: true,
  incTime: true,
  incDetails: true,
  incElements: true,
  incRecs: true,
  incExec: true,
  apiKey: ""
};

function ExtensionShell() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [view, setView] = useState("browser");
  const [scanState, setScanState] = useState("before");
  const [scanProgress, setScanProgress] = useState(0);
  const [highlighted, setHighlighted] = useState(false);
  const [ignoredIssues, setIgnoredIssues] = useState({});
  const [report, setReport] = useState(createEmptyCriterion4Report());
  const [standardData, setStandardData] = useState(buildStandardDataFromReport(null));
  const [toast, setToast] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [isAppBlocked, setIsAppBlocked] = useState(false);
  const [isCheckingBlock, setIsCheckingBlock] = useState(true);
  const toastTimer = useRef(null);

  // Check if API key is suspended
  useEffect(() => {
    const checkStatus = async () => {
      try {
        const apiKey = "emt_live_sk_4p5cbq9qrz78b0czk5urfonq";
        const url = `https://wsexgnphxcuceyqquhzv.supabase.co/rest/v1/api_keys?select=status&key=eq.${apiKey}`;
        const res = await fetch(url, {
          headers: {
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzZXhnbnBoeGN1Y2V5cXF1aHp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyMTU3NTMsImV4cCI6MjA5NDc5MTc1M30.0u9VgV4sPMs-PSdsBkc0cgW4yc-9wTXQkbbaKmfJ3QA',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzZXhnbnBoeGN1Y2V5cXF1aHp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyMTU3NTMsImV4cCI6MjA5NDc5MTc1M30.0u9VgV4sPMs-PSdsBkc0cgW4yc-9wTXQkbbaKmfJ3QA'
          }
        });
        if (res.ok) {
          const data = await res.json();
          if (data && data.length > 0) {
            if (data[0].status === 'suspended') {
              setIsAppBlocked(true);
            }
          }
        }
      } catch (err) {
        console.error("Failed to check status", err);
      } finally {
        setIsCheckingBlock(false);
      }
    };
    checkStatus();
  }, []);

  const flashToast = (msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  };

  useEffect(() => {
    const theme = settings.theme || "light";
    document.documentElement.setAttribute("data-theme", theme);
  }, [settings.theme]);

  const applyTemplateCalculation = (rawReport) => {
    const data = buildStandardDataFromReport(rawReport);
    const normalized = {
      ...rawReport,
      score: data.score,
      status: data.status,
      severityScore: typeof rawReport?.score === "number" ? rawReport.score : undefined,
      calculationMethod: "template-pass-ratio",
      calculationNote: "score = passed Criterion 4 requirements / 3 * 100, matching the uploaded template calculation logic"
    };
    return { report: normalized, data: buildStandardDataFromReport(normalized) };
  };

  const getTemplateScanState = (data) => {
    if (data.score === 100) return "full";
    if (data.score === 0) return "none";
    return "partial";
  };

  const updateReport = (nextReport) => {
    const normalized = applyTemplateCalculation(nextReport);
    setCurrentCriterion4Report(normalized.report);
    setReport(normalized.report);
    setStandardData(normalized.data);
    setIgnoredIssues({});
    if (chrome?.storage?.local) {
      chrome.storage.local.set({ criterion4LastReport: normalized.report }).catch(() => {});
    }
    return normalized.data;
  };

  const rebuildSummaryForIssues = (baseReport, activeIssues) => {
    const baseSummary = baseReport?.summary || {};
    const affected = new Set((activeIssues || []).map(issue => issue.selector || issue.domPath || issue.href));
    const issueHasCheck = (issue, code) => {
      return (issue.checks || []).some(check => String(check.code || "").includes(code))
        || String(issue.id || "").includes(code);
    };
    return {
      ...baseSummary,
      elementsWithIssues: affected.size,
      issuesCount: activeIssues.length,
      invalidSpacingValues: activeIssues.filter(issue => issue.category === "Invalid Spacing Value").length,
      hardcodedSpacing: activeIssues.filter(issue => issue.category === "Hardcoded Spacing").length,
      invalidGapValues: activeIssues.filter(issue => issue.category === "Invalid Gap Value").length,
      spacingViolations: activeIssues.filter(issue => issue.category === "Invalid Spacing Value" || issue.category === "Hardcoded Spacing").length,
      layoutViolations: activeIssues.filter(issue => issue.category === "Invalid Gap Value").length
    };
  };

  const createEffectiveReport = (baseReport, ignoredMap) => {
    const activeIssues = (baseReport?.issues || []).filter(issue => !ignoredMap[getIssueKey(issue)]);
    const filtered = {
      ...(baseReport || createEmptyCriterion4Report()),
      issues: activeIssues,
      summary: rebuildSummaryForIssues(baseReport, activeIssues)
    };
    return applyTemplateCalculation(filtered).report;
  };

  const effectiveReport = useMemo(() => createEffectiveReport(report, ignoredIssues), [report, ignoredIssues]);

  useEffect(() => {
    if (!chrome?.storage?.local) return;
    chrome.storage.local.get(["criterion4LastReport", "criterion4Settings"]).then(result => {
      if (result.criterion4LastReport) updateReport(result.criterion4LastReport);
      if (result.criterion4Settings) setSettings(result.criterion4Settings);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (scanState !== "scanning") return;
    setScanProgress(0);
    let current = 0;
    const timer = setInterval(() => {
      current += 1;
      setScanProgress(Math.min(current, 4));
      if (current >= 4) clearInterval(timer);
    }, 350);
    return () => clearInterval(timer);
  }, [scanState]);

  const loadConfig = async () => {
    try {
      const response = await fetch(chrome.runtime.getURL("design-system-config.json"));
      if (!response.ok) throw new Error(`Config HTTP ${response.status}`);
      return await response.json();
    } catch (_) {
      // Keep the extension operational even if the config file is unavailable.
      // Unknown exact Figma/token values are not treated as failures; the audit reports only confirmed violations.
      return {
        criterion: "12",
        buttons: {
          scanSelectors: ["button", "input[type='button']", "input[type='submit']", "input[type='reset']", "[role='button']", "a[class*='btn' i]", "a[class*='button' i]", "a[data-component*='button' i]"],
          platformCodeClassHints: ["dga-btn", "dga-button", "pc-button", "platform-button", "btn-primary", "btn-secondary", "btn-tertiary"],
          allowedBorderRadiusPx: [4, 6, 8],
          maxBorderRadiusPx: 8,
          maxTextButtonRadiusRatio: 0.35,
          minHeightPx: 32,
          minIconButtonSizePx: 32,
          minTouchTargetPx: 44,
          allowedHeightsPx: [32, 40, 48],
          heightTolerancePx: 5,
          minHorizontalPaddingPx: 12,
          minVerticalPaddingPx: 6,
          minContrastRatio: 4.5,
          allowedColorPalette: ["#1b8354", "#166a45", "#14573a", "#d92d20", "#b42318", "#ffffff", "#f3f4f6", "#f9fafb", "#111827", "#161616", "#384250", "#6c737f"],
          strictTokenColorCheck: false,
          requireVisibleFocus: true,
          requireDisabledVisualState: true,
          requireCustomStateSelectors: false,
          requireSemanticButton: true,
          requireValidHrefForLinkButtons: true,
          requireIconButtonLabel: true,
          requireContrast: true
        }
      };
    }
  };

  const getActiveTab = async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs && tabs[0];
  };

  const getTabUrl = (tab) => tab?.url || tab?.pendingUrl || "";

  const canScanTab = (tab) => {
    if (!tab || !tab.id) return false;
    const url = getTabUrl(tab);
    // If Chrome does not expose the URL for a moment, let executeScript be the source of truth
    // instead of blocking every page with a false "تعذر الفحص" state.
    if (!url) return true;
    return /^(https?:|file:)/i.test(url);
  };

  const getUnsupportedTabMessage = (tab) => {
    const url = getTabUrl(tab);
    if (!tab || !tab.id) return "لم يتم العثور على تبويب نشط يمكن فحصه.";
    if (/^(chrome:|edge:|about:|devtools:|chrome-extension:|view-source:)/i.test(url)) {
      return "لا يمكن فحص صفحات المتصفح الداخلية. افتح صفحة موقع عادية http/https ثم أعد الفحص.";
    }
    if (/^file:/i.test(url)) {
      return "صفحات الملفات المحلية تحتاج تفعيل Allow access to file URLs من إعدادات الإضافة في المتصفح.";
    }
    return "لا يمكن فحص هذه الصفحة. افتح صفحة http أو https ثم أعد المحاولة.";
  };

  const startScan = async () => {
    setErrorMessage("");
    setHighlighted(false);
    setScanState("scanning");

    try {
      const [tab, config] = await Promise.all([getActiveTab(), loadConfig()]);
      if (!canScanTab(tab)) {
        throw new Error(getUnsupportedTabMessage(tab));
      }

      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["src/criterion4-audit.js"]
      });

      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: async (auditConfig) => {
          if (!window.PlatformsCodeCriterion4 || typeof window.PlatformsCodeCriterion4.runAudit !== "function") {
            throw new Error("لم يتم تحميل محرك فحص معيار 4 داخل الصفحة.");
          }
          return window.PlatformsCodeCriterion4.runAudit(auditConfig);
        },
        args: [config]
      });

      const nextReport = results?.[0]?.result;
      if (!nextReport) throw new Error("لم يتم إرجاع نتيجة الفحص من الصفحة الحالية.");

      const nextData = updateReport(nextReport);
      setScanState(getTemplateScanState(nextData));
      flashToast("تم فحص الأزرار محليًا بنفس منطق حساب القالب");
    } catch (error) {
      const raw = error?.message || "تعذر فحص الصفحة الحالية.";
      const friendly = raw.includes("Cannot access contents of url") || raw.includes("Missing host permission")
        ? "لا يملك الإكستنشن صلاحية قراءة هذه الصفحة بعد. أعد تحميل الإضافة من chrome://extensions ثم افتح تفاصيل الإضافة وتأكد أن Site access مسموح على الموقع الحالي. إذا كانت الصفحة ملفًا محليًا، فعّل Allow access to file URLs."
        : raw.includes("The extensions gallery cannot be scripted")
          ? "لا يمكن فحص صفحة Chrome Web Store أو صفحات المتصفح الداخلية. افتح موقعًا عاديًا ثم أعد الفحص."
          : raw;
      setErrorMessage(friendly);
      setScanState("error");
      flashToast("تعذر إكمال الفحص");
      console.error("Criterion 4 scan failed", error);
    }
  };

  const cancelScan = () => {
    setScanState("before");
    setScanProgress(0);
  };

  const ensureAuditScript = async (tabId) => {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/criterion4-audit.js"]
    });
  };

  const runHighlightIssues = async (issues, modeLabel, temporary = false) => {
    const activeIssues = (issues || []).filter(Boolean);
    if (!activeIssues.length) {
      flashToast("لا توجد مشاكل قابلة للتمييز");
      return false;
    }

    try {
      const tab = await getActiveTab();
      if (!canScanTab(tab)) throw new Error("Cannot access tab");
      await ensureAuditScript(tab.id);
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (items, label, isTemporary) => {
          if (!window.PlatformsCodeCriterion4) return 0;
          if (typeof window.PlatformsCodeCriterion4.highlightIssues === "function") {
            return window.PlatformsCodeCriterion4.highlightIssues(items, label, { temporary: isTemporary });
          }
          const first = items[0];
          return window.PlatformsCodeCriterion4.highlightIssue(first.selector, first.domPath, first.category) ? 1 : 0;
        },
        args: [activeIssues.map(issue => ({
          selector: issue.selector,
          domPath: issue.domPath,
          category: issue.category,
          id: issue.id
        })), modeLabel || "Criterion 4", temporary]
      });
      const count = result?.[0]?.result || 0;
      if (count > 0) {
        flashToast(`تم تمييز ${count} عنصر في الصفحة`);
        return true;
      }
      flashToast("تعذر العثور على العناصر في الصفحة الحالية");
      return false;
    } catch (_) {
      flashToast("تعذر تمييز العناصر في الصفحة الحالية");
      return false;
    }
  };

  const clearPageHighlights = async () => {
    try {
      const tab = await getActiveTab();
      if (!canScanTab(tab)) return;
      await ensureAuditScript(tab.id);
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => window.PlatformsCodeCriterion4?.clearHighlights?.()
      });
    } catch (_) {}
  };

  const locateIssue = async (target, issue) => {
    const selectedIssue = issue || (effectiveReport.issues || []).find(item => item.selector === target || item.domPath === target || item.target === target);
    if (!selectedIssue) return flashToast("لم يتم العثور على العنصر في التقرير");
    const ok = await runHighlightIssues([selectedIssue], selectedIssue.category, true);
    if (ok) flashToast("تم الانتقال إلى العنصر وتمييزه مؤقتًا");
  };

  const highlightAll = async () => {
    const activeIssues = effectiveReport.issues || [];
    if (!activeIssues.length) return flashToast("لا توجد مشاكل قابلة للتمييز");
    if (highlighted) {
      await clearPageHighlights();
      setHighlighted(false);
      flashToast("تم إخفاء التمييز");
      return;
    }
    const ok = await runHighlightIssues(activeIssues, "كل مشاكل معيار 4");
    setHighlighted(ok);
  };

  const highlightGroup = async (item) => {
    const groupIssues = (item.issues || []).filter(issue => !ignoredIssues[getIssueKey(issue)]);
    const ok = await runHighlightIssues(groupIssues, item.title || item.category);
    setHighlighted(ok || highlighted);
  };

  const ignoreIssue = (issue) => {
    const key = getIssueKey(issue);
    setIgnoredIssues(prev => ({ ...prev, [key]: true }));
    if (highlighted) {
      clearPageHighlights();
      setHighlighted(false);
    }
    flashToast("تم تجاهل المشكلة وإخفاؤها من القائمة والحساب");
  };

  const setSetting = (keyOrObject, value) => {
    if (typeof keyOrObject === "object") {
      setSettings(prev => ({ ...prev, ...keyOrObject }));
      return;
    }
    setSettings(prev => ({ ...prev, [keyOrObject]: value }));
  };

  const downloadBlob = (content, mime, filename) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1200);
  };

  const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

  const buildReportFilename = (format, currentReport) => {
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    let host = "page";
    try {
      const url = new URL(currentReport?.pageUrl || "");
      host = url.hostname || host;
    } catch (_) {}
    const safeHost = host.replace(/[^a-zA-Z0-9.-]+/g, "-").replace(/^-+|-+$/g, "") || "page";
    return `criterion-12-button-audit-${safeHost}-${stamp}.${format.toLowerCase()}`;
  };

  const buildCsvReport = (safeReport) => {
    const summary = safeReport.summary || {};
    const summaryRows = [
      ["section", "field", "value"],
      ["summary", "criterion", safeReport.criterion],
      ["summary", "criterion_name", safeReport.criterionName],
      ["summary", "page_url", safeReport.pageUrl],
      ["summary", "scan_date", safeReport.scanDate],
      ["summary", "score", safeReport.score],
      ["summary", "status", safeReport.status],
      ["summary", "total_elements_scanned", summary.totalElementsScanned],
      ["summary", "invalid_spacing_values", summary.invalidSpacingValues],
      ["summary", "hardcoded_spacing", summary.hardcodedSpacing],
      ["summary", "invalid_gap_values", summary.invalidGapValues],
      ["summary", "issues_count", summary.issuesCount],
      [],
      ["id", "requirement", "category", "severity", "confidence", "element_text", "selector", "description", "evidence", "expected", "actual"]
    ];
    const issueRows = (safeReport.issues || []).map(issue => [
      issue.id,
      issue.requirementId,
      issue.category,
      issue.severity,
      issue.confidence,
      issue.elementText,
      issue.selector || issue.domPath,
      issue.description,
      issue.evidence,
      issue.expected,
      issue.actual
    ]);
    const rows = summaryRows.concat(issueRows);
    return "\ufeff" + rows.map(row => row.map(value => `"${String(value ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  };

  const buildPrintableReportHtml = (safeReport) => {
    const dataForReport = buildStandardDataFromReport(safeReport);
    const summary = safeReport.summary || {};
    const issues = safeReport.issues || [];
    const statusLabel = dataForReport.status === "Passed" ? "امتثال كامل" : dataForReport.status === "Failed" ? "غير ممتثل" : "امتثال جزئي";
    const logoUrl = settings.extLogo ? chrome.runtime.getURL(settings.extLogo) : "";
    const rows = issues.length ? issues.map(issue => `
      <tr>
        <td>${escapeHtml(issue.id)}</td>
        <td>${escapeHtml(issue.category)}</td>
        <td>${escapeHtml(issue.severity)}</td>
        <td>${escapeHtml(issue.elementText || "—")}</td>
        <td dir="ltr">${escapeHtml(issue.selector || issue.domPath || "—")}</td>
        <td>${escapeHtml(issue.description || "—")}<br><small>${escapeHtml(issue.evidence || "—")}</small></td>
      </tr>`).join("") : `<tr><td colspan="6">لا توجد مشاكل مكتشفة في التقرير الحالي.</td></tr>`;

    return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>تقرير معيار 4</title>
<style>
  *{box-sizing:border-box} body{margin:0;background:#eef0f4;color:#0f172a;font-family:"IBM Plex Sans Arabic","Segoe UI",Tahoma,Arial,sans-serif;line-height:1.7} .page{max-width:980px;margin:24px auto;background:#fff;border:1px solid #e2e6ee;border-radius:14px;overflow:hidden} .head{display:flex;align-items:center;gap:16px;justify-content:space-between;padding:24px 28px;border-bottom:2px solid #0f172a}.brand{display:flex;align-items:center;gap:12px}.logo{width:110px;height:48px;object-fit:contain;border:1px solid #e2e6ee;border-radius:10px;background:#fff}.title h1{margin:0;font-size:22px}.title div{font-size:12px;color:#64748b}.score{display:flex;gap:18px;align-items:center;margin:22px 28px;padding:18px;border:1px solid #e2e6ee;border-radius:12px;background:#f6f8fb}.pct{font-size:42px;font-weight:800;color:#b45309}.pct.pass{color:#047857}.pct.fail{color:#b91c1c}.section{padding:0 28px 24px}.section h2{font-size:14px;color:#64748b;border-bottom:1px solid #e2e6ee;padding-bottom:6px;margin:24px 0 10px;text-transform:uppercase;letter-spacing:.06em} dl{display:grid;grid-template-columns:170px 1fr;gap:6px 14px;margin:0} dt{color:#64748b} dd{margin:0;color:#0f172a} table{width:100%;border-collapse:collapse;margin-top:8px;table-layout:fixed} th,td{border-bottom:1px solid #e2e6ee;padding:8px 10px;text-align:start;vertical-align:top;font-size:12px;word-break:break-word} th{background:#f6f8fb;color:#475569;font-weight:700}.printbar{position:sticky;top:0;background:#0f172a;color:#fff;padding:10px 16px;display:flex;gap:8px;align-items:center;justify-content:space-between}.printbar button{border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}@media print{body{background:#fff}.page{margin:0;max-width:none;border:0;border-radius:0}.printbar{display:none}.section{break-inside:auto} tr{break-inside:avoid}}
</style>
</head>
<body>
<div class="printbar"><span>تقرير جاهز للطباعة أو الحفظ كـ PDF</span><button onclick="window.print()">طباعة / حفظ PDF</button></div>
<main class="page">
  <header class="head">
    <div class="brand">${logoUrl ? `<img class="logo" src="${escapeHtml(logoUrl)}" alt="${escapeHtml(settings.extName)}">` : ""}<div class="title"><h1>تقرير فحص الامتثال</h1><div>${escapeHtml(settings.extName)} · معيار 4 — ${escapeHtml(dataForReport.title)}</div></div></div>
    <div style="font-size:12px;color:#64748b;text-align:end">${escapeHtml(dataForReport.scanDateFormatted || "—")}<br>الحالة: ${escapeHtml(statusLabel)}</div>
  </header>
  <div class="score"><div class="pct ${dataForReport.status === "Passed" ? "pass" : dataForReport.status === "Failed" ? "fail" : ""}">${escapeHtml(dataForReport.score)}%</div><div><strong>${escapeHtml(statusLabel)}</strong><br><span>تم فحص ${escapeHtml(summary.totalElementsScanned || 0)} عنصر. عدد المشاكل الحالية بعد التجاهل: ${escapeHtml(summary.issuesCount || 0)}.</span></div></div>
  <section class="section"><h2>معلومات الفحص</h2><dl><dt>رقم المعيار</dt><dd>${escapeHtml(safeReport.criterion)}</dd><dt>اسم المعيار</dt><dd>${escapeHtml(safeReport.criterionName)}</dd><dt>رابط الصفحة</dt><dd dir="ltr">${escapeHtml(safeReport.pageUrl)}</dd><dt>وقت الفحص</dt><dd>${escapeHtml(dataForReport.scanDateFormatted || "—")}</dd><dt>إجمالي العناصر المفحوصة</dt><dd>${escapeHtml(summary.totalElementsScanned || 0)}</dd><dt>قيم مسافات غير معتمدة</dt><dd>${escapeHtml(summary.invalidSpacingValues || 0)}</dd><dt>قيم مبرمجة ثابتة (Hardcoded)</dt><dd>${escapeHtml(summary.hardcodedSpacing || 0)}</dd><dt>مسافات Gap غير صحيحة</dt><dd>${escapeHtml(summary.invalidGapValues || 0)}</dd></dl></section>
  <section class="section"><h2>توزيع المشاكل</h2><table><thead><tr><th>الفئة</th><th>العدد</th></tr></thead><tbody><tr><td>Invalid Spacing Value</td><td>${escapeHtml(summary.invalidSpacingValues || 0)}</td></tr><tr><td>Hardcoded Spacing</td><td>${escapeHtml(summary.hardcodedSpacing || 0)}</td></tr><tr><td>Invalid Gap Value</td><td>${escapeHtml(summary.invalidGapValues || 0)}</td></tr></tbody></table></section>
  <section class="section"><h2>تفاصيل المشاكل</h2><table><thead><tr><th>ID</th><th>الفئة</th><th>الشدة</th><th>العنصر</th><th>المحدد</th><th>الوصف</th></tr></thead><tbody>${rows}</tbody></table></section>
</main>
<script>setTimeout(function(){ window.focus(); window.print(); }, 350);</script>
</body>
</html>`;
  };

  const openPrintablePdfReport = (safeReport) => {
    const html = buildPrintableReportHtml(safeReport);
    const printWindow = window.open("", "_blank", "width=980,height=720");
    if (!printWindow) {
      window.print();
      return false;
    }
    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
    return true;
  };

  const handleReportDownload = (format, currentReport) => {
    const safeReport = currentReport || effectiveReport;
    const selectedFormat = format || settings.format || "PDF";
    try {
      if (selectedFormat === "JSON") {
        downloadBlob(JSON.stringify(safeReport, null, 2), "application/json;charset=utf-8", buildReportFilename("json", safeReport));
        flashToast("تم تنزيل تقرير JSON");
      } else if (selectedFormat === "CSV") {
        downloadBlob(buildCsvReport(safeReport), "text/csv;charset=utf-8", buildReportFilename("csv", safeReport));
        flashToast("تم تنزيل تقرير CSV");
      } else {
        const opened = openPrintablePdfReport(safeReport);
        flashToast(opened ? "تم فتح تقرير PDF للطباعة أو الحفظ" : "تم فتح نافذة الطباعة للتقرير");
      }
    } catch (error) {
      console.error("Report export failed", error);
      flashToast("تعذر إصدار التقرير، حاول مرة أخرى");
    }
  };

  const [isUploading, setIsUploading] = useState(false);
  const [isSubmittingComplaint, setIsSubmittingComplaint] = useState(false);

  const uploadReportToEmtithal = async (currentReport) => {
    setIsUploading(true);
    try {
      const payload = {
        p_api_key: "emt_live_sk_4p5cbq9qrz78b0czk5urfonq",
        p_platform_url: currentReport.pageUrl || "",
        p_report_data: currentReport,
        p_score: currentReport.score || 0
      };

      const response = await fetch('https://wsexgnphxcuceyqquhzv.supabase.co/rest/v1/rpc/submit_audit_report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzZXhnbnBoeGN1Y2V5cXF1aHp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyMTU3NTMsImV4cCI6MjA5NDc5MTc1M30.0u9VgV4sPMs-PSdsBkc0cgW4yc-9wTXQkbbaKmfJ3QA',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzZXhnbnBoeGN1Y2V5cXF1aHp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyMTU3NTMsImV4cCI6MjA5NDc5MTc1M30.0u9VgV4sPMs-PSdsBkc0cgW4yc-9wTXQkbbaKmfJ3QA'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Failed to upload report");

      flashToast("تم رفع التقرير إلى منصة امتثال بنجاح!");
      setView("browser");
    } catch (err) {
      console.error("Upload failed", err);
      flashToast("فشل الرفع: " + err.message);
    } finally {
      setIsUploading(false);
    }
  };

  const submitComplaintToEmtithal = async (violationText) => {
    setIsSubmittingComplaint(true);
    try {
      const tab = await getActiveTab();
      const pageUrl = getTabUrl(tab);

      const payload = {
        p_api_key: "emt_live_sk_4p5cbq9qrz78b0czk5urfonq",
        p_url: pageUrl || "",
        p_violation: violationText
      };

      const response = await fetch('https://wsexgnphxcuceyqquhzv.supabase.co/rest/v1/rpc/submit_complaint', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzZXhnbnBoeGN1Y2V5cXF1aHp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyMTU3NTMsImV4cCI6MjA5NDc5MTc1M30.0u9VgV4sPMs-PSdsBkc0cgW4yc-9wTXQkbbaKmfJ3QA',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndzZXhnbnBoeGN1Y2V5cXF1aHp2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyMTU3NTMsImV4cCI6MjA5NDc5MTc1M30.0u9VgV4sPMs-PSdsBkc0cgW4yc-9wTXQkbbaKmfJ3QA'
        },
        body: JSON.stringify(payload)
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Failed to submit complaint");

      flashToast("تم إرسال البلاغ إلى منصة امتثال بنجاح!");
      setView("browser");
    } catch (err) {
      console.error("Complaint failed", err);
      flashToast("فشل إرسال البلاغ: تأكد من صحة المفتاح (API Key)");
    } finally {
      setIsSubmittingComplaint(false);
    }
  };

  if (isCheckingBlock) {
    return (
      <div className="extension-root" style={{display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#f8fafc'}}>
        <div style={{color: '#64748b'}}>جاري التحقق من حالة الإضافة...</div>
      </div>
    );
  }

  if (isAppBlocked) {
    return (
      <div className="extension-root" dir="rtl" style={{display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: '#fef2f2', padding: 24, textAlign: 'center'}}>
        <div>
          <div style={{color: '#ef4444', marginBottom: 16}}>
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>
          </div>
          <h2 style={{color: '#991b1b', margin: '0 0 8px 0', fontSize: '18px'}}>تم إيقاف هذه الإضافة</h2>
          <p style={{color: '#b91c1c', margin: 0, fontSize: '14px', lineHeight: 1.5}}>تم إيقاف مفتاح الربط الخاص بهذه الإضافة من قِبل إدارة منصة امتثال. لا يمكنك استخدام الإضافة في الوقت الحالي.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="extension-root" data-screen-label="Criterion 4 Extension">
      <div className="extension-panel-shell">
        {view === "browser" && (
          <SidePanel
            state={scanState}
            onScan={startScan}
            onCancel={cancelScan}
            highlighted={highlighted}
            onToggleHighlight={highlightAll}
            onOpenSettings={() => setView("options")}
            onOpenReport={() => setView("report")}
            onOpenFlag={() => setView("complaint")}
            onLocateElement={highlightGroup}
            onLocateOne={locateIssue}
            extName={settings.extName}
            extLogo={settings.extLogo}
            extGlyph={settings.extGlyph}
            scanProgress={scanProgress}
            ignoredIssues={ignoredIssues}
            onIgnoreIssue={ignoreIssue}
            data={standardData}
            errorMessage={errorMessage}
          />
        )}

        {view === "options" && (
          <OptionsPage
            settings={settings}
            onChange={setSetting}
            onSave={() => {
              if (chrome?.storage?.local) {
                chrome.storage.local.set({ criterion4Settings: settings }).catch(() => {});
              }
              flashToast("تم حفظ الإعدادات بنجاح");
            }}
            onReset={() => {
              setSettings(DEFAULT_SETTINGS);
              if (chrome?.storage?.local) {
                chrome.storage.local.set({ criterion4Settings: DEFAULT_SETTINGS }).catch(() => {});
              }
            }}
            onBack={() => setView("browser")}
          />
        )}

        {view === "report" && (
          <ReportPreview
            format={settings.format}
            onChangeFormat={(format) => setSetting("format", format)}
            onBack={() => setView("browser")}
            onDownload={handleReportDownload}
            onUploadToEmtithal={uploadReportToEmtithal}
            isUploading={isUploading}
            settings={settings}
            report={effectiveReport}
          />
        )}

        {view === "complaint" && (
          <ComplaintForm
            onBack={() => setView("browser")}
            onSubmit={submitComplaintToEmtithal}
            isSubmitting={isSubmittingComplaint}
          />
        )}
      </div>

      {toast && <div className="toast">{SP_Icon.check} {toast}</div>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<ExtensionShell />);
