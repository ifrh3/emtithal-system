const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const babelPath = path.join(root, "vendor", "babel-standalone.min.js");
const sandbox = {};
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(babelPath, "utf8"), sandbox);

const files = [
  "src/data.js",
  "src/side-panel.jsx",
  "src/options-page.jsx",
  "src/report-preview.jsx",
  "src/extension-app.jsx"
];

const banner = `// Generated bundle for the MV3 side panel.\n// Source files are kept under src/ for editability.\n`;
const chunks = [banner];
for (const file of files) {
  const sourcePath = path.join(root, file);
  const source = fs.readFileSync(sourcePath, "utf8");
  const transformed = sandbox.Babel.transform(source, {
    presets: ["react"],
    comments: true,
    compact: false
  }).code;
  chunks.push(`\n// ---- ${file} ----\n(function(){\n${transformed}\n})();\n`);
}

const outDir = path.join(root, "dist");
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, "criterion4-extension.bundle.js"), chunks.join("\n"));
console.log("Built dist/criterion4-extension.bundle.js");
