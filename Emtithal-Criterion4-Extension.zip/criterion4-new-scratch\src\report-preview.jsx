// Report Preview view for Criterion 4 Button audit
function ReportPreview({ format, onChangeFormat, onBack, onDownload, onUploadToEmtithal, isUploading, settings, report: inputReport }) {
  const report = inputReport || getCurrentCriterion4Report();
  const data = buildStandardDataFromReport(report);
  const summary = report.summary || EMPTY_SUMMARY;
  const issues = report.issues || [];
  const ratio = typeof data.score === "number" ? data.score : 100;
  const statusLabel = data.status === "Passed" ? "امتثال كامل" : data.status === "Failed" ? "غير ممتثل" : "امتثال جزئي";
  const statusClass = data.status === "Passed" ? "success" : data.status === "Failed" ? "fail" : "partial";

  const csvEscape = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const csvRows = [
    ["id", "requirement", "category", "severity", "confidence", "checks", "element_text", "accessible_name", "selector", "description", "evidence", "expected", "actual"],
    ...issues.map(issue => [
      issue.id,
      issue.requirement,
      issue.category,
      issue.severity,
      issue.confidence,
      (issue.checks || []).map(check => check.code).join("|"),
      issue.elementText,
      issue.accessibleName,
      issue.selector || issue.domPath,
      issue.description,
      issue.evidence,
      issue.expected,
      issue.actual
    ])
  ].map(row => row.map(csvEscape).join(",")).join("\n");

  return (
    <div className="report-shell" data-screen-label="Report Preview">
      <div className="report-page">
        <div className="report-toolbar" style={{flexDirection: "column", alignItems: "stretch", gap: 12}}>
          <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", width: "100%"}}>
            <div className="left" style={{display: "flex", alignItems: "center", gap: 8}}>
              <button className="btn" onClick={onBack}>← العودة</button>
              <span style={{fontWeight: 600}}>معاينة التقرير</span>
            </div>
            <div className="report-fmt-pick">
              {["PDF","CSV","JSON"].map(f => (
                <button key={f} className={"chip" + (format === f ? " active" : "")} onClick={() => onChangeFormat(f)}>{f}</button>
              ))}
            </div>
          </div>
          
          <div style={{display: "flex", gap: 8, width: "100%"}}>
            <button className="btn" style={{flex: 1, backgroundColor: '#059669', color: '#fff', border: 'none', fontWeight: 600}} onClick={() => onUploadToEmtithal(report)} disabled={isUploading}>
              {isUploading ? "جاري الرفع..." : "رفع لمنصة امتثال"}
            </button>
            <button className="btn primary" style={{flex: 1, fontWeight: 600}} onClick={() => onDownload(format, report)}>
              تنزيل التقرير {format}
            </button>
          </div>
        </div>

        {format === "PDF" && (
          <div className="report-doc">
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",borderBottom:"2px solid var(--text)",paddingBottom:14,marginBottom:18}}>
              <div>
                <h1>تقرير فحص الامتثال</h1>
                <div className="sub">{settings.extName} · معيار 4 — {data.title}</div>
              </div>
              <div style={{textAlign:"end",fontSize:11,color:"var(--text-3)"}}>
                <div>{data.scanDateFormatted || "—"}</div>
                <div>الحالة: {report.status}</div>
              </div>
            </div>

            <div className="summary-card">
              <div className={"pct " + statusClass}>{ratio}%</div>
              <div style={{flex:1}}>
                <div style={{fontSize:14,fontWeight:700,color:"var(--text)"}}>{statusLabel}</div>
                <div style={{fontSize:12,marginTop:2}}>تم فحص {summary.totalElementsScanned || 0} عنصر. عدد المشاكل الحالية بعد التجاهل: {summary.issuesCount || 0}.</div>
              </div>
            </div>

            <h2>معلومات الفحص</h2>
            <dl>
              <dt>اسم الإضافة</dt><dd>{settings.extName}</dd>
              <dt>رقم المعيار</dt><dd>{report.criterion}</dd>
              <dt>اسم المعيار</dt><dd>{report.criterionName}</dd>
              <dt>رابط الصفحة</dt><dd style={{fontFamily:"ui-monospace, monospace",direction:"ltr",textAlign:"start"}}>{report.pageUrl}</dd>
              <dt>وقت الفحص</dt><dd>{data.scanDateFormatted}</dd>
              <dt>إجمالي العناصر المفحوصة</dt><dd>{summary.totalElementsScanned || 0}</dd>
              <dt>قيم مسافات غير معتمدة</dt><dd>{summary.invalidSpacingValues || 0}</dd>
              <dt>قيم مسافات مبرمجة ثابتة (Hardcoded)</dt><dd>{summary.hardcodedSpacing || 0}</dd>
              <dt>مسافات Gap غير صحيحة</dt><dd>{summary.invalidGapValues || 0}</dd>
              <dt>إجمالي الأخطاء</dt><dd>{summary.issuesCount || 0}</dd>
            </dl>

            <h2>الملخص التنفيذي</h2>
            <p style={{margin:0}}>تم فحص الصفحة مقابل معيار «{data.title}». النتيجة الحالية {ratio}% وفق منطق القالب: عدد متطلبات معيار 4 المجتازة من أصل 3. يقتصر الفحص على الهوامش والمسافات الداخلية والمسافات البينية (Gaps) فقط.</p>

            <h2>توزيع المشاكل</h2>
            <table>
              <thead>
                <tr><th>الفئة</th><th>العدد</th></tr>
              </thead>
              <tbody>
                <tr><td>Invalid Spacing Value</td><td>{summary.invalidSpacingValues || 0}</td></tr>
                <tr><td>Hardcoded Spacing</td><td>{summary.hardcodedSpacing || 0}</td></tr>
                <tr><td>Invalid Gap Value</td><td>{summary.invalidGapValues || 0}</td></tr>
              </tbody>
            </table>

            <h2>تفاصيل المشاكل</h2>
            <table>
              <thead>
                <tr><th>ID</th><th>الفئة</th><th>الشدة</th><th>العنصر</th><th>الدليل</th></tr>
              </thead>
              <tbody>
                {issues.length === 0 && <tr><td colSpan="5">لا توجد مشاكل مكتشفة.</td></tr>}
                {issues.map(iss => (
                  <tr key={iss.id}>
                    <td>{iss.id}</td>
                    <td>{iss.category}</td>
                    <td>{iss.severity}</td>
                    <td>{iss.accessibleName || iss.elementText || "—"}</td>
                    <td style={{fontSize:11,color:"var(--text-3)"}}>{iss.evidence}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <h2>المرجع</h2>
            <p style={{margin:0,direction:"ltr",textAlign:"start",fontFamily:"ui-monospace, monospace",fontSize:12}}>{data.reference}</p>
          </div>
        )}

        {format === "CSV" && (
          <div className="report-doc" style={{fontFamily:"ui-monospace, Menlo, monospace",direction:"ltr",textAlign:"start",fontSize:12,whiteSpace:"pre",overflow:"auto"}}>
{csvRows}
          </div>
        )}

        {format === "JSON" && (
          <div className="report-doc" style={{fontFamily:"ui-monospace, Menlo, monospace",direction:"ltr",textAlign:"start",fontSize:12,whiteSpace:"pre-wrap",overflow:"auto"}}>
{JSON.stringify(report, null, 2)}
          </div>
        )}
      </div>
    </div>
  );
}

window.ReportPreview = ReportPreview;
