window.PlatformsCodeCriterion4 = (function() {
  let highlightOverlay = null;

  function createHighlightOverlay() {
    if (!highlightOverlay) {
      highlightOverlay = document.createElement("div");
      highlightOverlay.id = "dga-criterion4-highlights";
      highlightOverlay.style.cssText = "position:absolute; top:0; left:0; width:100%; height:100%; pointer-events:none; z-index:2147483647;";
      document.body.appendChild(highlightOverlay);
    }
    return highlightOverlay;
  }

  function clearHighlights() {
    if (highlightOverlay) {
      highlightOverlay.innerHTML = "";
    }
  }

  function highlightIssue(selector, domPath, category, options = {}) {
    const el = document.querySelector(selector) || document.evaluate(domPath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    if (!el) return false;
    
    const rect = el.getBoundingClientRect();
    const overlay = createHighlightOverlay();
    
    const box = document.createElement("div");
    const isTemp = options.temporary;
    const color = category === "Invalid Spacing Value" ? "#E5E500" : category === "Hardcoded Spacing" ? "#E49EDD" : "#94DCF8";
    
    box.style.cssText = `
      position: absolute;
      top: ${window.scrollY + rect.top}px;
      left: ${window.scrollX + rect.left}px;
      width: ${rect.width}px;
      height: ${rect.height}px;
      border: 3px solid ${color};
      background: rgba(229, 229, 0, 0.1);
      box-sizing: border-box;
      border-radius: 4px;
      transition: all 0.3s ease;
      box-shadow: 0 0 10px ${color};
    `;
    
    overlay.appendChild(box);
    
    if (isTemp) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => box.remove(), 2500);
    }
    return true;
  }

  function highlightIssues(issues, label, options) {
    if (!options?.temporary) clearHighlights();
    let count = 0;
    for (const issue of issues) {
      if (highlightIssue(issue.selector, issue.domPath, issue.category, options)) {
        count++;
      }
    }
    return count;
  }

  function getDomPath(el) {
    const stack = [];
    while (el.parentNode != null) {
      let count = 0;
      for (let i = 0; i < el.parentNode.childNodes.length; i++) {
        const sibling = el.parentNode.childNodes[i];
        if (sibling === el) {
          stack.unshift(el.tagName.toLowerCase() + (count > 0 ? `:nth-child(${count + 1})` : ""));
          break;
        }
        if (sibling.nodeType === 1 && sibling.tagName === el.tagName) count++;
      }
      el = el.parentNode;
    }
    return stack.join(" > ");
  }

  function isMultipleOf(val, bases) {
    if (!val || val === "0px" || val === "auto" || val === "normal") return true;
    const px = parseFloat(val);
    if (isNaN(px) || px === 0) return true;
    return bases.some(b => px % b === 0);
  }

  function getPixelValue(val) {
    if (!val || val === "0px" || val === "auto" || val === "normal") return null;
    const px = parseFloat(val);
    if (isNaN(px)) return null;
    return px;
  }

  function runAudit(config) {
    clearHighlights();
    
    const issues = [];
    let spacingViolations = 0;
    let layoutViolations = 0;
    let invalidSpacingValues = 0;
    let hardcodedSpacing = 0;
    let invalidGapValues = 0;
    let issueIdCounter = 1;

    // We scan common structural elements, excluding svg and small wrappers
    const elements = document.querySelectorAll("div, section, article, header, footer, nav, aside, main, ul, li, form, fieldset, button, input");
    
    elements.forEach(el => {
      // Ignore hidden elements
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      const style = window.getComputedStyle(el);
      const inlineStyle = el.style;

      // 1. Check computed margin & padding for 4/8 multiples
      const sides = ["Top", "Right", "Bottom", "Left"];
      const spaces = [];
      sides.forEach(side => {
        spaces.push({ prop: `margin${side}`, val: style[`margin${side}`] });
        spaces.push({ prop: `padding${side}`, val: style[`padding${side}`] });
      });

      const allowedMultiples = [4, 8];
      
      let elementHasIssue = false;

      spaces.forEach(space => {
        if (!isMultipleOf(space.val, allowedMultiples)) {
          issues.push({
            id: `C4-ISSUE-${issueIdCounter++}`,
            requirementId: "req-1",
            category: "Invalid Spacing Value",
            severity: "High",
            confidence: "High",
            elementText: el.tagName.toLowerCase() + (el.className ? `.${el.className.split(" ")[0]}` : ""),
            selector: getDomPath(el),
            domPath: getDomPath(el),
            description: `يجب أن تكون المسافات من مضاعفات الـ 4 أو 8. تم اكتشاف قيمة غير صالحة.`,
            expected: "مضاعفات 4px أو 8px",
            actual: `${space.prop}: ${space.val}`,
            evidence: `Computed style ${space.prop} is ${space.val}`
          });
          invalidSpacingValues++;
          elementHasIssue = true;
        }

        // 2. Check inline styles for hardcoded pixel values (which usually violates tokens)
        if (inlineStyle[space.prop] && inlineStyle[space.prop].includes("px") && !inlineStyle[space.prop].includes("var(")) {
          issues.push({
            id: `C4-ISSUE-${issueIdCounter++}`,
            requirementId: "req-2",
            category: "Hardcoded Spacing",
            severity: "Medium",
            confidence: "High",
            elementText: el.tagName.toLowerCase() + (el.className ? `.${el.className.split(" ")[0]}` : ""),
            selector: getDomPath(el),
            domPath: getDomPath(el),
            description: `تم العثور على مسافات مضمنة (Inline style) مبرمجة برقم ثابت بدلاً من استخدام رموز التصميم (Tokens).`,
            expected: `var(--spacing-...)`,
            actual: `${space.prop}: ${inlineStyle[space.prop]}`,
            evidence: `Inline style ${space.prop} is hardcoded to ${inlineStyle[space.prop]}`
          });
          hardcodedSpacing++;
          elementHasIssue = true;
        }
      });

      if (elementHasIssue) spacingViolations++;

      // 3. Check Flex/Grid Gap
      if (style.display === "flex" || style.display === "grid") {
        const gapVal = style.gap || style.rowGap || style.columnGap;
        if (!isMultipleOf(gapVal, allowedMultiples)) {
          issues.push({
            id: `C4-ISSUE-${issueIdCounter++}`,
            requirementId: "req-3",
            category: "Invalid Gap Value",
            severity: "High",
            confidence: "High",
            elementText: el.tagName.toLowerCase() + (el.className ? `.${el.className.split(" ")[0]}` : ""),
            selector: getDomPath(el),
            domPath: getDomPath(el),
            description: `قيمة الفراغ (gap) في الـ ${style.display} يجب أن تكون من مضاعفات 4 أو 8.`,
            expected: "مضاعفات 4px أو 8px",
            actual: `gap: ${gapVal}`,
            evidence: `Computed gap is ${gapVal}`
          });
          invalidGapValues++;
          layoutViolations++;
        }
      }
    });

    // Calculate score
    const req1Pass = invalidSpacingValues === 0;
    const req2Pass = hardcodedSpacing === 0;
    const req3Pass = invalidGapValues === 0;
    const passedReqs = [req1Pass, req2Pass, req3Pass].filter(Boolean).length;
    const totalReqs = 3;
    const score = Math.round((passedReqs / totalReqs) * 100);

    const report = {
      criterion: "4",
      criterionName: "المسافات والتخطيط (Layout & Spacing)",
      pageUrl: window.location.href,
      scanDate: new Date().toISOString(),
      score: score,
      status: score === 100 ? "Passed" : score === 0 ? "Failed" : "Partial",
      issues: issues,
      summary: {
        totalElementsScanned: elements.length,
        spacingViolations,
        layoutViolations,
        elementsWithIssues: spacingViolations + layoutViolations,
        invalidSpacingValues,
        hardcodedSpacing,
        invalidGapValues,
        issuesCount: issues.length
      }
    };

    return report;
  }

  return { runAudit, highlightIssues, highlightIssue, clearHighlights };
})();
