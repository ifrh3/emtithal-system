// Root App — orchestrates browser shell, side panel, mock page, modals, options
const { useState, useEffect, useRef } = React;

const DEFAULT_SETTINGS = /*EDITMODE-BEGIN*/{
  "extName": "فحص الامتثال",
  "extGlyph": "ف",
  "extLogo": "assets/images/emttthal-logo.png",
  "lang": "ar",
  "theme": "light",
  "notifications": true,
  "autoScroll": true,
  "clearOnClose": true,
  "format": "PDF",
  "incLink": true,
  "incTime": true,
  "incDetails": true,
  "incElements": true,
  "incRecs": true,
  "incExec": true
}/*EDITMODE-END*/;

const STATES = [
  { id: "before", label: "قبل الفحص" },
  { id: "scanning", label: "أثناء الفحص" },
  { id: "full", label: "امتثال 100%" },
  { id: "partial", label: "امتثال جزئي" },
  { id: "none", label: "غير ممتثل" },
  { id: "error", label: "خطأ" },
  { id: "n/a", label: "غير قابل للتطبيق" }
];

function StateSwitcher({ current, onChange }) {
  return (
    <div className="state-switcher">
      <span className="label">حالة العرض</span>
      {STATES.map(s => (
        <button key={s.id} className={current === s.id ? "active" : ""} onClick={() => onChange(s.id)}>
          {s.label}
        </button>
      ))}
    </div>
  );
}

// Issue Report modal
function IssueReportModal({ onClose, settings, scanState }) {
  const [note, setNote] = useState("");
  const [sent, setSent] = useState(false);

  if (sent) {
    return (
      <div className="modal-backdrop" onClick={onClose}>
        <div className="modal" onClick={e => e.stopPropagation()} style={{ width: 420 }}>
          <div className="modal-body" style={{ textAlign: "center", padding: "32px 24px" }}>
            <div style={{ width: 48, height: 48, borderRadius: "50%", background: "var(--success-soft)", color: "var(--success)", display: "grid", placeItems: "center", margin: "0 auto 12px" }}>
              {SP_Icon.bigCheck}
            </div>
            <h3 style={{ margin: 0, fontSize: 16 }}>تم إرسال البلاغ</h3>
            <p style={{ fontSize: 13, color: "var(--text-3)", marginTop: 8, lineHeight: 1.6 }}>شكرًا لمساعدتنا على تحسين {settings.extName}. سنراجع البلاغ ونتواصل معك إذا لزم الأمر.</p>
          </div>
          <div className="modal-foot">
            <button className="btn primary" onClick={onClose}>إغلاق</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-head">
          <h3>إبلاغ عن مشكلة</h3>
          <button className="sp-iconbtn" onClick={onClose}>{SP_Icon.close}</button>
        </div>
        <div className="modal-body">
          <p style={{ marginTop: 0, fontSize: 12, color: "var(--text-3)" }}>
            ساعدنا على تحسين الإضافة بالإبلاغ عن أي خلل في الفحص أو نتيجة غير دقيقة. الحقول التالية معبأة تلقائيًا من جلسة الفحص.
          </p>
          <div className="field">
            <label>رابط الصفحة</label>
            <input readOnly value={STANDARD_DATA.pageUrl} />
          </div>
          <div className="field">
            <label>رقم المعيار</label>
            <input readOnly value={`${STANDARD_DATA.number} — ${STANDARD_DATA.title}`} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div className="field">
              <label>وقت الفحص</label>
              <input readOnly value="09 مايو 2026، 02:30 مساءً" />
            </div>
            <div className="field">
              <label>نتيجة الفحص</label>
              <input readOnly value={
                scanState === "full" ? "100% — امتثال كامل" :
                  scanState === "partial" ? "67% — امتثال جزئي" :
                    scanState === "none" ? "0% — غير ممتثل" :
                      "—"
              } />
            </div>
          </div>
          <div className="field">
            <label>ملاحظتك <span style={{ color: "var(--text-3)", fontWeight: 400 }}>(اختياري)</span></label>
            <textarea
              placeholder="مثال: المعيار الفرعي يعتبر عنصر «X» مخالفًا، لكنه يستخدم الرمز المعتمد..."
              value={note}
              onChange={e => setNote(e.target.value)}
            />
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={onClose}>إلغاء</button>
          <button className="btn primary" onClick={() => setSent(true)}>إرسال البلاغ</button>
        </div>
      </div>
    </div>
  );
}

function ResetModal({ onConfirm, onCancel }) {
  return (
    <div className="modal-backdrop" onClick={onCancel}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ width: 420 }}>
        <div className="modal-head">
          <h3>تأكيد إعادة التعيين</h3>
          <button className="sp-iconbtn" onClick={onCancel}>{SP_Icon.close}</button>
        </div>
        <div className="modal-body">
          هل أنت متأكد من إعادة جميع الإعدادات إلى الوضع الافتراضي؟ لن يتم استرجاع التخصيصات السابقة.
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={onCancel}>إلغاء</button>
          <button className="btn danger" onClick={onConfirm}>إعادة التعيين</button>
        </div>
      </div>
    </div>
  );
}

function App() {
  // Tweaks integration
  const [settings, setTweak] = useTweaks(DEFAULT_SETTINGS);

  // App view: 'browser' | 'options' | 'report'
  const [view, setView] = useState("browser");

  // Scan state
  const [scanState, setScanState] = useState("before");
  const [scanProgress, setScanProgress] = useState(0);
  const [highlighted, setHighlighted] = useState(false);
  const [highlightTargets, setHighlightTargets] = useState({}); // map of data-scan key -> true
  const [ignoredIssues, setIgnoredIssues] = useState({});

  // Modals & toasts
  const [showFlag, setShowFlag] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);

  const flashToast = (msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2400);
  };

  // Scan flow
  useEffect(() => {
    if (scanState !== "scanning") return;
    setScanProgress(0);
    let i = 0;
    const tick = () => {
      i += 1;
      if (i <= 4) {
        setScanProgress(i);
        if (i < 4) setTimeout(tick, 700);
        else setTimeout(() => setScanState("full"), 600);
      }
    };
    setTimeout(tick, 500);
  }, [scanState]);

  // When toggling state from switcher, reset UI side-effects
  const switchState = (s) => {
    setScanState(s);
    setHighlighted(false);
    setHighlightTargets({});
    setIgnoredIssues({});
  };

  const startScan = () => {
    setHighlighted(false);
    setHighlightTargets({});
    setIgnoredIssues({});
    setScanState("scanning");
  };
  const cancelScan = () => setScanState("before");

  const toggleHighlight = () => {
    if (!highlighted) {
      // turn on all fail issues
      const t = {};
      STANDARD_DATA.subCriteria.forEach(s => {
        if (s.status === "fail") {
          (s.issues || [])
            .filter(i => !ignoredIssues[getIssueKey(i)])
            .forEach(i => {
              const m = i.target.match(/data-scan='([^']+)'/);
              if (m) t[m[1]] = true;
            });
        }
      });
      setHighlightTargets(t);
      setHighlighted(true);
      flashToast("تم تمييز المشاكل داخل الصفحة");
    } else {
      setHighlightTargets({});
      setHighlighted(false);
      flashToast("تم إخفاء التمييز");
    }
  };

  const highlightOne = (item) => {
    const t = {};
    (item.issues || []).forEach(i => {
      const m = i.target.match(/data-scan='([^']+)'/);
      if (m) t[m[1]] = true;
    });
    setHighlightTargets(t);
    setHighlighted(true);
    flashToast(`تم تمييز عناصر معيار «${item.title}»`);
  };
  const ignoreIssue = (issue) => {
    const key = getIssueKey(issue);

    setIgnoredIssues((prev) => ({
      ...prev,
      [key]: true
    }));

    const match = issue.target?.match(/data-scan='([^']+)'/);

    if (match) {
      setHighlightTargets((prev) => {
        const next = { ...prev };
        delete next[match[1]];
        return next;
      });
    }

    flashToast("تم تجاهل المشكلة وتحديث نسبة الامتثال");
  };
  const locateOne = (target) => {
    const m = target.match(/data-scan='([^']+)'/);
    if (m) {
      setHighlightTargets({ [m[1]]: true });
      setHighlighted(true);
      // attempt smooth scroll on first matching element
      setTimeout(() => {
        const el = document.querySelector(`[data-scan='${m[1]}']`);
        if (el && el.scrollIntoView) {
          // scroll within content container
          const container = document.querySelector(".bw-content");
          if (container) {
            const rect = el.getBoundingClientRect();
            const cRect = container.getBoundingClientRect();
            container.scrollBy({ top: rect.top - cRect.top - 80, behavior: "smooth" });
          }
        }
      }, 50);
      flashToast("تم الانتقال إلى العنصر");
    }
  };

  const handleReportDownload = () => {
    flashToast(`تم تنزيل التقرير (${settings.format}) — وهمي`);
  };

  return (
    <>
      <div className="app-shell" data-screen-label="App Shell">
        <div className="browser">
          {/* Browser chrome */}
          <div className="bw-chrome">
            <div className="bw-traffic"><span></span><span></span><span></span></div>
            <div className="bw-tabs">
              <div className="bw-tab active">
                <div className="dot">و</div>
                {settings.extName === "فحص الامتثال" ? "بوابة الخدمات الرقمية" : "Services Portal"}
              </div>
            </div>
            <div className="bw-address">
              <span className="lock">🔒</span>
              {STANDARD_DATA.pageUrl}
            </div>
            <div className="bw-icons">
              <span className="ext-pill">
                <span className="pulse"></span>
                {settings.extName}
              </span>
            </div>
          </div>

          <div className="bw-body">
            {/* Main content */}
            <div className="bw-content">
              {view === "browser" && <MockGovPage highlights={highlightTargets} />}
              {view === "options" && (
                <OptionsPage
                  settings={settings}
                  onChange={(s) => setTweak(s)}
                  onSave={() => flashToast("تم حفظ الإعدادات")}
                  onReset={() => setShowReset(true)}
                  onBack={() => setView("browser")}
                />
              )}
              {view === "report" && (
                <ReportPreview
                  format={settings.format}
                  onChangeFormat={(f) => setTweak("format", f)}
                  onBack={() => setView("browser")}
                  onDownload={handleReportDownload}
                  settings={settings}
                />
              )}
            </div>

            {/* Side Panel — visible across all views */}
            <div className="side-panel-wrap">
              <SidePanel
                state={scanState}
                onScan={startScan}
                onCancel={cancelScan}
                highlighted={highlighted}
                onToggleHighlight={toggleHighlight}
                onOpenSettings={() => setView("options")}
                onOpenReport={() => setView("report")}
                onOpenFlag={() => setShowFlag(true)}
                onLocateElement={highlightOne}
                onLocateOne={locateOne}
                extName={settings.extName}
                extGlyph={settings.extGlyph}
                scanProgress={scanProgress}
                ignoredIssues={ignoredIssues}
                onIgnoreIssue={ignoreIssue}
              />
            </div>
          </div>
        </div>
      </div>

      {/* State switcher (always visible) */}
      <StateSwitcher current={scanState} onChange={switchState} />

      {/* Modals */}
      {showFlag && <IssueReportModal onClose={() => setShowFlag(false)} settings={settings} scanState={scanState} />}
      {showReset && (
        <ResetModal
          onCancel={() => setShowReset(false)}
          onConfirm={() => {
            setTweak(DEFAULT_SETTINGS);
            setShowReset(false);
            flashToast("تم استعادة الإعدادات الافتراضية");
          }}
        />
      )}

      {/* Toast */}
      {toast && <div className="toast">{SP_Icon.check} {toast}</div>}

      {/* Tweaks panel */}
      <TweaksPanel title="Tweaks">
        <TweakSection label="هوية الإضافة">
          <TweakText label="اسم الإضافة" value={settings.extName} onChange={(v) => setTweak("extName", v)} />
          <TweakText label="حرف الشعار" value={settings.extGlyph} onChange={(v) => setTweak("extGlyph", v)} />
        </TweakSection>
        <TweakSection label="حالة العرض">
          <TweakSelect
            label="حالة الفحص"
            value={scanState}
            options={STATES.map(s => s.id)}
            onChange={switchState}
          />
          <TweakSelect
            label="الواجهة"
            value={view}
            options={["browser", "options", "report"]}
            onChange={setView}
          />
        </TweakSection>
        <TweakSection label="إجراءات">
          <TweakButton label="فتح نموذج الإبلاغ" onClick={() => setShowFlag(true)} />
          <TweakButton label="تبديل التمييز" onClick={toggleHighlight} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
