// Mock government services page
// Demonstrates responsive design examples for the audit template.

function MockGovPage({ highlights }) {
  const isHl = (key) => highlights && highlights[key];

  return (
    <div className="gov-page" data-screen-label="Mock Gov Page">
      <div className="gov-topbar">
        <span>المملكة العربية السعودية — هيئة الحكومة الرقمية</span>
        <span className="row-flex" style={{gap: 14}}>
          <span>الأحد، 9 مايو 2026</span>
          <span>EN</span>
          <span>البحث ⌕</span>
        </span>
      </div>
      <div className="gov-nav">
        <div className="gov-logo">
          <div className="glyph">و</div>
          <div className="name">
            بوابة الخدمات
            <small>Services Portal · DEMO</small>
          </div>
        </div>
        <nav className="gov-menu">
          <a href="#" className="active">الرئيسية</a>
          <a href="#">الخدمات</a>
          <a href="#">عن البوابة</a>
          <a href="#">الأخبار</a>
          <a href="#">اتصل بنا</a>
        </nav>
      </div>

      <section className="gov-hero">
        <h1>منصتك الرقمية لخدمات أكثر من <br/>300 جهة حكومية</h1>
        <p>
          أنجز معاملاتك الحكومية بسهولة وأمان من مكان واحد. راجع
          <a href="#" className={isHl("link-base") ? "scan-highlight" : ""} data-scan="link-base" style={{position:"relative", marginInline:"4px"}}> دليل استخدام الروابط </a>
          للتأكد من الالتزام بمعيار الاستجابة في كود المنصات.
          {isHl("link-base") && <span className="scan-tooltip">Base Design Mismatch</span>}
        </p>
        <div className="cta-row">
          <a href="#" className="more">استكشف الخدمات</a>
          <a href="https://designsystem.gov.sa" target="_blank" rel="noreferrer" className={isHl("external-link") ? "scan-highlight" : ""} data-scan="external-link" style={{position:"relative"}}>
            كود المنصات ↗
            {isHl("external-link") && <span className="scan-tooltip">Responsive Issue</span>}
          </a>
        </div>
      </section>

      <section className="gov-services">
        <h2>أمثلة روابط داخل الصفحة</h2>
        <div className="gov-grid">
          {[
            {t: "رابط عربي", d: "يدعم RTL واتجاه الأيقونة والمسافات.", link: "ابدأ الخدمة"},
            {t: "English Link", d: "Supports LTR text while preserving the component style.", link: "Learn more"},
            {t: "رابط معطل", d: "يجب أن يظهر بحالة disabled المعتمدة.", link: "غير متاح حاليًا"}
          ].map((c, i) => (
            <article key={i} className="gov-card">
              <div className="ico">◇</div>
              <h3>{c.t}</h3>
              <p>{c.d}</p>
              <a href={i === 2 ? undefined : "#"} aria-disabled={i === 2 ? "true" : undefined} className="more">{c.link}</a>
            </article>
          ))}
        </div>
      </section>

      <footer className="gov-footer">
        <div className="row">
          <div>
            <h4>الجهة</h4>
            <a href="#">عن البوابة</a>
            <a href="#">المركز الإعلامي</a>
            <a href="#">سياسة الخصوصية</a>
          </div>
          <div>
            <h4>الخدمات</h4>
            <a href="#">دليل الخدمات</a>
            <a href="#">الخدمات الإلكترونية</a>
            <a href="#">معايير الامتثال</a>
          </div>
          <div>
            <h4>تواصل</h4>
            <a href="tel:19999">19999</a>
            <a href="mailto:support@example.gov.sa">support@example.gov.sa</a>
            <a href="https://designsystem.gov.sa" target="_blank" rel="noreferrer">كود المنصات ↗</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

window.MockGovPage = MockGovPage;
