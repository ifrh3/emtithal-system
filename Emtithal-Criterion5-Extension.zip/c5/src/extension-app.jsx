// Extension App — real active-tab Responsive Design audit while preserving the uploaded template panel style
const { useState, useEffect, useRef, useMemo } = React;

const DEFAULT_SETTINGS = {
  extName: "إمتثال",
  extGlyph: "ف",
  extLogo: "assets/images/emttthal-logo.png",
  lang: "ar",
  theme: "light",
  notifications: true,
  autoScroll: true,
  clearOnClose: true,
  format: "PDF",
  incLink: true,
  incTime: true,
  incDetails: true,
  incElements: true,
  incRecs: true,
  incExec: true,
  autoSubmitReports: false
};

function IssueReportModal({ onClose, settings, report, scanState }) {
  const [note, setNote] = useState("");
  const [submitState, setSubmitState] = useState("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [receipt, setReceipt] = useState(null);
  const data = buildStandardDataFromReport(report || createEmptyCriterion14Report());
  const statusLabel = data.status === "Passed" ? "امتثال كامل" : data.status === "Failed" ? "غير ممتثل" : "امتثال جزئي";

  const handleSubmit = async () => {
    setErrorMessage("");
    setSubmitState("sending");
    try {
      const result = await window.submitComplaintToEmtithal(settings, report, note, scanState);
      setReceipt(result);
      setSubmitState("sent");
    } catch (error) {
      setErrorMessage(error?.message || "تعذر إرسال البلاغ إلى موقع امتثال.");
      setSubmitState("error");
    }
  };

  if (submitState === "sent") {
    return (
      <div className="modal-backdrop" onClick={onClose}>
        <div className="modal" onClick={e => e.stopPropagation()} style={{ width: 420 }}>
          <div className="modal-body" style={{ textAlign: "center", padding: "32px 24px" }}>
            <div style={{ width: 48, height: 48, borderRadius: "50%", background: "var(--success-soft)", color: "var(--success)", display: "grid", placeItems: "center", margin: "0 auto 12px" }}>
              {SP_Icon.bigCheck}
            </div>
            <h3 style={{ margin: 0, fontSize: 16 }}>تم إرسال البلاغ</h3>
            <p style={{ fontSize: 13, color: "var(--text-3)", marginTop: 8, lineHeight: 1.6 }}>
              تم حفظ البلاغ في موقع امتثال بنجاح{receipt?.id ? `، رقم البلاغ: ${receipt.id}` : ""}.
            </p>
          </div>
          <div className="modal-foot">
            <button className="btn primary" onClick={onClose}>إغلاق</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-head">
          <h3>إبلاغ عن مشكلة</h3>
          <button className="sp-iconbtn" onClick={onClose}>{SP_Icon.close}</button>
        </div>
        <div className="modal-body">
          <p style={{ marginTop: 0, fontSize: 12, color: "var(--text-3)" }}>
            استخدم هذه النافذة للإبلاغ عن خلل في فحص الاستجابة أو نتيجة غير دقيقة. سيتم إرسال البلاغ إلى موقع امتثال عبر مفتاح الربط الرسمي المدمج في نسخة الإضافة.
          </p>
          <div className="field">
            <label>رابط الصفحة</label>
            <input readOnly value={data.pageUrl || "—"} />
          </div>
          <div className="field">
            <label>المعيار</label>
            <input readOnly value={`${data.number} — ${data.title}`} />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div className="field">
              <label>وقت الفحص</label>
              <input readOnly value={data.scanDateFormatted || "—"} />
            </div>
            <div className="field">
              <label>نتيجة الفحص</label>
              <input readOnly value={scanState === "before" ? "لم يبدأ الفحص" : `${data.score}% — ${statusLabel}`} />
            </div>
          </div>
          <div className="field">
            <label>ملاحظتك <span style={{ color: "var(--text-3)", fontWeight: 400 }}>(اختياري)</span></label>
            <textarea
              placeholder="مثال: ظهرت مشكلة تمرير أفقي في عنصر محدد، أو لم يتعرف الفحص على تقنية تخطيط متجاوبة مستخدمة في الصفحة..."
              value={note}
              onChange={e => setNote(e.target.value)}
            />
          </div>
          {errorMessage && <div className="api-error" role="alert">{errorMessage}</div>}
        </div>
        <div className="modal-foot">
          <button className="btn" onClick={onClose} disabled={submitState === "sending"}>إلغاء</button>
          <button className="btn primary" onClick={handleSubmit} disabled={submitState === "sending"}>
            {submitState === "sending" ? "جار الإرسال..." : "إرسال البلاغ"}
          </button>
        </div>
      </div>
    </div>
  );
}


function ExtensionShell() {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [view, setView] = useState("browser");
  const [scanState, setScanState] = useState("before");
  const [scanProgress, setScanProgress] = useState(0);
  const [highlighted, setHighlighted] = useState(false);
  const [ignoredIssues, setIgnoredIssues] = useState({});
  const [report, setReport] = useState(createEmptyCriterion14Report());
  const [standardData, setStandardData] = useState(buildStandardDataFromReport(null));
  const [toast, setToast] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [showFlag, setShowFlag] = useState(false);
  const [reportSubmitState, setReportSubmitState] = useState("idle");
  const toastTimer = useRef(null);

  const flashToast = (msg) => {
    if (settings.notifications === false) return;
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2600);
  };

  useEffect(() => {
    const theme = settings.theme || "light";
    document.documentElement.setAttribute("data-theme", theme);
  }, [settings.theme]);

  const applyTemplateCalculation = (rawReport) => {
    const data = buildStandardDataFromReport(rawReport);
    const normalized = {
      ...rawReport,
      score: data.score,
      status: data.status,
      calculationMethod: "template-pass-ratio",
      calculationNote: "score = passed responsive sub-checks / 3 * 100, matching the uploaded template calculation style"
    };
    return { report: normalized, data: buildStandardDataFromReport(normalized) };
  };

  const getTemplateScanState = (data) => {
    if (!data.summary || data.summary.totalChecks === 0) return "n/a";
    if (data.score === 100) return "full";
    if (data.score === 0) return "none";
    return "partial";
  };

  const updateReport = (nextReport) => {
    const normalized = applyTemplateCalculation(nextReport);
    setCurrentCriterion14Report(normalized.report);
    setReport(normalized.report);
    setStandardData(normalized.data);
    setIgnoredIssues({});
    if (chrome?.storage?.local) {
      chrome.storage.local.set({ responsiveLastReport: normalized.report }).catch(() => {});
    }
    return normalized.data;
  };

  const rebuildSummaryForIssues = (baseReport, activeIssues) => {
    const baseSummary = baseReport?.summary || {};
    const affected = new Set((activeIssues || []).map(issue => issue.selector || issue.domPath || issue.id));
    const failedChecks = [
      activeIssues.some(issue => issue.category === "Viewport Meta Issue"),
      activeIssues.some(issue => issue.category === "Horizontal Overflow Issue"),
      activeIssues.some(issue => issue.category === "Responsive Layout Issue")
    ].filter(Boolean).length;
    const totalChecks = baseSummary.totalChecks || 3;
    return {
      ...baseSummary,
      totalChecks,
      passedChecks: Math.max(0, totalChecks - failedChecks),
      failedChecks,
      issuesCount: activeIssues.length,
      elementsWithIssues: affected.size,
      linksWithIssues: affected.size,
      viewportIssues: activeIssues.filter(issue => issue.category === "Viewport Meta Issue").length,
      horizontalScrollIssues: activeIssues.filter(issue => issue.category === "Horizontal Overflow Issue").length,
      responsiveLayoutIssues: activeIssues.filter(issue => issue.category === "Responsive Layout Issue").length
    };
  };

  const createEffectiveReport = (baseReport, ignoredMap) => {
    const activeIssues = (baseReport?.issues || []).filter(issue => !ignoredMap[getIssueKey(issue)]);
    const filtered = {
      ...(baseReport || createEmptyCriterion14Report()),
      issues: activeIssues,
      summary: rebuildSummaryForIssues(baseReport, activeIssues)
    };
    return applyTemplateCalculation(filtered).report;
  };

  const effectiveReport = useMemo(() => createEffectiveReport(report, ignoredIssues), [report, ignoredIssues]);

  useEffect(() => {
    if (!chrome?.storage?.local) return;
    chrome.storage.local.get(["responsiveLastReport", "responsiveSettings"]).then(result => {
      if (result.responsiveSettings) {
        const { apiKey, supabaseUrl, supabaseAnonKey, ...safeSettings } = result.responsiveSettings;
        setSettings(prev => ({ ...prev, ...safeSettings }));
      }
      if (result.responsiveLastReport) updateReport(result.responsiveLastReport);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (scanState !== "scanning") return;
    setScanProgress(0);
    let current = 0;
    const timer = setInterval(() => {
      current += 1;
      setScanProgress(Math.min(current, 3));
      if (current >= 3) clearInterval(timer);
    }, 350);
    return () => clearInterval(timer);
  }, [scanState]);

  const getActiveTab = async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    return tabs && tabs[0];
  };

  const getTabUrl = (tab) => tab?.url || tab?.pendingUrl || "";

  const canScanTab = (tab) => {
    if (!tab || !tab.id) return false;
    const url = getTabUrl(tab);
    if (!url) return true;
    return /^(https?:|file:)/i.test(url);
  };

  const getUnsupportedTabMessage = (tab) => {
    const url = getTabUrl(tab);
    if (!tab || !tab.id) return "لم يتم العثور على تبويب نشط يمكن فحصه.";
    if (/^(chrome:|edge:|about:|devtools:|chrome-extension:|view-source:)/i.test(url)) {
      return "لا يمكن فحص صفحات المتصفح الداخلية. افتح صفحة موقع عادية http/https ثم أعد الفحص.";
    }
    if (/^file:/i.test(url)) {
      return "صفحات الملفات المحلية تحتاج تفعيل Allow access to file URLs من إعدادات الإضافة في المتصفح.";
    }
    return "لا يمكن فحص هذه الصفحة. افتح صفحة http أو https ثم أعد المحاولة.";
  };

  const ensureApiKeyActive = async () => {
    if (!window.validateEmtithalApiKey) {
      throw new Error("تعذر التحقق من حالة مفتاح الربط. أعد تحميل الإضافة بعد تشغيل ملف fix_validate_api_key_rpc.sql.");
    }
    try {
      await window.validateEmtithalApiKey(settings);
    } catch (error) {
      throw new Error(error?.message || "تم إيقاف مفتاح الربط من منصة امتثال.");
    }
  };

  const submitReportToWebsite = async (targetReport = effectiveReport, options = {}) => {
    const silent = Boolean(options.silent);
    setReportSubmitState("sending");
    try {
      await ensureApiKeyActive();
      const result = await window.submitAuditReportToEmtithal(settings, targetReport);
      setReportSubmitState("sent");
      if (!silent) flashToast(result?.message || "تم إرسال التقرير إلى موقع امتثال");
      return result;
    } catch (error) {
      setReportSubmitState("error");
      if (!silent) flashToast(error?.message || "تعذر إرسال التقرير إلى موقع امتثال");
      throw error;
    } finally {
      setTimeout(() => setReportSubmitState("idle"), 2600);
    }
  };

  const openProjectWebsite = async () => {
    const url = window.EMTITHAL_API_DEFAULTS?.websiteUrl || "https://emtithal-system.vercel.app/home/emtithal_public_home.html";
    try {
      if (chrome?.tabs?.create) {
        await chrome.tabs.create({ url });
      } else {
        window.open(url, "_blank", "noopener");
      }
    } catch (_) {
      window.open(url, "_blank", "noopener");
    }
  };

  const ensureAuditScript = async (tabId) => {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["src/responsive-audit.js"]
    });
  };

  const startScan = async () => {
    setErrorMessage("");
    setHighlighted(false);
    setScanState("scanning");

    try {
      await ensureApiKeyActive();
      const tab = await getActiveTab();
      if (!canScanTab(tab)) throw new Error(getUnsupportedTabMessage(tab));

      await clearPageHighlights();
      await ensureAuditScript(tab.id);
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          if (!window.PlatformsCodeCriterion14 || typeof window.PlatformsCodeCriterion14.runAudit !== "function") {
            throw new Error("لم يتم تحميل محرك فحص الاستجابة داخل الصفحة.");
          }
          return window.PlatformsCodeCriterion14.runAudit();
        }
      });

      const nextReport = results?.[0]?.result;
      if (!nextReport) throw new Error("لم يتم إرجاع نتيجة الفحص من الصفحة الحالية.");

      const nextData = updateReport(nextReport);
      setScanState(getTemplateScanState(nextData));
      flashToast("تم فحص الاستجابة لجميع الأجهزة محليًا");
      if (settings.autoSubmitReports && window.EMTITHAL_API_DEFAULTS?.apiKey && window.isSaudiWebsiteUrl?.(nextReport.pageUrl)) {
        submitReportToWebsite(nextReport, { silent: true }).catch(error => console.warn("Auto report submit failed", error?.message || error));
      }
    } catch (error) {
      const raw = error?.message || "تعذر فحص الصفحة الحالية.";
      const friendly = raw.includes("Cannot access contents of url") || raw.includes("Missing host permission")
        ? "لا يملك الإكستنشن صلاحية قراءة هذه الصفحة. أعد تحميل الإضافة من chrome://extensions وتأكد من السماح لها بالعمل على المواقع، ثم افتح الصفحة واضغط أيقونة الإضافة من نفس التبويب."
        : raw.includes("The extensions gallery cannot be scripted")
          ? "لا يمكن فحص صفحة Chrome Web Store أو صفحات المتصفح الداخلية. افتح موقعًا عاديًا ثم أعد الفحص."
          : raw;
      setErrorMessage(friendly);
      setScanState("error");
      flashToast("تعذر إكمال الفحص");
      console.error("Responsive scan failed", error);
    }
  };

  const cancelScan = () => {
    setScanState("before");
    setScanProgress(0);
  };

  const runHighlightIssues = async (issues, modeLabel) => {
    const activeIssues = (issues || []).filter(Boolean);
    if (!activeIssues.length) {
      flashToast("لا توجد مشاكل قابلة للتمييز");
      return false;
    }

    try {
      const tab = await getActiveTab();
      if (!canScanTab(tab)) throw new Error("Cannot access tab");
      await ensureAuditScript(tab.id);
      const result = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (items, label, options) => {
          if (!window.PlatformsCodeCriterion14) return 0;
          if (typeof window.PlatformsCodeCriterion14.highlightIssues === "function") {
            return window.PlatformsCodeCriterion14.highlightIssues(items, label, options);
          }
          const first = items[0];
          return window.PlatformsCodeCriterion14.highlightIssue(first.selector, first.domPath, first.category) ? 1 : 0;
        },
        args: [activeIssues.map(issue => ({
          selector: issue.selector,
          domPath: issue.domPath,
          category: issue.category,
          id: issue.id
        })), modeLabel || "Responsive Design", { autoScroll: settings.autoScroll !== false }]
      });
      const count = result?.[0]?.result || 0;
      if (count > 0) {
        flashToast(`تم تمييز ${count} عنصر في الصفحة`);
        return true;
      }
      flashToast("تعذر العثور على العناصر في الصفحة الحالية");
      return false;
    } catch (_) {
      flashToast("تعذر تمييز العناصر في الصفحة الحالية");
      return false;
    }
  };

  const clearPageHighlights = async () => {
    try {
      const tab = await getActiveTab();
      if (!canScanTab(tab)) return;
      await ensureAuditScript(tab.id);
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => window.PlatformsCodeCriterion14?.clearHighlights?.()
      });
    } catch (_) {}
  };

  const locateIssue = async (target, issue) => {
    const selectedIssue = issue || (effectiveReport.issues || []).find(item => item.selector === target || item.domPath === target || item.target === target);
    if (!selectedIssue) return flashToast("لم يتم العثور على العنصر في التقرير");
    const ok = await runHighlightIssues([selectedIssue], selectedIssue.category);
    if (ok) flashToast("تم الانتقال إلى العنصر وتمييزه مؤقتًا");
  };

  const highlightAll = async () => {
    const activeIssues = effectiveReport.issues || [];
    if (!activeIssues.length) return flashToast("لا توجد مشاكل قابلة للتمييز");
    if (highlighted) {
      await clearPageHighlights();
      setHighlighted(false);
      flashToast("تم إخفاء التمييز");
      return;
    }
    const ok = await runHighlightIssues(activeIssues, "كل مشاكل الاستجابة");
    setHighlighted(ok);
  };

  const highlightGroup = async (item) => {
    const groupIssues = (item.issues || []).filter(issue => !ignoredIssues[getIssueKey(issue)]);
    const ok = await runHighlightIssues(groupIssues, item.title || item.category);
    setHighlighted(ok || highlighted);
  };

  const ignoreIssue = (issue) => {
    const key = getIssueKey(issue);
    setIgnoredIssues(prev => ({ ...prev, [key]: true }));
    if (highlighted) {
      clearPageHighlights();
      setHighlighted(false);
    }
    flashToast("تم تجاهل المشكلة وإخفاؤها من القائمة والحساب");
  };

  const stripSensitiveSettings = (source = {}) => {
    const { apiKey, supabaseUrl, supabaseAnonKey, ...safeSettings } = source;
    return safeSettings;
  };

  const persistSettings = (nextSettings) => {
    if (chrome?.storage?.local) {
      chrome.storage.local.set({ responsiveSettings: stripSensitiveSettings(nextSettings) }).catch(() => {});
    }
  };

  const setSetting = (keyOrObject, value) => {
    setSettings(prev => {
      const next = typeof keyOrObject === "object" ? { ...prev, ...keyOrObject } : { ...prev, [keyOrObject]: value };
      persistSettings(next);
      return next;
    });
  };

  const downloadBlob = (content, mime, filename) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1200);
  };

  const escapeHtml = (value) => String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");

  const buildReportFilename = (format, currentReport) => {
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    let host = "page";
    try {
      const url = new URL(currentReport?.pageUrl || "");
      host = url.hostname || host;
    } catch (_) {}
    const safeHost = host.replace(/[^a-zA-Z0-9.-]+/g, "-").replace(/^-+|-+$/g, "") || "page";
    return `responsive-design-audit-${safeHost}-${stamp}.${format.toLowerCase()}`;
  };

  const buildCsvReport = (safeReport) => {
    const summary = safeReport.summary || {};
    const summaryRows = [
      ["section", "field", "value"],
      ["summary", "criterion", safeReport.criterion],
      ["summary", "criterion_name", safeReport.criterionName],
      ["summary", "page_url", safeReport.pageUrl],
      ["summary", "scan_date", safeReport.scanDate],
      ["summary", "score", safeReport.score],
      ["summary", "status", safeReport.status],
      ["summary", "total_checks", summary.totalChecks],
      ["summary", "passed_checks", summary.passedChecks],
      ["summary", "failed_checks", summary.failedChecks],
      ["summary", "overflowing_elements", summary.overflowingElements],
      ["summary", "issues_count", summary.issuesCount],
      [],
      ["id", "requirement", "category", "severity", "confidence", "element", "selector", "description", "evidence", "expected", "actual", "recommendation"]
    ];
    const issueRows = (safeReport.issues || []).map(issue => [
      issue.id,
      issue.requirement,
      issue.category,
      issue.severity,
      issue.confidence,
      issue.elementName || issue.linkText,
      issue.selector || issue.domPath,
      issue.description,
      issue.evidence,
      issue.expected,
      issue.actual,
      issue.recommendation
    ]);
    const rows = summaryRows.concat(issueRows);
    return "\ufeff" + rows.map(row => row.map(value => `"${String(value ?? "").replace(/"/g, '""')}"`).join(",")).join("\n");
  };

  const buildPrintableReportHtml = (safeReport) => {
    const dataForReport = buildStandardDataFromReport(safeReport);
    const summary = safeReport.summary || {};
    const issues = safeReport.issues || [];
    const statusLabel = dataForReport.status === "Passed" ? "امتثال كامل" : dataForReport.status === "Failed" ? "غير ممتثل" : "امتثال جزئي";
    const logoUrl = settings.extLogo ? chrome.runtime.getURL(settings.extLogo) : "";
    const rows = issues.length ? issues.map(issue => `
      <tr>
        <td>${escapeHtml(issue.id)}</td>
        <td>${escapeHtml(issue.category)}</td>
        <td>${escapeHtml(issue.severity)}</td>
        <td>${escapeHtml(issue.elementName || issue.linkText || "—")}</td>
        <td dir="ltr">${escapeHtml(issue.selector || issue.domPath || "—")}</td>
        <td>${escapeHtml(issue.description || "—")}</td>
        <td>${escapeHtml(issue.recommendation || "—")}</td>
      </tr>`).join("") : `<tr><td colspan="7">لا توجد مشاكل مكتشفة في التقرير الحالي.</td></tr>`;

    return `<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<title>تقرير فحص الاستجابة</title>
<style>
  *{box-sizing:border-box} body{margin:0;background:#eef0f4;color:#0f172a;font-family:"IBM Plex Sans Arabic","Segoe UI",Tahoma,Arial,sans-serif;line-height:1.7} .page{max-width:980px;margin:24px auto;background:#fff;border:1px solid #e2e6ee;border-radius:14px;overflow:hidden} .head{display:flex;align-items:center;gap:16px;justify-content:space-between;padding:24px 28px;border-bottom:2px solid #0f172a}.brand{display:flex;align-items:center;gap:12px}.logo{width:110px;height:48px;object-fit:contain;border:1px solid #e2e6ee;border-radius:10px;background:#fff}.title h1{margin:0;font-size:22px}.title div{font-size:12px;color:#64748b}.score{display:flex;gap:18px;align-items:center;margin:22px 28px;padding:18px;border:1px solid #e2e6ee;border-radius:12px;background:#f6f8fb}.pct{font-size:42px;font-weight:800;color:#b45309}.pct.pass{color:#047857}.pct.fail{color:#b91c1c}.section{padding:0 28px 24px}.section h2{font-size:14px;color:#64748b;border-bottom:1px solid #e2e6ee;padding-bottom:6px;margin:24px 0 10px;text-transform:uppercase;letter-spacing:.06em} dl{display:grid;grid-template-columns:190px 1fr;gap:6px 14px;margin:0} dt{color:#64748b} dd{margin:0;color:#0f172a} table{width:100%;border-collapse:collapse;margin-top:8px;table-layout:fixed} th,td{border-bottom:1px solid #e2e6ee;padding:8px 10px;text-align:start;vertical-align:top;font-size:12px;word-break:break-word} th{background:#f6f8fb;color:#475569;font-weight:700}.printbar{position:sticky;top:0;background:#0f172a;color:#fff;padding:10px 16px;display:flex;gap:8px;align-items:center;justify-content:space-between}.printbar button{border:0;border-radius:8px;padding:8px 14px;font-weight:700;cursor:pointer}@media print{body{background:#fff}.page{margin:0;max-width:none;border:0;border-radius:0}.printbar{display:none}.section{break-inside:auto} tr{break-inside:avoid}}
</style>
</head>
<body>
<div class="printbar"><span>تقرير جاهز للطباعة أو الحفظ كـ PDF</span><button onclick="window.print()">طباعة / حفظ PDF</button></div>
<main class="page">
  <header class="head">
    <div class="brand">${logoUrl ? `<img class="logo" src="${escapeHtml(logoUrl)}" alt="${escapeHtml(settings.extName)}">` : ""}<div class="title"><h1>تقرير فحص الاستجابة</h1><div>${escapeHtml(settings.extName)} · معيار ${escapeHtml(safeReport.criterion)} — ${escapeHtml(dataForReport.title)}</div></div></div>
    <div style="font-size:12px;color:#64748b;text-align:end">${escapeHtml(dataForReport.scanDateFormatted || "—")}<br>الحالة: ${escapeHtml(statusLabel)}</div>
  </header>
  <div class="score"><div class="pct ${dataForReport.status === "Passed" ? "pass" : dataForReport.status === "Failed" ? "fail" : ""}">${escapeHtml(dataForReport.score)}%</div><div><strong>${escapeHtml(statusLabel)}</strong><br><span>تم اجتياز ${escapeHtml(summary.passedChecks || 0)} من أصل ${escapeHtml(summary.totalChecks || 3)} فحوصات فرعية. عدد المشاكل الحالية بعد التجاهل: ${escapeHtml(summary.issuesCount || 0)}.</span></div></div>
  <section class="section"><h2>معلومات الفحص</h2><dl><dt>رقم المعيار</dt><dd>${escapeHtml(safeReport.criterion)}</dd><dt>اسم المعيار</dt><dd>${escapeHtml(safeReport.criterionNameAr || safeReport.criterionName)}</dd><dt>رابط الصفحة</dt><dd dir="ltr">${escapeHtml(safeReport.pageUrl)}</dd><dt>وقت الفحص</dt><dd>${escapeHtml(dataForReport.scanDateFormatted || "—")}</dd><dt>عناصر متجاوزة أفقيًا</dt><dd>${escapeHtml(summary.overflowingElements || 0)}</dd><dt>مشاكل مكتشفة</dt><dd>${escapeHtml(summary.issuesCount || 0)}</dd></dl></section>
  <section class="section"><h2>توزيع المشاكل</h2><table><thead><tr><th>الفئة</th><th>العدد</th></tr></thead><tbody><tr><td>Viewport Meta Issue</td><td>${escapeHtml(summary.viewportIssues || 0)}</td></tr><tr><td>Horizontal Overflow Issue</td><td>${escapeHtml(summary.horizontalScrollIssues || 0)}</td></tr><tr><td>Responsive Layout Issue</td><td>${escapeHtml(summary.responsiveLayoutIssues || 0)}</td></tr></tbody></table></section>
  <section class="section"><h2>تفاصيل المشاكل</h2><table><thead><tr><th>ID</th><th>الفئة</th><th>الشدة</th><th>العنصر</th><th>المحدد</th><th>الوصف</th><th>التوصية</th></tr></thead><tbody>${rows}</tbody></table></section>
</main>
<script>setTimeout(function(){ window.focus(); window.print(); }, 350);</script>
</body>
</html>`;
  };

  const openPrintablePdfReport = (safeReport) => {
    const html = buildPrintableReportHtml(safeReport);
    const printWindow = window.open("", "_blank", "width=980,height=720");
    if (!printWindow) {
      window.print();
      return false;
    }
    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
    return true;
  };

  const handleReportDownload = (format, currentReport) => {
    const safeReport = currentReport || effectiveReport;
    const isSaudi = window.isSaudiWebsiteUrl?.(safeReport?.pageUrl);
    const selectedFormat = isSaudi ? (format || settings.format || "PDF") : "PDF";
    try {
      if (selectedFormat === "JSON") {
        downloadBlob(JSON.stringify(safeReport, null, 2), "application/json;charset=utf-8", buildReportFilename("json", safeReport));
        flashToast("تم تنزيل تقرير JSON");
      } else if (selectedFormat === "CSV") {
        downloadBlob(buildCsvReport(safeReport), "text/csv;charset=utf-8", buildReportFilename("csv", safeReport));
        flashToast("تم تنزيل تقرير CSV");
      } else {
        const opened = openPrintablePdfReport(safeReport);
        flashToast(isSaudi ? (opened ? "تم فتح تقرير PDF وجار إرسال النتيجة" : "تم فتح نافذة الطباعة وجار إرسال النتيجة") : (opened ? "تم فتح تقرير PDF للطباعة أو الحفظ" : "تم فتح نافذة الطباعة للتقرير"));
      }
      if (isSaudi && window.EMTITHAL_API_DEFAULTS?.apiKey) {
        submitReportToWebsite(safeReport).catch(() => {});
      }
    } catch (error) {
      console.error("Report export failed", error);
      flashToast("تعذر إصدار التقرير، حاول مرة أخرى");
    }
  };

  return (
    <div className="extension-root" data-screen-label="Responsive Extension">
      <div className="extension-panel-shell">
        {view === "browser" && (
          <SidePanel
            state={scanState}
            onScan={startScan}
            onCancel={cancelScan}
            highlighted={highlighted}
            onToggleHighlight={highlightAll}
            onOpenSettings={() => setView("options")}
            onOpenReport={() => setView("report")}
            onOpenFlag={() => setShowFlag(true)}
            onOpenWebsite={openProjectWebsite}
            onLocateElement={highlightGroup}
            onLocateOne={locateIssue}
            extName={settings.extName}
            extLogo={settings.extLogo}
            extGlyph={settings.extGlyph}
            scanProgress={scanProgress}
            ignoredIssues={ignoredIssues}
            onIgnoreIssue={ignoreIssue}
            data={standardData}
            errorMessage={errorMessage}
          />
        )}

        {view === "options" && (
          <OptionsPage
            settings={settings}
            onChange={setSetting}
            onSave={() => flashToast("تم حفظ الإعدادات محليًا")}
            onReset={() => { setSettings(DEFAULT_SETTINGS); persistSettings(DEFAULT_SETTINGS); flashToast("تمت إعادة ضبط الإعدادات"); }}
            onBack={() => setView("browser")}
          />
        )}

        {view === "report" && (
          <ReportPreview
            format={settings.format}
            onChangeFormat={(format) => setSetting("format", format)}
            onBack={() => setView("browser")}
            onDownload={handleReportDownload}
            onSubmitReport={targetReport => submitReportToWebsite(targetReport || effectiveReport).catch(() => {})}
            reportSubmitState={reportSubmitState}
            canSubmitReport={Boolean(window.EMTITHAL_API_DEFAULTS?.apiKey && window.isSaudiWebsiteUrl?.(effectiveReport?.pageUrl))}
            settings={settings}
            report={effectiveReport}
          />
        )}
      </div>

      {showFlag && (
        <IssueReportModal
          onClose={() => setShowFlag(false)}
          settings={settings}
          report={effectiveReport}
          scanState={scanState}
        />
      )}

      {toast && <div className="toast">{SP_Icon.check} {toast}</div>}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<ExtensionShell />);
