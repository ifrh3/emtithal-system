// Options Page (Settings)
function OptionsPage({ settings, onChange, onSave, onReset, onBack }) {
  const set = (k, v) => onChange({ ...settings, [k]: v });

  return (
    <div className="options-shell" data-screen-label="Options Page">
      <div className="options-page">
        <div className="options-main">
          <div className="options-head">
            <div className="glyph" title={settings.extName}>
              {settings.extLogo ? (
                <img src={settings.extLogo} alt={settings.extName} className="app-logo-img" />
              ) : (
                settings.extGlyph
              )}
            </div>
            <div style={{flex: 1}}>
              <div className="crumb">{settings.extName} · الإعدادات</div>
              <h1>تخصيص الإضافة</h1>
            </div>
            <button className="btn" onClick={onBack}>← العودة</button>
          </div>

          {/* General */}
          <div className="options-section">
            <h2><span className="num">01</span> الإعدادات العامة</h2>
            <p className="desc">تخصيص اللغة والمظهر والإشعارات.</p>

            <div className="opt-row">
              <div className="lbl">
                اللغة
                <small>تظهر اللوحة بالعربية افتراضيًا مع دعم RTL</small>
              </div>
              <div className="seg">
                {[["ar","العربية"],["en","English"]].map(([k, l]) => (
                  <button key={k} className={settings.lang === k ? "active" : ""} onClick={() => set("lang", k)}>{l}</button>
                ))}
              </div>
            </div>

            <div className="opt-row">
              <div className="lbl">
                المظهر
                <small>يؤثر على ألوان اللوحة الجانبية</small>
              </div>
              <div className="seg">
                {[["light","فاتح"],["dark","داكن"],["system","حسب النظام"]].map(([k, l]) => (
                  <button key={k} className={settings.theme === k ? "active" : ""} onClick={() => set("theme", k)}>{l}</button>
                ))}
              </div>
            </div>

            <div className="opt-row">
              <div className="lbl">
                الإشعارات
                <small>تنبيهات عند اكتمال الفحص أو ظهور المشاكل</small>
              </div>
              <button className={"toggle" + (settings.notifications ? " on" : "")} onClick={() => set("notifications", !settings.notifications)}></button>
            </div>

            <div className="opt-row">
              <div className="lbl">
                التمرير التلقائي إلى أول مشكلة
                <small>عند تفعيل التمييز، تنتقل الصفحة لأول عنصر مخالف</small>
              </div>
              <button className={"toggle" + (settings.autoScroll ? " on" : "")} onClick={() => set("autoScroll", !settings.autoScroll)}></button>
            </div>

            <div className="opt-row">
              <div className="lbl">
                إزالة التمييز عند إغلاق اللوحة
                <small>تنظيف الصفحة الأصلية تلقائيًا</small>
              </div>
              <button className={"toggle" + (settings.clearOnClose ? " on" : "")} onClick={() => set("clearOnClose", !settings.clearOnClose)}></button>
            </div>
          </div>

          {/* Report settings */}
          <div className="options-section">
            <h2><span className="num">02</span> إعدادات التقرير</h2>
            <p className="desc">حدد الصيغة الافتراضية والمعلومات التي يحتويها التقرير.</p>

            <div className="opt-row">
              <div className="lbl">
                صيغة التصدير الافتراضية
                <small>PDF للمشاركة · CSV للتحليل · JSON للتكاملات</small>
              </div>
              <div className="seg">
                {["PDF","CSV","JSON"].map(k => (
                  <button key={k} className={settings.format === k ? "active" : ""} onClick={() => set("format", k)}>{k}</button>
                ))}
              </div>
            </div>

            {[
              ["incLink", "تضمين رابط الصفحة"],
              ["incTime", "تضمين وقت الفحص"],
              ["incDetails", "تضمين تفاصيل المشاكل"],
              ["incElements", "تضمين العناصر المتأثرة"],
              ["incRecs", "تضمين التوصيات"],
              ["incExec", "تضمين الملخص التنفيذي"]
            ].map(([k, l]) => (
              <div key={k} className="opt-row">
                <div className="lbl">{l}</div>
                <button className={"toggle" + (settings[k] ? " on" : "")} onClick={() => set(k, !settings[k])}></button>
              </div>
            ))}
          </div>

          {/* Privacy */}
          <div className="options-section">
            <h2><span className="num">03</span> الخصوصية</h2>
            <p className="desc">يتم الفحص محليًا داخل المتصفح ولا تُرسل بيانات الصفحة، محتوى الصفحة، لقطات الشاشة، أو نتائج الفحص إلى أي خادم خارجي.</p>
          </div>

          <div className="options-foot">
            <button className="btn" onClick={onReset}>إعادة التعيين</button>
            <button className="btn primary" onClick={onSave}>حفظ الإعدادات</button>
          </div>
        </div>
      </div>
    </div>
  );
}

window.OptionsPage = OptionsPage;
