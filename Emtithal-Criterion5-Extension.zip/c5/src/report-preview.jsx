// Report Preview view for Responsive Design audit
function ReportPreview({
  format,
  onChangeFormat,
  onBack,
  onDownload,
  onSubmitReport,
  reportSubmitState = "idle",
  canSubmitReport = false,
  settings,
  report: inputReport
}) {
  const report = inputReport || getCurrentCriterion14Report();
  const data = buildStandardDataFromReport(report);
  const summary = report.summary || EMPTY_SUMMARY;
  const issues = report.issues || [];
  const ratio = typeof data.score === "number" ? data.score : 100;
  const statusLabel = data.status === "Passed" ? "امتثال كامل" : data.status === "Failed" ? "غير ممتثل" : "امتثال جزئي";
  const statusClass = data.status === "Passed" ? "success" : data.status === "Failed" ? "fail" : "partial";
  const canSendToPlatform = window.isSaudiWebsiteUrl?.(report.pageUrl);
  const activeFormat = canSendToPlatform ? format : "PDF";
  const isSubmittingReport = reportSubmitState === "sending";
  const submitButtonLabel = reportSubmitState === "sent" ? "تم الإرسال" : isSubmittingReport ? "جار الإرسال..." : "إرسال لمنصة امتثال";

  const csvEscape = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const csvRows = [
    ["id", "requirement", "category", "severity", "confidence", "element", "selector", "description", "expected", "actual"],
    ...issues.map(issue => [
      issue.id,
      issue.requirement,
      issue.category,
      issue.severity,
      issue.confidence,
      issue.elementName || issue.linkText,
      issue.selector || issue.domPath,
      issue.description,
      issue.expected,
      issue.actual
    ])
  ].map(row => row.map(csvEscape).join(",")).join("\n");

  return (
    <div className="report-shell" data-screen-label="Report Preview">
      <div className="report-page">
        <div className="report-toolbar">
          <div className="left">
            <button className="btn" onClick={onBack}>← العودة</button>
            <span>معاينة التقرير</span>
          </div>
          <div className="row-flex report-actions" style={{gap: 12}}>
            <div className="report-fmt-pick">
              {(canSendToPlatform ? ["PDF","CSV","JSON"] : ["PDF"]).map(f => (
                <button key={f} className={"chip" + (activeFormat === f ? " active" : "")} onClick={() => onChangeFormat(f)}>{f}</button>
              ))}
            </div>
            {canSendToPlatform && (
              <button
                className="btn report-submit-btn"
                onClick={() => onSubmitReport?.(report)}
                disabled={!canSubmitReport || isSubmittingReport}
                title={canSubmitReport ? "إرسال نتيجة التقرير إلى منصة امتثال" : "الإرسال متاح لمواقع .sa المرتبطة فقط"}
                aria-label="إرسال نتيجة التقرير إلى منصة امتثال"
              >
                {submitButtonLabel}
              </button>
            )}
            <button className="btn primary" onClick={() => onDownload(activeFormat, report)}>
              تنزيل التقرير {activeFormat}
            </button>
          </div>
        </div>

        {activeFormat === "PDF" && (
          <div className="report-doc">
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",borderBottom:"2px solid var(--text)",paddingBottom:14,marginBottom:18}}>
              <div>
                <h1>تقرير فحص الاستجابة</h1>
                <div className="sub">{settings.extName} · معيار {report.criterion} — {data.title}</div>
              </div>
              <div style={{textAlign:"end",fontSize:11,color:"var(--text-3)"}}>
                <div>{data.scanDateFormatted || "—"}</div>
                <div>الحالة: {report.status}</div>
              </div>
            </div>

            <div className="summary-card">
              <div className={"pct " + statusClass}>{ratio}%</div>
              <div style={{flex:1}}>
                <div style={{fontSize:14,fontWeight:700,color:"var(--text)"}}>{statusLabel}</div>
                <div style={{fontSize:12,marginTop:2}}>
                  تم اجتياز {summary.passedChecks} من أصل {summary.totalChecks} فحوصات. تم العثور على {summary.issuesCount} مشكلة.
                </div>
              </div>
            </div>

            <h2>معلومات الفحص</h2>
            <dl>
              <dt>اسم الإضافة</dt><dd>{settings.extName}</dd>
              <dt>رقم المعيار</dt><dd>{report.criterion}</dd>
              <dt>اسم المعيار</dt><dd>{report.criterionNameAr || report.criterionName}</dd>
              <dt>رابط الصفحة</dt><dd style={{fontFamily:"ui-monospace, monospace",direction:"ltr",textAlign:"start"}}>{report.pageUrl}</dd>
              <dt>وقت الفحص</dt><dd>{data.scanDateFormatted}</dd>
              <dt>إجمالي الفحوصات</dt><dd>{summary.totalChecks}</dd>
              <dt>الفحوصات الناجحة</dt><dd>{summary.passedChecks}</dd>
              <dt>العناصر المتجاوزة أفقيًا</dt><dd>{summary.overflowingElements}</dd>
            </dl>

            <h2>الملخص التنفيذي</h2>
            <p style={{margin:0}}>تم فحص الصفحة مقابل معيار «{data.title}». النتيجة الحالية {ratio}% وفق منطق القالب: عدد فحوصات الاستجابة المجتازة من أصل 3. يغطي الفحص Viewport، التمرير الأفقي، وتقنيات التخطيط المتجاوب.</p>

            <h2>توزيع المشاكل</h2>
            <table>
              <thead>
                <tr><th>الفئة</th><th>العدد</th></tr>
              </thead>
              <tbody>
                <tr><td>Viewport Meta Issue</td><td>{summary.viewportIssues}</td></tr>
                <tr><td>Horizontal Overflow Issue</td><td>{summary.horizontalScrollIssues}</td></tr>
                <tr><td>Responsive Layout Issue</td><td>{summary.responsiveLayoutIssues}</td></tr>
              </tbody>
            </table>

            <h2>تفاصيل المشاكل</h2>
            <table>
              <thead>
                <tr><th>ID</th><th>الفئة</th><th>الشدة</th><th>العنصر</th><th>الدليل</th></tr>
              </thead>
              <tbody>
                {issues.length === 0 && <tr><td colSpan="5">لا توجد مشاكل مكتشفة.</td></tr>}
                {issues.map(iss => (
                  <tr key={iss.id}>
                    <td>{iss.id}</td>
                    <td>{iss.category}</td>
                    <td>{iss.severity}</td>
                    <td>{iss.elementName || iss.linkText || "—"}</td>
                    <td style={{fontSize:11,color:"var(--text-3)"}}>{iss.evidence}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <h2>المرجع</h2>
            <p style={{margin:0,direction:"ltr",textAlign:"start",fontFamily:"ui-monospace, monospace",fontSize:12}}>{data.reference}</p>
          </div>
        )}

        {activeFormat === "CSV" && (
          <div className="report-doc" style={{fontFamily:"ui-monospace, Menlo, monospace",direction:"ltr",textAlign:"start",fontSize:12,whiteSpace:"pre",overflow:"auto"}}>
{csvRows}
          </div>
        )}

        {activeFormat === "JSON" && (
          <div className="report-doc" style={{fontFamily:"ui-monospace, Menlo, monospace",direction:"ltr",textAlign:"start",fontSize:12,whiteSpace:"pre-wrap",overflow:"auto"}}>
{JSON.stringify(report, null, 2)}
          </div>
        )}
      </div>
    </div>
  );
}

window.ReportPreview = ReportPreview;
