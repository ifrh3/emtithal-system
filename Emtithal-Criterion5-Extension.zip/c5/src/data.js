// Responsive Design data — DGA Platforms Code compliance
const CRITERION_14_NAME = "Responsive Design Compliance for All Devices";
const CRITERION_14_NAME_AR = "معيار الاستجابة لجميع الأجهزة";

const CATEGORY_COLORS = {
  Foundations: "#E5E500",
  Templates: "#E49EDD",
  Components: "#94DCF8",
  Experience: "#9DA6F3",
  "أساسات": "#E5E500",
  "قوالب": "#E49EDD",
  "عناصر": "#94DCF8",
  "التجربة": "#9DA6F3"
};

const EMPTY_SUMMARY = {
  totalChecks: 3,
  passedChecks: 3,
  failedChecks: 0,
  issuesCount: 0,
  viewportIssues: 0,
  horizontalScrollIssues: 0,
  responsiveLayoutIssues: 0,
  overflowingElements: 0,
  responsiveTechniquesFound: 0,
  elementsWithIssues: 0,
  totalElementsScanned: 0,
  // template compatibility aliases
  totalLinks: 0,
  internalLinks: 0,
  externalLinks: 0,
  linksWithIssues: 0,
  manualReview: 0
};

const BASE_SUB_CRITERIA = [
  {
    id: "viewport-meta-tag",
    requirement: "Viewport Meta Tag",
    category: "Viewport Meta Issue",
    title: "وسم Viewport Meta",
    description: "يتحقق من وجود وسم viewport الصحيح داخل head حتى تتعامل الصفحة مع عرض الأجهزة المختلفة بشكل سليم.",
    howToFix: "أضف داخل <head> الوسم: <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"> أو عدّل الوسم الحالي ليحتوي على width=device-width و initial-scale=1.",
    reason: "وسم Viewport موجود وصحيح.",
    status: "pass",
    occurrences: 0,
    issues: []
  },
  {
    id: "horizontal-scrolling",
    requirement: "Horizontal Scrolling",
    category: "Horizontal Overflow Issue",
    title: "منع التمرير الأفقي",
    description: "يتحقق من عدم وجود عناصر تتجاوز عرض الشاشة وتسبب تمريرًا أفقيًا يكسر التخطيط على الأجهزة الصغيرة.",
    howToFix: "راجع العناصر ذات العرض الثابت، الصور، الجداول، والحاويات الواسعة. استخدم max-width:100% و flex-wrap و overflow-wrap عند الحاجة.",
    reason: "لم يتم اكتشاف تمرير أفقي أو عناصر متجاوزة لعرض الشاشة.",
    status: "pass",
    occurrences: 0,
    issues: []
  },
  {
    id: "responsive-layout-techniques",
    requirement: "Responsive Layout Techniques",
    category: "Responsive Layout Issue",
    title: "تقنيات التخطيط المتجاوب",
    description: "يتحقق من وجود دلائل على استخدام Media Queries أو Flexbox أو CSS Grid لدعم أحجام الشاشات المختلفة.",
    howToFix: "أضف breakpoints مناسبة واستخدم Flexbox أو CSS Grid للحاويات الرئيسية بدل الاعتماد على قياسات ثابتة فقط.",
    reason: "تم اكتشاف تقنيات تخطيط متجاوبة كافية.",
    status: "pass",
    occurrences: 0,
    issues: []
  }
];

const STANDARD_DATA = buildStandardDataFromReport(null);

function createEmptyCriterion14Report() {
  return {
    criterion: "05",
    criterionName: CRITERION_14_NAME,
    criterionNameAr: CRITERION_14_NAME_AR,
    pageUrl: "—",
    pageTitle: "الصفحة الحالية",
    scanDate: "",
    score: 100,
    status: "Passed",
    checks: {},
    summary: { ...EMPTY_SUMMARY },
    issues: []
  };
}

function normaliseIssueForPanel(issue, index) {
  const requirement = issue.requirement || "Responsive Design Check";
  return {
    ...issue,
    n: index + 1,
    target: issue.selector || issue.domPath || `[data-pc-responsive-id='${issue.id || index + 1}']`,
    element: issue.elementName || issue.linkText || "عنصر في الصفحة",
    current: issue.actual || issue.evidence || "يتطلب معالجة",
    suggested: issue.expected || "مطابقة متطلبات التصميم المتجاوب",
    location: `${issue.category || "Responsive Design"} · ${issue.selector || issue.domPath || "DOM"}`,
    requirement
  };
}

function buildStandardDataFromReport(report) {
  const safeReport = report || createEmptyCriterion14Report();
  const grouped = BASE_SUB_CRITERIA.map(item => ({ ...item, issues: [] }));

  (safeReport.issues || []).forEach((issue, index) => {
    const panelIssue = normaliseIssueForPanel(issue, index);
    const category = issue.category;
    const requirement = issue.requirement;

    const targetGroup = grouped.find(item =>
      item.category === category || item.requirement === requirement
    ) || grouped[0];

    targetGroup.issues.push(panelIssue);
  });

  grouped.forEach(item => {
    item.occurrences = item.issues.length;
    item.status = item.issues.length ? "fail" : "pass";
    if (item.issues.length) {
      item.reason = `تم العثور على ${item.issues.length} مشكلة ضمن هذا الفحص الفرعي.`;
    } else if (safeReport.checks) {
      const checkMap = {
        "Viewport Meta Tag": "viewport",
        "Horizontal Scrolling": "horizontalScroll",
        "Responsive Layout Techniques": "responsiveLayout"
      };
      const check = safeReport.checks[checkMap[item.requirement]];
      if (check?.detail) item.reason = check.detail;
    }
  });

  // Template calculation logic: passed sub-requirements / total sub-requirements × 100.
  const passedRequirements = grouped.filter(item => item.status === "pass").length;
  const templateScore = grouped.length ? Math.round((passedRequirements / grouped.length) * 100) : 100;
  const templateStatus = templateScore === 100 ? "Passed" : templateScore === 0 ? "Failed" : "Needs Review";

  const summary = { ...EMPTY_SUMMARY, ...(safeReport.summary || {}) };
  const scanDate = safeReport.scanDate || "";

  return {
    number: 5,
    category: "أساسات",
    categoryColor: CATEGORY_COLORS.Foundations,
    title: "الاستجابة لجميع الأجهزة",
    titleEn: CRITERION_14_NAME,
    description: "التأكد من أن الصفحة تعمل بشكل مناسب على الشاشات المختلفة عبر Viewport صحيح، عدم وجود تمرير أفقي، واستخدام تقنيات تخطيط متجاوبة.",
    reference: "DGA Design System: Layout & Spacing / Responsive Design",
    pageUrl: safeReport.pageUrl || "—",
    pageTitle: safeReport.pageTitle || "الصفحة الحالية",
    scanDate,
    scanDateFormatted: scanDate ? new Date(scanDate).toLocaleString("ar-SA") : "—",
    totalElementsScanned: summary.totalElementsScanned || summary.totalInteractiveElements || 0,
    affectedElements: summary.elementsWithIssues || summary.linksWithIssues || 0,
    score: templateScore,
    severityScore: typeof safeReport.score === "number" ? safeReport.score : 100,
    status: templateStatus,
    summary,
    report: safeReport,
    subCriteria: grouped
  };
}

function getIssueKey(issue) {
  return issue?.id || issue?.target || `issue-${issue?.n}`;
}

function getEffectiveSubCriteria(data, ignoredIssues = {}) {
  return data.subCriteria.map((criterion) => {
    const originalIssues = criterion.issues || [];
    const activeIssues = originalIssues.filter(
      (issue) => !ignoredIssues[getIssueKey(issue)]
    );
    const wasPass = criterion.status === "pass";
    const isPass = wasPass || activeIssues.length === 0;

    return {
      ...criterion,
      status: isPass ? "pass" : "fail",
      issues: activeIssues,
      occurrences: wasPass ? criterion.occurrences : activeIssues.length,
      reason:
        !wasPass && activeIssues.length === 0
          ? "تم تجاهل جميع العناصر المخالفة لهذا المتطلب."
          : criterion.reason
    };
  });
}

function getCurrentCriterion14Report() {
  return window.CURRENT_AUDIT_REPORT || window.STANDARD_DATA?.report || createEmptyCriterion14Report();
}

function setCurrentCriterion14Report(report) {
  window.CURRENT_AUDIT_REPORT = report || createEmptyCriterion14Report();
  window.STANDARD_DATA = buildStandardDataFromReport(window.CURRENT_AUDIT_REPORT);
  return window.STANDARD_DATA;
}

window.CRITERION_14_NAME = CRITERION_14_NAME;
window.CRITERION_14_NAME_AR = CRITERION_14_NAME_AR;
window.EMPTY_SUMMARY = EMPTY_SUMMARY;
window.STANDARD_DATA = STANDARD_DATA;
window.createEmptyCriterion14Report = createEmptyCriterion14Report;
window.buildStandardDataFromReport = buildStandardDataFromReport;
window.getCurrentCriterion14Report = getCurrentCriterion14Report;
window.setCurrentCriterion14Report = setCurrentCriterion14Report;
window.getIssueKey = getIssueKey;
window.getEffectiveSubCriteria = getEffectiveSubCriteria;
