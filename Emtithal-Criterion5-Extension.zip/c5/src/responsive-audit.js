(function () {
  "use strict";

  const CRITERION = "05";
  const CRITERION_NAME = "Responsive Design Compliance for All Devices";
  const CRITERION_NAME_AR = "معيار الاستجابة لجميع الأجهزة";

  const REQ_VIEWPORT = "Viewport Meta Tag";
  const REQ_SCROLL = "Horizontal Scrolling";
  const REQ_LAYOUT = "Responsive Layout Techniques";

  const CAT_VIEWPORT = "Viewport Meta Issue";
  const CAT_SCROLL = "Horizontal Overflow Issue";
  const CAT_LAYOUT = "Responsive Layout Issue";

  const TOLERANCE = 5;
  const MAX_ELEMENT_ISSUES = 40;

  function nowIso() { return new Date().toISOString(); }

  function cleanText(value, max = 180) {
    return String(value || "").replace(/\s+/g, " ").trim().slice(0, max);
  }

  function cssEscape(value) {
    if (window.CSS && typeof CSS.escape === "function") return CSS.escape(value);
    return String(value).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }

  function isVisible(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return false;
    const style = getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
    if (el.closest("[hidden],[aria-hidden='true']")) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function isDisabled(el) {
    return Boolean(el.disabled || el.getAttribute("aria-disabled") === "true" || el.closest("[disabled]"));
  }

  function getDomPath(el) {
    const path = [];
    let node = el;
    while (node && node.nodeType === Node.ELEMENT_NODE && node !== document.documentElement) {
      let part = node.localName;
      if (node.id) {
        part += `#${cssEscape(node.id)}`;
        path.unshift(part);
        break;
      }
      const parent = node.parentElement;
      if (parent) {
        const same = Array.from(parent.children).filter(child => child.localName === node.localName);
        if (same.length > 1) part += `:nth-of-type(${same.indexOf(node) + 1})`;
      }
      path.unshift(part);
      node = parent;
    }
    return path.join(" > ");
  }

  function getSelector(el) {
    if (!el || el.nodeType !== Node.ELEMENT_NODE) return "";
    if (el.id) return `#${cssEscape(el.id)}`;
    const auditId = el.getAttribute("data-pc-responsive-id");
    if (auditId) return `[data-pc-responsive-id='${cssEscape(auditId)}']`;
    const testId = el.getAttribute("data-testid") || el.getAttribute("data-test-id");
    if (testId) return `[data-testid='${cssEscape(testId)}']`;
    const aria = el.getAttribute("aria-label");
    if (aria && aria.length < 80) {
      const ariaSelector = `${el.localName}[aria-label='${cssEscape(aria)}']`;
      try { if (document.querySelectorAll(ariaSelector).length === 1) return ariaSelector; } catch (_) {}
    }
    return getDomPath(el) || el.localName || "element";
  }

  function elementName(el) {
    if (!el) return "الصفحة";
    const tag = el.localName || "element";
    const text = cleanText(el.innerText || el.textContent || el.getAttribute("aria-label") || el.getAttribute("title") || "", 60);
    return text ? `<${tag}> ${text}` : `<${tag}>`;
  }

  function makeIssue({ id, requirement, category, severity = "High", confidence = "High", element, selector, domPath, description, evidence, expected, actual, recommendation }) {
    const target = selector || (element ? getSelector(element) : "");
    return {
      id,
      requirement,
      category,
      severity,
      confidence,
      elementName: elementName(element),
      linkText: elementName(element),
      selector: target,
      domPath: domPath || (element ? getDomPath(element) : target),
      href: "",
      description,
      evidence,
      expected,
      actual,
      recommendation
    };
  }

  function checkViewportMeta() {
    const metaTags = Array.from(document.querySelectorAll('meta[name="viewport" i]'));
    if (metaTags.length === 0) {
      return {
        passed: false,
        detail: "لا يوجد وسم <meta name=\"viewport\"> في الصفحة.",
        evidence: [],
        issues: [makeIssue({
          id: "RESP-VIEWPORT-MISSING",
          requirement: REQ_VIEWPORT,
          category: CAT_VIEWPORT,
          severity: "Critical",
          confidence: "High",
          selector: "head",
          description: "الصفحة لا تحتوي على وسم Viewport المطلوب لدعم العرض الصحيح على الجوال والأجهزة المختلفة.",
          evidence: "meta[name=viewport] غير موجود داخل <head>.",
          expected: 'وجود <meta name="viewport" content="width=device-width, initial-scale=1">',
          actual: "وسم Viewport مفقود.",
          recommendation: 'أضف الوسم التالي داخل <head>: <meta name="viewport" content="width=device-width, initial-scale=1">.'
        })]
      };
    }

    for (const tag of metaTags) {
      const content = (tag.getAttribute("content") || "").toLowerCase();
      const pairs = content.split(",").reduce((acc, part) => {
        const [key, value] = part.trim().split("=").map(s => s.trim());
        if (key) acc[key] = value || "";
        return acc;
      }, {});

      const hasWidthDeviceWidth = pairs.width === "device-width";
      const hasInitialScale = pairs["initial-scale"] && parseFloat(pairs["initial-scale"]) === 1;
      if (hasWidthDeviceWidth && hasInitialScale) {
        return {
          passed: true,
          detail: `وسم Viewport صحيح: "${tag.getAttribute("content")}"`,
          evidence: [`content="${tag.getAttribute("content")}"`],
          issues: []
        };
      }

      return {
        passed: false,
        detail: `وسم Viewport موجود لكنه غير مكتمل: "${tag.getAttribute("content")}" — المطلوب width=device-width, initial-scale=1`,
        evidence: [`content="${tag.getAttribute("content")}"`],
        issues: [makeIssue({
          id: "RESP-VIEWPORT-INCOMPLETE",
          requirement: REQ_VIEWPORT,
          category: CAT_VIEWPORT,
          severity: "High",
          confidence: "High",
          element: tag,
          selector: 'meta[name="viewport"]',
          description: "وسم Viewport موجود لكن لا يحتوي على القيم الأساسية المطلوبة للاستجابة.",
          evidence: `content="${tag.getAttribute("content")}"`,
          expected: "width=device-width, initial-scale=1",
          actual: tag.getAttribute("content") || "فارغ",
          recommendation: "عدّل قيمة content في وسم Viewport لتشمل width=device-width و initial-scale=1."
        })]
      };
    }

    return { passed: false, detail: "وسم Viewport غير صحيح.", evidence: [], issues: [] };
  }

  function checkHorizontalScrolling() {
    const body = document.body || document.documentElement;
    const bodyScrollWidth = body.scrollWidth || 0;
    const bodyClientWidth = body.clientWidth || window.innerWidth;
    const docScrollWidth = document.documentElement.scrollWidth || 0;
    const docClientWidth = document.documentElement.clientWidth || window.innerWidth;
    const viewportWidth = window.innerWidth;

    const bodyOverflows = bodyScrollWidth > bodyClientWidth + TOLERANCE;
    const docOverflows = docScrollWidth > docClientWidth + TOLERANCE;
    const overflowing = [];

    const all = Array.from(document.querySelectorAll("body *"));
    for (const el of all) {
      if (!isVisible(el)) continue;
      const style = getComputedStyle(el);
      if (style.overflowX === "hidden" || style.overflowX === "clip") continue;
      const rect = el.getBoundingClientRect();
      if (rect.width <= 0) continue;
      if (rect.right > viewportWidth + TOLERANCE || rect.left < -TOLERANCE) {
        overflowing.push({ el, right: Math.round(rect.right), left: Math.round(rect.left), width: Math.round(rect.width) });
      }
      if (overflowing.length >= 80) break;
    }

    const hasOverflow = bodyOverflows || docOverflows || overflowing.length > 0;
    if (!hasOverflow) {
      return {
        passed: true,
        detail: `لا يوجد تمرير أفقي. body.scrollWidth=${bodyScrollWidth}px، viewport=${viewportWidth}px.`,
        evidence: [`body.scrollWidth=${bodyScrollWidth}`, `viewport=${viewportWidth}`],
        overflowingCount: 0,
        issues: []
      };
    }

    const elementIssues = overflowing.slice(0, MAX_ELEMENT_ISSUES).map((item, index) => makeIssue({
      id: `RESP-SCROLL-${index + 1}`,
      requirement: REQ_SCROLL,
      category: CAT_SCROLL,
      severity: "High",
      confidence: "High",
      element: item.el,
      description: "عنصر يتجاوز حدود عرض الشاشة وقد يسبب تمريرًا أفقيًا يكسر التخطيط.",
      evidence: `left=${item.left}px, right=${item.right}px, width=${item.width}px, viewport=${viewportWidth}px`,
      expected: "عدم تجاوز أي عنصر حدود الـ viewport وعدم ظهور تمرير أفقي غير مقصود.",
      actual: `العنصر يتجاوز عرض الشاشة (${viewportWidth}px).`,
      recommendation: "استخدم max-width:100%، flex-wrap، overflow-wrap، أو عدّل عرض الصور/الجداول/الحاويات الثابتة."
    }));

    const fallbackIssue = elementIssues.length ? [] : [makeIssue({
      id: "RESP-SCROLL-DOCUMENT",
      requirement: REQ_SCROLL,
      category: CAT_SCROLL,
      severity: "High",
      confidence: "High",
      selector: "body",
      description: "مستند الصفحة أعرض من نافذة العرض، مما يدل على وجود تمرير أفقي.",
      evidence: `body.scrollWidth=${bodyScrollWidth}, document.scrollWidth=${docScrollWidth}, viewport=${viewportWidth}`,
      expected: "عرض الصفحة يساوي أو يقل عن عرض نافذة العرض دون تمرير أفقي.",
      actual: "يوجد تجاوز أفقي في المستند.",
      recommendation: "راجع العناصر ذات العرض الثابت أو الجداول والصور والحاويات التي قد تتجاوز عرض الشاشة."
    })];

    return {
      passed: false,
      detail: `يوجد تمرير أفقي. body.scrollWidth=${bodyScrollWidth}px، viewport=${viewportWidth}px. العناصر المتجاوزة المكتشفة: ${overflowing.length}.`,
      evidence: overflowing.slice(0, 5).map(item => `${getSelector(item.el)} right=${item.right}px viewport=${viewportWidth}px`),
      overflowingCount: overflowing.length || 1,
      issues: elementIssues.concat(fallbackIssue)
    };
  }

  function checkResponsiveLayout() {
    const evidence = { mediaQueries: false, flexbox: false, grid: false, details: [] };

    try {
      const sheets = Array.from(document.styleSheets);
      for (const sheet of sheets) {
        let rules = [];
        try { rules = Array.from(sheet.cssRules || []); } catch (_) { continue; }
        for (const rule of rules) {
          if (rule.type === CSSRule.MEDIA_RULE) {
            const mediaText = rule.conditionText || rule.media?.mediaText || "";
            if (/max-width|min-width|max-device-width|min-device-width|orientation/i.test(mediaText)) {
              evidence.mediaQueries = true;
              evidence.details.push(`Media Query: @media ${mediaText}`);
              break;
            }
          }
        }
        if (evidence.mediaQueries) break;
      }
    } catch (_) {}

    const sampleSelectors = ["body", "main", "header", "footer", "nav", "section", "article", "aside", "div", "ul", "ol", "form", "[class]"];
    const sample = Array.from(document.querySelectorAll(sampleSelectors.join(","))).slice(0, 350);
    for (const el of sample) {
      if (!isVisible(el)) continue;
      const display = getComputedStyle(el).display;
      if (!evidence.flexbox && (display === "flex" || display === "inline-flex")) {
        evidence.flexbox = true;
        evidence.details.push(`Flexbox: ${getSelector(el)}`);
      }
      if (!evidence.grid && (display === "grid" || display === "inline-grid")) {
        evidence.grid = true;
        evidence.details.push(`CSS Grid: ${getSelector(el)}`);
      }
      if (evidence.mediaQueries && evidence.flexbox && evidence.grid) break;
    }

    const techniquesFound = [evidence.mediaQueries, evidence.flexbox, evidence.grid].filter(Boolean).length;
    const passed = evidence.mediaQueries || (evidence.flexbox && evidence.grid) || techniquesFound >= 2;
    const found = [
      evidence.mediaQueries && "Media Queries",
      evidence.flexbox && "Flexbox",
      evidence.grid && "CSS Grid"
    ].filter(Boolean).join("، ");

    if (passed) {
      return {
        passed: true,
        detail: `تقنيات التجاوب المكتشفة: ${found}.`,
        evidence: evidence.details.slice(0, 5),
        techniquesFound,
        issues: []
      };
    }

    return {
      passed: false,
      detail: `لم يُكتشف استخدام كافٍ لتقنيات التجاوب. المكتشف: ${found || "لا شيء"}.`,
      evidence: evidence.details.slice(0, 5),
      techniquesFound,
      issues: [makeIssue({
        id: "RESP-LAYOUT-TECHNIQUES",
        requirement: REQ_LAYOUT,
        category: CAT_LAYOUT,
        severity: "Medium",
        confidence: "Medium",
        selector: "body",
        description: "لم تظهر أدلة كافية على استخدام تقنيات تخطيط متجاوبة مثل Media Queries أو Flexbox أو CSS Grid.",
        evidence: `mediaQueries=${evidence.mediaQueries}, flexbox=${evidence.flexbox}, grid=${evidence.grid}`,
        expected: "استخدام Media Queries أو مزيج واضح من Flexbox وCSS Grid لدعم اختلاف أحجام الشاشات.",
        actual: found || "لم تُكتشف تقنيات تجاوب كافية.",
        recommendation: "أضف breakpoints مناسبة واستخدم Flexbox/CSS Grid للحاويات الرئيسية بدل القياسات الثابتة."
      })]
    };
  }

  function buildReport(checks) {
    const checkList = [checks.viewport, checks.horizontalScroll, checks.responsiveLayout];
    const issues = checkList.flatMap(check => check.issues || []);
    const passedChecks = checkList.filter(check => check.passed).length;
    const score = Math.round((passedChecks / checkList.length) * 100);
    const status = score === 100 ? "Passed" : score === 0 ? "Failed" : "Needs Review";

    return {
      criterion: CRITERION,
      criterionName: CRITERION_NAME,
      criterionNameAr: CRITERION_NAME_AR,
      pageUrl: location.href,
      pageTitle: document.title || "الصفحة الحالية",
      scanDate: nowIso(),
      score,
      status,
      checks: {
        viewport: checks.viewport,
        horizontalScroll: checks.horizontalScroll,
        responsiveLayout: checks.responsiveLayout
      },
      summary: {
        totalChecks: checkList.length,
        passedChecks,
        failedChecks: checkList.length - passedChecks,
        issuesCount: issues.length,
        viewportIssues: issues.filter(issue => issue.category === CAT_VIEWPORT).length,
        horizontalScrollIssues: issues.filter(issue => issue.category === CAT_SCROLL).length,
        responsiveLayoutIssues: issues.filter(issue => issue.category === CAT_LAYOUT).length,
        overflowingElements: checks.horizontalScroll.overflowingCount || 0,
        responsiveTechniquesFound: checks.responsiveLayout.techniquesFound || 0,
        elementsWithIssues: new Set(issues.map(issue => issue.selector || issue.domPath || issue.id)).size,
        totalElementsScanned: document.querySelectorAll("*").length,
        // aliases retained so the uploaded template components remain stable
        totalLinks: 0,
        internalLinks: 0,
        externalLinks: checks.horizontalScroll.overflowingCount || 0,
        linksWithIssues: new Set(issues.map(issue => issue.selector || issue.domPath || issue.id)).size,
        manualReview: checks.responsiveLayout.passed ? 0 : 1
      },
      issues
    };
  }

  function runAudit() {
    const checks = {
      viewport: checkViewportMeta(),
      horizontalScroll: checkHorizontalScrolling(),
      responsiveLayout: checkResponsiveLayout()
    };
    return buildReport(checks);
  }

  function clearHighlights() {
    document.querySelectorAll(".pc-responsive-highlight, .pc-responsive-label").forEach(node => node.remove());
    document.querySelectorAll("[data-pc-responsive-outline]").forEach(el => {
      el.style.outline = el.getAttribute("data-pc-responsive-old-outline") || "";
      el.style.outlineOffset = el.getAttribute("data-pc-responsive-old-outline-offset") || "";
      el.removeAttribute("data-pc-responsive-outline");
      el.removeAttribute("data-pc-responsive-old-outline");
      el.removeAttribute("data-pc-responsive-old-outline-offset");
    });
  }

  function findElement(issue) {
    if (!issue) return null;
    const selectors = [issue.selector, issue.domPath].filter(Boolean);
    for (const selector of selectors) {
      try {
        const el = document.querySelector(selector);
        if (el) return el;
      } catch (_) {}
    }
    return null;
  }

  function highlightIssues(items, label, options) {
    clearHighlights();
    const issues = Array.isArray(items) ? items : [];
    let count = 0;
    issues.forEach((issue, index) => {
      const el = findElement(issue);
      if (!el || !isVisible(el)) return;
      if (!el.getAttribute("data-pc-responsive-outline")) {
        el.setAttribute("data-pc-responsive-outline", "1");
        el.setAttribute("data-pc-responsive-old-outline", el.style.outline || "");
        el.setAttribute("data-pc-responsive-old-outline-offset", el.style.outlineOffset || "");
      }
      el.style.outline = "3px solid #C0392B";
      el.style.outlineOffset = "3px";
      const rect = el.getBoundingClientRect();
      const badge = document.createElement("div");
      badge.className = "pc-responsive-label";
      badge.textContent = `${index + 1}. ${label || issue.category || "Responsive issue"}`;
      Object.assign(badge.style, {
        position: "fixed",
        zIndex: "2147483647",
        top: `${Math.max(4, rect.top - 26)}px`,
        left: `${Math.max(4, Math.min(window.innerWidth - 220, rect.left))}px`,
        maxWidth: "220px",
        padding: "4px 8px",
        font: "12px/1.4 Tahoma, Arial, sans-serif",
        color: "#fff",
        background: "#C0392B",
        borderRadius: "6px",
        boxShadow: "0 3px 10px rgba(0,0,0,.25)",
        direction: "rtl"
      });
      document.documentElement.appendChild(badge);
      if (count === 0 && (!options || options.autoScroll !== false)) el.scrollIntoView({ behavior: "smooth", block: "center", inline: "center" });
      count += 1;
    });
    return count;
  }

  function highlightIssue(selector, domPath, category) {
    return highlightIssues([{ selector, domPath, category }], category, { autoScroll: true }) > 0;
  }

  window.PlatformsCodeCriterion14 = {
    runAudit,
    highlightIssues,
    highlightIssue,
    clearHighlights,
    version: "responsive-1.0.0"
  };
})();
