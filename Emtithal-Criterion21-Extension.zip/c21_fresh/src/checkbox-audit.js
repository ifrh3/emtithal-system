// checkbox-audit.js — Criterion 21: Checkbox Design System Compliance
// Injected into the active page via chrome.scripting.executeScript
(function () {
  "use strict";

  const CRITERION      = "21";
  const CRITERION_NAME = "Ensure Checkbox follows the Platforms Code Design System";

  const CAT_BASE    = "Base Design Mismatch";
  const CAT_STATE   = "Interactive State Issue";
  const CAT_CTX     = "Contextual State Issue";

  const REQ_BASE    = "Base Design Compliance";
  const REQ_STATE   = "Interactive States Compliance";
  const REQ_CTX     = "Contextual States Compliance";

  // ── Utilities ──────────────────────────────────────────────────────────────
  function nowIso() { return new Date().toISOString(); }

  function cleanText(v, max = 120) {
    return String(v || "").replace(/\s+/g, " ").trim().slice(0, max);
  }

  function cssEscape(v) {
    if (window.CSS && CSS.escape) return CSS.escape(v);
    return String(v).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }

  function cssNum(v) {
    const n = parseFloat(String(v || "").replace("px", ""));
    return isFinite(n) ? n : 0;
  }

  function parseRgb(color) {
    const s = String(color || "").trim().toLowerCase();
    if (!s || s === "transparent" || s === "rgba(0, 0, 0, 0)") return { r:0,g:0,b:0,a:0 };
    const m = s.match(/^rgba?\(([^)]+)\)$/);
    if (m) {
      const p = m[1].split(/[,/ ]+/).map(parseFloat).filter(isFinite);
      return { r:p[0]||0, g:p[1]||0, b:p[2]||0, a:p.length>3?p[3]:1 };
    }
    const h = s.match(/^#([0-9a-f]{3,8})$/i);
    if (h) {
      let v = h[1];
      if (v.length===3||v.length===4) v = v.split("").map(c=>c+c).join("");
      return { r:parseInt(v.slice(0,2),16), g:parseInt(v.slice(2,4),16), b:parseInt(v.slice(4,6),16), a:v.length>=8?parseInt(v.slice(6,8),16)/255:1 };
    }
    return { r:0,g:0,b:0,a:-1 };
  }

  function rgbToHsl(c) {
    const r=c.r/255, g=c.g/255, b=c.b/255;
    const max=Math.max(r,g,b), min=Math.min(r,g,b);
    let h=0,s=0; const l=(max+min)/2;
    if (max!==min) {
      const d=max-min;
      s=l>0.5?d/(2-max-min):d/(max+min);
      switch(max){ case r: h=(g-b)/d+(g<b?6:0); break; case g: h=(b-r)/d+2; break; case b: h=(r-g)/d+4; }
      h*=60;
    }
    return {h,s,l};
  }

  function isVisible(el) {
    if (!el||el.nodeType!==1) return false;
    const st=getComputedStyle(el);
    if (st.display==="none"||st.visibility==="hidden"||+st.opacity===0) return false;
    const r=el.getBoundingClientRect();
    return r.width>0&&r.height>0;
  }

  function isHiddenFromUsers(el) {
    if (!el) return true;
    const st=getComputedStyle(el), r=el.getBoundingClientRect();
    const vhidden=r.width<=1&&r.height<=1&&/absolute|fixed/.test(st.position)&&(cssNum(st.left)<-100);
    return st.display==="none"||st.visibility==="hidden"||+st.opacity===0||vhidden;
  }

  function getDomPath(el) {
    const parts=[]; let node=el;
    while(node&&node.nodeType===1&&node!==document.documentElement) {
      let part=node.localName;
      if(node.id){parts.unshift(`#${cssEscape(node.id)}`);break;}
      const parent=node.parentElement;
      if(parent){ const same=Array.from(parent.children).filter(c=>c.localName===node.localName); if(same.length>1) part+=`:nth-of-type(${same.indexOf(node)+1})`; }
      parts.unshift(part); node=parent;
    }
    return parts.join(" > ");
  }

  function getSelector(el) {
    if(el.id) return `#${cssEscape(el.id)}`;
    return getDomPath(el)||el.localName||"element";
  }

  function elDesc(el) {
    const tag=el.localName||"element";
    const id=el.id?`#${el.id}`:"";
    const cls=el.className&&typeof el.className==="string"?"."+el.className.trim().split(/\s+/).slice(0,2).join("."):"";
    const lbl=el.getAttribute("aria-label")||el.getAttribute("name")||el.getAttribute("id")||"";
    return `<${tag}${id}${cls}>${lbl?` "${cleanText(lbl,30)}"`:""}`;
  }

  // ── Issue builder ──────────────────────────────────────────────────────────
  let _seq=0;
  function buildIssue({requirement,category,severity,confidence,el,description,evidence,expected,actual,recommendation}) {
    _seq++;
    return {
      id: `C21-${String(_seq).padStart(3,"0")}`,
      requirement, category, severity, confidence,
      selector:    getSelector(el),
      domPath:     getDomPath(el),
      elementLabel: elDesc(el),
      href:        "",
      description, evidence, expected, actual, recommendation
    };
  }

  // ── Detect checkboxes ──────────────────────────────────────────────────────
  function detectCheckboxes() {
    const selectors = [
      "input[type='checkbox']",
      "[role='checkbox']",
      "[data-component*='checkbox' i]",
      "[data-testid*='checkbox' i]",
      "[class*='checkbox' i]:not(label):not(span.checkbox-label)",
      "[class*='check-box' i]:not(label)"
    ];
    const seen = new Set();
    const results = [];
    document.querySelectorAll(selectors.join(",")).forEach(el => {
      if (seen.has(el)) return;
      seen.add(el);
      if (el.localName==="input" && el.type!=="checkbox") return;
      results.push(el);
    });
    return results;
  }

  // ── Color family heuristic ─────────────────────────────────────────────────
  function isApprovedColorFamily(color) {
    const c = parseRgb(color);
    if (c.a <= 0.05) return true; // transparent is ok
    if (c.a < 0)    return true; // unknown — don't fail
    const hsl = rgbToHsl(c);
    const isGreen    = hsl.h>=100&&hsl.h<=175&&hsl.s>=0.18;
    const isNeutral  = hsl.s<=0.18;
    const isWhiteish = hsl.l>=0.85&&hsl.s<=0.2;
    return isGreen || isNeutral || isWhiteish;
  }

  function hasVisibleFill(color) { return parseRgb(color).a > 0.05; }

  function isNativeCheckbox(el) {
    return el.localName==="input" && el.type==="checkbox";
  }

  // ── Stylesheet state helpers (same pattern as criterion-14) ───────────────
  function splitSelectors(selectorText) {
    const parts=[]; let cur="",depth=0;
    for(const ch of selectorText) {
      if(ch==="("||ch==="[") depth++;
      if(ch===")"||ch==="]") depth=Math.max(0,depth-1);
      if(ch===","&&depth===0){parts.push(cur.trim());cur="";}
      else cur+=ch;
    }
    if(cur.trim()) parts.push(cur.trim());
    return parts;
  }

  function stripPseudo(sel) {
    return sel.replace(/::?[a-zA-Z-]+(?:\([^)]*\))?/g,"").replace(/\s+/g," ").trim();
  }

  function collectStateEvidence(el) {
    const states={hovered:false,pressed:false,focused:false,readOnly:false,disabled:false};
    const suspicious=[];
    Array.from(document.styleSheets||[]).forEach(sheet=>{
      let rules; try{ rules=sheet.cssRules; }catch(_){return;}
      Array.from(rules||[]).forEach(rule=>{
        if(!rule.selectorText) return;
        splitSelectors(rule.selectorText).forEach(selector=>{
          const lower=selector.toLowerCase();
          const matches=[];
          if(lower.includes(":hover"))     matches.push("hovered");
          if(lower.includes(":active"))    matches.push("pressed");
          if(lower.includes(":focus"))     matches.push("focused");
          if(lower.includes(":read-only")||lower.includes("[readonly")||lower.includes("[aria-readonly")) matches.push("readOnly");
          if(lower.includes(":disabled")||lower.includes("[disabled")||lower.includes("[aria-disabled")||lower.includes(".disabled")) matches.push("disabled");
          if(!matches.length) return;
          const base=stripPseudo(selector);
          if(!base) return;
          try {
            if(el.matches(base)) {
              matches.forEach(s=>{ states[s]=true; });
            }
          } catch(_){}
        });
      });
    });
    // DOM signals
    if(el.hasAttribute("disabled")||el.getAttribute("aria-disabled")==="true") states.disabled=true;
    if(el.hasAttribute("readonly")||el.getAttribute("aria-readonly")==="true")  states.readOnly=true;
    return {states, suspicious};
  }

  function findFocusSuppression(el) {
    const found=[];
    Array.from(document.styleSheets||[]).forEach(sheet=>{
      let rules; try{rules=sheet.cssRules;}catch(_){return;}
      const walk=list=>Array.from(list||[]).forEach(rule=>{
        if(rule.cssRules) return walk(rule.cssRules);
        if(!rule.selectorText||!rule.style) return;
        if(!rule.selectorText.toLowerCase().includes(":focus")) return;
        const base=stripPseudo(rule.selectorText);
        try{
          if(base&&el.matches(base)){
            const outline=rule.style.getPropertyValue("outline");
            const outlineW=rule.style.getPropertyValue("outline-width");
            const shadow=rule.style.getPropertyValue("box-shadow");
            const hasReplacement=shadow&&shadow!=="none";
            if((/none/i.test(outline)||(outlineW==="0"||/^0/.test(outline)))&&!hasReplacement) found.push(rule.selectorText);
          }
        }catch(_){}
      });
      walk(rules);
    });
    return found;
  }

  function runtimeFocusCheck(el) {
    if(isHiddenFromUsers(el)) return {checked:false,visible:true,reason:"hidden"};
    const prev=document.activeElement;
    const hadTab=el.hasAttribute("tabindex");
    const oldTab=el.getAttribute("tabindex");
    try {
      if(!hadTab&&el.getAttribute("role")==="checkbox") el.setAttribute("tabindex","0");
      el.focus({preventScroll:true});
      if(document.activeElement!==el) return {checked:false,visible:true,reason:"not focusable"};
      const st=getComputedStyle(el);
      const outlineW=cssNum(st.outlineWidth);
      const outlineOk=outlineW>0&&st.outlineStyle!=="none"&&parseRgb(st.outlineColor).a>0;
      const shadowOk=st.boxShadow&&st.boxShadow!=="none"&&!/^rgba?\(0,0,0,0\)/.test(st.boxShadow);
      return {checked:true, visible:outlineOk||shadowOk, reason:`outline=${st.outlineWidth} ${st.outlineStyle}`};
    }catch(e){
      return {checked:false,visible:true,reason:e?.message||"focus failed"};
    }finally{
      if(!hadTab) el.removeAttribute("tabindex"); else el.setAttribute("tabindex",oldTab);
      try{if(prev&&prev.focus) prev.focus({preventScroll:true});}catch(_){}
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 1 — Base Design Compliance
  // ══════════════════════════════════════════════════════════════════════════
  function auditBaseDesign(el, index, config, issues) {
    const st = getComputedStyle(el);
    const guard = config?.checkbox?.baseDesign || {};

    // 1-a: Inline style overrides (shape, color, spacing)
    const inlineStyle = el.getAttribute("style") || "";
    if (guard.disallowInlineStyleOverrides && inlineStyle &&
        /background|border|border-radius|padding|width|height|box-shadow/i.test(inlineStyle)) {
      issues.push(buildIssue({
        requirement: REQ_BASE, category: CAT_BASE, severity: "Medium", confidence: "High", el,
        description: "يوجد تنسيق مباشر (inline style) يعدّل شكل Checkbox الأساسي المعتمد في كود المنصات.",
        evidence:    `style="${cleanText(inlineStyle, 180)}"`,
        expected:    "استخدام مكوّن Checkbox الرسمي دون تعديلات على الشكل أو المسافات أو الألوان.",
        actual:      "تم العثور على تنسيقات مباشرة تؤثر على التصميم الأساسي.",
        recommendation: "أزل التنسيقات المباشرة واستخدم رموز التصميم الرسمية من كود المنصات."
      }));
    }

    // 1-b: Non-approved background color
    const bgColor = st.backgroundColor;
    if (guard.disallowCustomBackground && hasVisibleFill(bgColor) && !isApprovedColorFamily(bgColor)) {
      issues.push(buildIssue({
        requirement: REQ_BASE, category: CAT_BASE, severity: "High", confidence: "High", el,
        description: "لون خلفية Checkbox لا ينتمي إلى عائلة الألوان المعتمدة في كود المنصات.",
        evidence:    `background-color: ${bgColor}`,
        expected:    "الخلفية تكون من عائلة الأخضر المعتمد أو المحايد/الرمادي أو الشفاف.",
        actual:      `background-color: ${bgColor}`,
        recommendation: "استبدل اللون بالرمز المعتمد من نظام التصميم (var(--color-…))."
      }));
    }

    // 1-c: Border radius outside expected range
    if (!isNativeCheckbox(el)) {
      const radius = Math.max(
        cssNum(st.borderTopLeftRadius), cssNum(st.borderTopRightRadius),
        cssNum(st.borderBottomLeftRadius), cssNum(st.borderBottomRightRadius)
      );
      const approvedRadii = guard.expectedBorderRadius || [4, 6];
      const minR = approvedRadii[0], maxR = approvedRadii[approvedRadii.length-1];
      // Only flag if radius is drastically different (fully round = button-like)
      if (radius > 14) {
        issues.push(buildIssue({
          requirement: REQ_BASE, category: CAT_BASE, severity: "Medium", confidence: "High", el,
          description: "نصف قطر حواف Checkbox كبير جدًا ويجعله يشبه شكلًا دائريًا بدلاً من المربع المعتمد.",
          evidence:    `border-radius: ${radius}px`,
          expected:    `border-radius بين ${minR}px و${maxR}px للشكل المربع المعتمد.`,
          actual:      `border-radius: ${radius}px`,
          recommendation: "استخدم border-radius المعتمد من رموز التصميم (4-6px)."
        }));
      }
    }

    // 1-d: Button-like shape (padding + background = looks like a button)
    if (!isNativeCheckbox(el)) {
      const pX = cssNum(st.paddingLeft) + cssNum(st.paddingRight);
      const pY = cssNum(st.paddingTop)  + cssNum(st.paddingBottom);
      if (pX > 20 || pY > 12) {
        issues.push(buildIssue({
          requirement: REQ_BASE, category: CAT_BASE, severity: "High", confidence: "High", el,
          description: "Checkbox يحتوي على حشو (padding) كبير يجعله يشبه زرًا وليس مربع اختيار.",
          evidence:    `padding-x=${pX}px; padding-y=${pY}px`,
          expected:    "Checkbox عنصر مربع خفيف بحشو محدود وفق التصميم المعتمد.",
          actual:      `padding-x=${pX}px; padding-y=${pY}px`,
          recommendation: "أزل الحشو الزائد واستخدم مكوّن Checkbox الرسمي."
        }));
      }
    }

    // 1-e: Non-approved border color (custom/arbitrary color)
    const borderColor = st.borderColor || st.borderTopColor;
    if (borderColor && hasVisibleFill(borderColor) && !isApprovedColorFamily(borderColor)) {
      issues.push(buildIssue({
        requirement: REQ_BASE, category: CAT_BASE, severity: "Medium", confidence: "Medium", el,
        description: "لون حدود Checkbox لا ينتمي إلى عائلة الألوان المعتمدة في كود المنصات.",
        evidence:    `border-color: ${borderColor}`,
        expected:    "الحدود من عائلة الأخضر المعتمد أو المحايد/الرمادي.",
        actual:      `border-color: ${borderColor}`,
        recommendation: "استخدم رمز الحدود المعتمد من نظام التصميم."
      }));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 2 — Interactive States
  // ══════════════════════════════════════════════════════════════════════════
  function auditInteractiveStates(el, index, config, issues) {
    const stateEv  = collectStateEvidence(el);
    const focusSup = findFocusSuppression(el);
    const focusRT  = runtimeFocusCheck(el);
    const cfg      = config?.checkbox?.interactiveStates || {};

    // 2-a: Focus not visible
    if (cfg.focusMustBeVisible !== false) {
      if (focusSup.length > 0 || (focusRT.checked && !focusRT.visible)) {
        issues.push(buildIssue({
          requirement: REQ_STATE, category: CAT_STATE, severity: "Critical", confidence: "High", el,
          description: "حالة التركيز (Focused) لـ Checkbox غير ظاهرة أو تم تعطيل outline التركيز.",
          evidence:    focusSup.length ? `focus suppression: ${focusSup.slice(0,3).join(" | ")}` : focusRT.reason,
          expected:    "عند التركيز يظهر إطار واضح (outline) حول Checkbox كما هو معتمد في كود المنصات.",
          actual:      "لم يظهر مؤشر تركيز واضح أو وُجدت قاعدة CSS تزيله.",
          recommendation: "أعد تفعيل focus outline المعتمد لـ Checkbox."
        }));
      }
    }

    // 2-b: Disabled still interactive
    if (cfg.disabledMustBeNonInteractive !== false) {
      const isDisabledDOM = el.hasAttribute("disabled") || el.getAttribute("aria-disabled")==="true"
        || /(^|\s)(disabled|is-disabled)(\s|$)/i.test(el.className||"");
      const st = getComputedStyle(el);
      if (isDisabledDOM && st.pointerEvents !== "none" && el.tabIndex >= 0 && !isNativeCheckbox(el)) {
        issues.push(buildIssue({
          requirement: REQ_STATE, category: CAT_STATE, severity: "High", confidence: "High", el,
          description: "Checkbox معلّم كمعطل (Disabled) لكنه ما زال تفاعليًا وقابلًا للتركيز.",
          evidence:    `aria-disabled/disabled detected; pointer-events=${st.pointerEvents}; tabIndex=${el.tabIndex}`,
          expected:    "Checkbox المعطل لا يكون قابلًا للنقر أو التركيز.",
          actual:      "Checkbox يبدو معطلًا لكنه ما زال تفاعليًا.",
          recommendation: "أضف pointer-events:none وtabindex=-1 للـ Checkbox المعطل."
        }));
      }
    }

    // 2-c: No hover/focus state evidence at all (CSS missing entirely)
    const hasAnyInteractive = stateEv.states.hovered || stateEv.states.focused || stateEv.states.disabled;
    if (!hasAnyInteractive && !isNativeCheckbox(el) && isVisible(el)) {
      issues.push(buildIssue({
        requirement: REQ_STATE, category: CAT_STATE, severity: "Medium", confidence: "Medium", el,
        description: "لم يتم العثور على أي قواعد CSS للحالات التفاعلية (Hover, Focus, Disabled) لهذا Checkbox.",
        evidence:    "لا توجد قواعد :hover/:focus/:disabled مطابقة للعنصر في أوراق الأنماط.",
        expected:    "حالات Default, Hovered, Focused, Read-only, Disabled جميعها مُعرَّفة في CSS.",
        actual:      "لم يتم العثور على قواعد الحالات التفاعلية.",
        recommendation: "أضف حالات التفاعل المعتمدة من مكوّن Checkbox في كود المنصات."
      }));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 3 — Contextual States (Checked / Unchecked / Indeterminate)
  // ══════════════════════════════════════════════════════════════════════════
  function auditContextualStates(el, index, config, issues) {
    const cfg = config?.checkbox?.contextualStates || {};

    // Determine current state
    const isChecked       = el.checked === true  || el.getAttribute("aria-checked") === "true";
    const isUnchecked     = el.checked === false || el.getAttribute("aria-checked") === "false";
    const isIndeterminate = el.indeterminate === true || el.getAttribute("aria-checked") === "mixed"
      || /(indeterminate|mixed|partial)/i.test(el.className||"")
      || el.getAttribute("data-state") === "indeterminate";

    // 3-a: Check visual indication exists for checked state
    if (isChecked) {
      const st = getComputedStyle(el);
      // For native inputs browser handles this; for custom we check content/background
      if (!isNativeCheckbox(el)) {
        const hasCheckmark =
          st.content !== "none" && st.content !== '""' && st.content !== "" ||
          el.querySelector("svg,i,[class*='check'],[class*='icon']") !== null ||
          st.backgroundImage !== "none";
        if (!hasCheckmark) {
          issues.push(buildIssue({
            requirement: REQ_CTX, category: CAT_CTX, severity: "High", confidence: "Medium", el,
            description: "Checkbox في حالة Checked لكن لا توجد علامة ظاهرة (checkmark) على العنصر المخصص.",
            evidence:    `aria-checked=true/checked; content=${st.content}; background-image=${st.backgroundImage}`,
            expected:    "يجب ظهور علامة الاختيار (checkmark) داخل Checkbox عند تحديده.",
            actual:      "لم يتم العثور على علامة اختيار ظاهرة في الحالة Checked.",
            recommendation: "أضف checkmark مرئيًا (SVG أو CSS content) للحالة Checked."
          }));
        }
      }
    }

    // 3-b: Indeterminate state support check
    // Only check for custom checkboxes or where indeterminate signals exist
    if (!isNativeCheckbox(el)) {
      const signals = cfg.indeterminateSignals || ["indeterminate","mixed","partial"];
      const supportsIndet = signals.some(sig =>
        (el.className||"").toLowerCase().includes(sig.toLowerCase()) ||
        el.getAttribute("aria-checked")==="mixed" ||
        el.getAttribute("data-state")==="indeterminate"
      );
      // Check if CSS has indeterminate rules at all
      let hasIndetCss = false;
      Array.from(document.styleSheets||[]).forEach(sheet=>{
        try{Array.from(sheet.cssRules||[]).forEach(rule=>{
          if(rule.selectorText&&(rule.selectorText.includes("indeterminate")||rule.selectorText.includes("mixed")||rule.selectorText.includes("partial"))) hasIndetCss=true;
        });}catch(_){}
      });
      if (!hasIndetCss && isVisible(el)) {
        issues.push(buildIssue({
          requirement: REQ_CTX, category: CAT_CTX, severity: "Medium", confidence: "Medium", el,
          description: "لم يتم العثور على قواعد CSS لحالة Indeterminate للـ Checkbox المخصص.",
          evidence:    "لا توجد قواعد :indeterminate أو .indeterminate في أوراق الأنماط.",
          expected:    "يجب تعريف مظهر مخصص لحالة Indeterminate (شرطة أفقية) في CSS.",
          actual:      "حالة Indeterminate غير مُعرَّفة مرئيًا.",
          recommendation: "أضف قاعدة CSS لحالة Indeterminate مع شرطة أفقية وفق مرجع كود المنصات."
        }));
      }
    }

    // 3-c: role="checkbox" without aria-checked
    if (el.getAttribute("role")==="checkbox" && el.getAttribute("aria-checked")===null) {
      issues.push(buildIssue({
        requirement: REQ_CTX, category: CAT_CTX, severity: "Critical", confidence: "High", el,
        description: "Checkbox مخصص يستخدم role='checkbox' بدون خاصية aria-checked — حالته السياقية غير معلنة للتقنيات المساعدة.",
        evidence:    `role="checkbox" aria-checked missing`,
        expected:    'aria-checked="true"/"false"/"mixed" يجب أن تكون موجودة وتُحدَّث عند التغيير.',
        actual:      "aria-checked غير موجودة.",
        recommendation: 'أضف aria-checked="false" كقيمة ابتدائية وحدّثها عند التفاعل.'
      }));
    }

    // 3-d: Native checkbox wrapped without sync
    if (isNativeCheckbox(el)) {
      const parent = el.closest("[role='checkbox']");
      if (parent && parent !== el) {
        const parentChecked = parent.getAttribute("aria-checked");
        const actualChecked = el.checked ? "true" : (el.indeterminate ? "mixed" : "false");
        if (parentChecked !== null && parentChecked !== actualChecked) {
          issues.push(buildIssue({
            requirement: REQ_CTX, category: CAT_CTX, severity: "High", confidence: "High", el,
            description: "aria-checked في العنصر الحاوي لا يتطابق مع الحالة الفعلية للـ <input type=checkbox>.",
            evidence:    `parent aria-checked="${parentChecked}"; input checked=${el.checked}; indeterminate=${el.indeterminate}`,
            expected:    "aria-checked في العنصر الحاوي يجب أن يعكس الحالة الفعلية دائمًا.",
            actual:      `aria-checked="${parentChecked}" لكن الحالة الفعلية="${actualChecked}".`,
            recommendation: "زامن aria-checked مع حالة <input> عند كل تغيير."
          }));
        }
      }
    }
  }

  // ── Summary ────────────────────────────────────────────────────────────────
  function buildSummary(checkboxes, allIssues) {
    const affected = new Set(allIssues.map(i=>i.selector||i.domPath));
    return {
      totalCheckboxes:         checkboxes.length,
      nativeCheckboxes:        checkboxes.filter(isNativeCheckbox).length,
      customCheckboxes:        checkboxes.filter(el=>!isNativeCheckbox(el)).length,
      checkboxesWithIssues:    affected.size,
      issuesCount:             allIssues.length,
      baseDesignMismatch:      allIssues.filter(i=>i.category===CAT_BASE).length,
      interactiveStateIssue:   allIssues.filter(i=>i.category===CAT_STATE).length,
      contextualStateIssue:    allIssues.filter(i=>i.category===CAT_CTX).length,
      bySeverity: {
        Critical: allIssues.filter(i=>i.severity==="Critical").length,
        High:     allIssues.filter(i=>i.severity==="High").length,
        Medium:   allIssues.filter(i=>i.severity==="Medium").length,
        Low:      allIssues.filter(i=>i.severity==="Low").length
      }
    };
  }

  function computeScore(issues, config) {
    const w = {Critical:34,High:20,Medium:10,Low:5,"Manual Review":1,...(config?.scoring||{})};
    return Math.max(0, 100 - issues.reduce((s,i)=>s+(w[i.severity]||0),0));
  }

  // ── Main ───────────────────────────────────────────────────────────────────
  async function runAudit(config={}) {
    _seq=0;
    const checkboxes = detectCheckboxes();
    const allIssues  = [];

    checkboxes.forEach((el, idx) => {
      if (!isVisible(el)) return;
      auditBaseDesign(el, idx+1, config, allIssues);
      auditInteractiveStates(el, idx+1, config, allIssues);
      auditContextualStates(el, idx+1, config, allIssues);
    });

    const score   = computeScore(allIssues, config);
    const hasCrit = allIssues.some(i=>i.severity==="Critical");
    const status  = score===100?"Passed":(score<70||hasCrit)?"Failed":"Needs Review";
    const summary = buildSummary(checkboxes, allIssues);

    return {
      criterion:      CRITERION,
      criterionName:  CRITERION_NAME,
      pageUrl:        location.href,
      pageTitle:      document.title,
      scanDate:       nowIso(),
      score, status, summary,
      issues: allIssues
    };
  }

  // ── Highlight helpers (same pattern as criterion-14) ─────────────────────
  function getHState() {
    if(!window.__pcC21Highlights) window.__pcC21Highlights={items:[],timer:null};
    return window.__pcC21Highlights;
  }

  function clearHighlights() {
    const st=getHState();
    if(st.timer){clearTimeout(st.timer);st.timer=null;}
    st.items.forEach(r=>{
      if(!r.el||!r.el.style) return;
      r.el.style.outline=r.outline; r.el.style.outlineOffset=r.outlineOffset;
      r.el.style.boxShadow=r.boxShadow; r.el.style.scrollMargin=r.scrollMargin;
    });
    st.items=[];
    document.querySelectorAll("[data-pc-c21-badge='1']").forEach(n=>n.remove());
    return true;
  }

  function findEl(selector,domPath) {
    let el=null;
    if(selector){try{el=document.querySelector(selector);}catch(_){}}
    if(!el&&domPath){try{el=document.querySelector(domPath);}catch(_){}}
    return el;
  }

  function addBadge(el,label,index) {
    const rect=el.getBoundingClientRect();
    const b=document.createElement("div");
    b.setAttribute("data-pc-c21-badge","1");
    b.textContent=`${index}. ${label||"C21"}`;
    b.style.cssText=["position:absolute",`top:${Math.max(8,rect.top+window.scrollY-26)}px`,`left:${Math.max(8,rect.left+window.scrollX)}px`,"z-index:2147483647","background:#b91c1c","color:#fff","font:600 10px system-ui,sans-serif","padding:2px 7px","border-radius:999px","box-shadow:0 2px 8px rgba(0,0,0,.3)","pointer-events:none"].join(";");
    document.documentElement.appendChild(b);
  }

  function highlightIssues(items,label) {
    clearHighlights();
    const st=getHState(), seen=new Set(), els=[];
    (items||[]).forEach(item=>{
      const el=findEl(item.selector,item.domPath);
      if(!el||seen.has(el)) return;
      seen.add(el); els.push({el,label:item.category||label||"C21"});
    });
    els.forEach((item,i)=>{
      const el=item.el;
      st.items.push({el,outline:el.style.outline,outlineOffset:el.style.outlineOffset,boxShadow:el.style.boxShadow,scrollMargin:el.style.scrollMargin});
      el.style.outline="3px solid #b91c1c"; el.style.outlineOffset="3px";
      el.style.boxShadow="0 0 0 5px rgba(185,28,28,0.18)"; el.style.scrollMargin="96px";
      addBadge(el,item.label,i+1);
    });
    if(els[0]) els[0].el.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"});
    st.timer=window.setTimeout(()=>clearHighlights(),9000);
    return els.length;
  }

  function highlightIssue(selector,domPath,label) {
    return highlightIssues([{selector,domPath,category:label}],label)>0;
  }

  window.PlatformsCodeCheckboxAudit = {runAudit,highlightIssue,highlightIssues,clearHighlights};
})();
