// data.js — Criterion 21: Checkbox Design System Compliance
// Same structure as the template — only labels and categories changed.

const CRITERION_21_NAME    = "Ensure Checkbox follows the Platforms Code Design System";
const CRITERION_21_NAME_AR = "ضمان أن عنصر مربع الاختيار يتبع النظام التصميمي الموحد (كود المنصات)";

const CATEGORY_COLORS = {
  Foundations:"#E5E500", Templates:"#E49EDD", Components:"#94DCF8", Experience:"#9DA6F3",
  "أساسات":"#E5E500", "قوالب":"#E49EDD", "عناصر":"#94DCF8", "التجربة":"#9DA6F3"
};

const EMPTY_SUMMARY = {
  totalCheckboxes:0, nativeCheckboxes:0, customCheckboxes:0,
  checkboxesWithIssues:0, issuesCount:0,
  baseDesignMismatch:0, interactiveStateIssue:0, contextualStateIssue:0,
  bySeverity:{Critical:0,High:0,Medium:0,Low:0}
};

// ── 3 sub-criteria matching the 3 requirements ────────────────────────────
const BASE_SUB_CRITERIA = [
  {
    id:          "base-design-compliance",
    requirement: "Base Design Compliance",
    category:    "Base Design Mismatch",
    title:       "مطابقة التصميم الأساسي لـ Checkbox",
    description: "التحقق من أن عنصر Checkbox يستخدم الشكل، الحواف، اللون، المسافات وجميع خصائص التصميم كما هي معتمدة في كود المنصات دون أي تعديل على التصميم الأساسي.",
    howToFix:    "استخدم مكوّن Checkbox الرسمي من كود المنصات. أزل أي تنسيقات مباشرة تعدل الشكل الأساسي أو الألوان أو المسافات.",
    reason:      "لم يتم العثور على مخالفات مؤكدة في التصميم الأساسي لـ Checkbox.",
    status:      "pass",
    occurrences: 0,
    issues:      []
  },
  {
    id:          "interactive-states-compliance",
    requirement: "Interactive States Compliance",
    category:    "Interactive State Issue",
    title:       "تطبيق الحالات التفاعلية",
    description: "التحقق من تطبيق جميع الحالات التفاعلية المعتمدة: Default, Hovered, Focused, Read-only, Disabled — كما هو معتمد في كود المنصات.",
    howToFix:    "عرّف حالات :hover و:focus و:disabled و:read-only باستخدام أنماط نظام التصميم الرسمي. تأكد من ظهور focus outline واضح وأن الحالة المعطلة غير تفاعلية.",
    reason:      "تم العثور على أدلة كافية على الحالات التفاعلية المطلوبة.",
    status:      "pass",
    occurrences: 0,
    issues:      []
  },
  {
    id:          "contextual-states-compliance",
    requirement: "Contextual States Compliance",
    category:    "Contextual State Issue",
    title:       "تطبيق الحالات السياقية (Checked / Unchecked / Indeterminate)",
    description: "التحقق من تطبيق الحالات السياقية الثلاثة: Checked (علامة الاختيار)، Unchecked (فارغ)، Indeterminate (شرطة أفقية) — كما هو معتمد في كود المنصات.",
    howToFix:    "تأكد من وجود مظهر مرئي واضح لكل حالة. أضف aria-checked للعناصر المخصصة. عرّف حالة Indeterminate بشرطة أفقية في CSS.",
    reason:      "جميع الحالات السياقية المطلوبة مُطبَّقة بشكل صحيح.",
    status:      "pass",
    occurrences: 0,
    issues:      []
  }
];

// ── Normalise raw issue for the panel ─────────────────────────────────────
function normaliseIssueForPanel(issue, index) {
  return {
    ...issue,
    n:         index + 1,
    target:    issue.selector || issue.domPath || `[data-pc-c21-id='${issue.id||index+1}']`,
    element:   issue.elementLabel || issue.selector || "عنصر Checkbox",
    current:   issue.actual   || issue.evidence || "يتطلب مراجعة",
    suggested: issue.expected || "مطابقة مكوّن Checkbox الرسمي في كود المنصات",
    location:  `${issue.category} · ${issue.selector||issue.domPath||"DOM"}`
  };
}

function createEmptyCriterion21Report() {
  return {
    criterion:      "21",
    criterionName:  CRITERION_21_NAME,
    criterionNameAr: CRITERION_21_NAME_AR,
    pageUrl:        "—",
    pageTitle:      "",
    scanDate:       "",
    score:          100,
    status:         "Passed",
    summary:        {...EMPTY_SUMMARY},
    issues:         []
  };
}

function buildStandardDataFromReport(report) {
  const safeReport = report || createEmptyCriterion21Report();
  const grouped    = BASE_SUB_CRITERIA.map(item => ({...item, issues:[]}));

  (safeReport.issues||[]).forEach((issue,idx) => {
    const pi     = normaliseIssueForPanel(issue, idx);
    const target = grouped.find(g => g.category===issue.category || g.requirement===issue.requirement) || grouped[0];
    target.issues.push(pi);
  });

  grouped.forEach(item => {
    item.occurrences = item.issues.length;
    item.status      = item.issues.length ? "fail" : "pass";
    if (item.issues.length) item.reason = `تم العثور على ${item.issues.length} عنصر يحتاج إلى معالجة ضمن هذا المتطلب.`;
  });

  // Score = passed reqs / 3 × 100  (same template formula)
  const passed  = grouped.filter(g=>g.status==="pass").length;
  const total   = grouped.length;
  const tScore  = Math.round((passed/total)*100);
  const tStatus = tScore===100?"Passed":tScore===0?"Failed":"Needs Review";

  const summary  = {...EMPTY_SUMMARY,...(safeReport.summary||{})};
  const scanDate = safeReport.scanDate||"";

  return {
    number:             21,
    category:           "عناصر",
    categoryColor:      CATEGORY_COLORS["عناصر"],
    title:              "مطابقة عنصر Checkbox لنظام كود المنصات",
    titleEn:            CRITERION_21_NAME,
    description:        "التأكد من أن عنصر Checkbox يطابق التصميم الرسمي في كود المنصات، بما يشمل التصميم الأساسي، الحالات التفاعلية، والحالات السياقية.",
    reference:          "https://design.dga.gov.sa/guidelines/components/forms | Figma: Components Library - Platforms Code",
    pageUrl:            safeReport.pageUrl||"—",
    pageTitle:          safeReport.pageTitle||"الصفحة الحالية",
    scanDate,
    scanDateFormatted:  scanDate ? new Date(scanDate).toLocaleString("ar-SA") : "—",
    totalElementsScanned: summary.totalCheckboxes||0,
    affectedElements:   summary.checkboxesWithIssues||0,
    score:              tScore,
    severityScore:      typeof safeReport.score==="number"?safeReport.score:100,
    status:             tStatus,
    summary,
    report:             safeReport,
    subCriteria:        grouped
  };
}

function getIssueKey(issue) {
  return issue?.id||issue?.target||`issue-${issue?.n}`;
}

function getEffectiveSubCriteria(data, ignoredIssues={}) {
  return data.subCriteria.map(criterion=>{
    const original  = criterion.issues||[];
    const active    = original.filter(i=>!ignoredIssues[getIssueKey(i)]);
    const wasPass   = criterion.status==="pass";
    const isPass    = wasPass||active.length===0;
    return {
      ...criterion,
      status:      isPass?"pass":"fail",
      issues:      active,
      occurrences: wasPass?criterion.occurrences:active.length,
      reason:      !wasPass&&active.length===0?"تم تجاهل جميع العناصر المخالفة لهذا المتطلب.":criterion.reason
    };
  });
}

function getCurrentCriterion21Report() {
  return window.CURRENT_C21_REPORT || createEmptyCriterion21Report();
}
function setCurrentCriterion21Report(report) {
  window.CURRENT_C21_REPORT = report || createEmptyCriterion21Report();
  window.STANDARD_DATA = buildStandardDataFromReport(window.CURRENT_C21_REPORT);
  return window.STANDARD_DATA;
}

const STANDARD_DATA = buildStandardDataFromReport(null);

// Aliases for template compatibility
window.CRITERION_21_NAME        = CRITERION_21_NAME;
window.CRITERION_21_NAME_AR     = CRITERION_21_NAME_AR;
window.EMPTY_SUMMARY            = EMPTY_SUMMARY;
window.STANDARD_DATA            = STANDARD_DATA;
window.createEmptyCriterion14Report    = createEmptyCriterion21Report;
window.createEmptyCriterion21Report    = createEmptyCriterion21Report;
window.buildStandardDataFromReport     = buildStandardDataFromReport;
window.getCurrentCriterion14Report     = getCurrentCriterion21Report;
window.getCurrentCriterion21Report     = getCurrentCriterion21Report;
window.setCurrentCriterion14Report     = setCurrentCriterion21Report;
window.setCurrentCriterion21Report     = setCurrentCriterion21Report;
window.getIssueKey                     = getIssueKey;
window.getEffectiveSubCriteria         = getEffectiveSubCriteria;
