const fs=require("fs"),path=require("path"),vm=require("vm");
const root=path.resolve(__dirname,"..");
const sandbox={};vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root,"vendor","babel-standalone.min.js"),"utf8"),sandbox);
const files=["src/data.js","src/api-client.js","src/side-panel.jsx","src/options-page.jsx","src/report-preview.jsx","src/extension-app.jsx"];
const chunks=["// Generated bundle — Criterion 10 Search\n"];
for(const file of files){
  const src=fs.readFileSync(path.join(root,file),"utf8");
  const t=sandbox.Babel.transform(src,{presets:["react"],comments:true,compact:false}).code;
  chunks.push("\n// ---- "+file+" ----\n(function(){\n"+t+"\n})();\n");
}
fs.mkdirSync(path.join(root,"dist"),{recursive:true});
fs.writeFileSync(path.join(root,"dist","criterion10-extension.bundle.js"),chunks.join("\n"));
console.log("Built "+root);
