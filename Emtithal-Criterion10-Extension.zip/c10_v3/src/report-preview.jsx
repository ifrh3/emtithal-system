// Report Preview — Criterion 10: Search Template
function ReportPreview({
  format,
  onChangeFormat,
  onBack,
  onDownload,
  onSubmitReport,
  reportSubmitState = "idle",
  canSubmitReport = false,
  settings,
  report: inputReport
}) {
  const report = inputReport || getCurrentCriterion10Report();
  const data = buildStandardDataFromReport(report);
  const summary = report.summary || {};
  const issues = report.issues || [];
  const ratio = typeof data.score === "number" ? data.score : 100;
  const statusLabel = data.status === "Passed" ? "امتثال كامل" : data.status === "Failed" ? "غير ممتثل" : "امتثال جزئي";
  const statusClass = data.status === "Passed" ? "success" : data.status === "Failed" ? "fail" : "partial";
  const canSendToPlatform = window.isSaudiWebsiteUrl?.(report.pageUrl);
  const activeFormat = canSendToPlatform ? format : "PDF";
  const isSubmittingReport = reportSubmitState === "sending";
  const submitButtonLabel = reportSubmitState === "sent" ? "تم الإرسال" : isSubmittingReport ? "جار الإرسال..." : "إرسال لمنصة امتثال";

  const csvEscape = (value) => `"${String(value ?? "").replace(/"/g, '""')}"`;
  const csvRows = [
    ["id","requirement","category","severity","confidence","element_label","selector","description","expected","actual","recommendation"],
    ...issues.map(i => [i.id,i.requirement,i.category,i.severity,i.confidence,i.elementLabel,i.selector||i.domPath,i.description,i.expected,i.actual,i.recommendation])
  ].map(row => row.map(csvEscape).join(",")).join("\n");

  return (
    <div className="report-shell" data-screen-label="Report Preview">
      <div className="report-page">
        <div className="report-toolbar">
          <div className="left">
            <button className="btn" onClick={onBack}>← العودة</button>
            <span>معاينة التقرير</span>
          </div>
          <div className="row-flex report-actions" style={{gap:12}}>
            <div className="report-fmt-pick">
              {(canSendToPlatform ? ["PDF","CSV","JSON"] : ["PDF"]).map(f=>(
                <button key={f} className={"chip"+(activeFormat===f?" active":"")} onClick={()=>onChangeFormat(f)}>{f}</button>
              ))}
            </div>
            {canSendToPlatform && (
              <button
                className="btn report-submit-btn"
                onClick={()=>onSubmitReport?.(report)}
                disabled={!canSubmitReport || isSubmittingReport}
                title={canSubmitReport ? "إرسال نتيجة التقرير إلى منصة امتثال" : "الإرسال متاح لمواقع .sa المرتبطة فقط"}
                aria-label="إرسال نتيجة التقرير إلى منصة امتثال"
              >
                {submitButtonLabel}
              </button>
            )}
            <button className="btn primary" onClick={()=>onDownload(activeFormat,report)}>تنزيل التقرير {activeFormat}</button>
          </div>
        </div>

        {activeFormat==="PDF" && (
          <div className="report-doc">
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",borderBottom:"2px solid var(--text)",paddingBottom:14,marginBottom:18}}>
              <div>
                <h1>تقرير فحص الامتثال</h1>
                <div className="sub">{settings.extName} · معيار {report.criterion||"10"} — {data.title}</div>
              </div>
              <div style={{textAlign:"end",fontSize:11,color:"var(--text-3)"}}>
                <div>{data.scanDateFormatted||"—"}</div>
                <div>الحالة: {statusLabel}</div>
              </div>
            </div>
            <div className="summary-card">
              <div className={"pct "+statusClass}>{ratio}%</div>
              <div style={{flex:1}}>
                <div style={{fontSize:14,fontWeight:700,color:"var(--text)"}}>{statusLabel}</div>
                <div style={{fontSize:12,marginTop:2}}>
                  فحص {summary.totalSearchFields||0} حقل بحث · بطاقات نتائج: {summary.resultCardsFound||0} · ترقيم: {summary.paginationFound?'✓':'✗'} · مشاكل: {summary.issuesCount||0}.
                </div>
              </div>
            </div>
            <h2>معلومات الفحص</h2>
            <dl>
              <dt>اسم الإضافة</dt><dd>{settings.extName}</dd>
              <dt>رقم المعيار</dt><dd>{report.criterion||"10"}</dd>
              <dt>اسم المعيار</dt><dd>{report.criterionNameAr||report.criterionName}</dd>
              <dt>رابط الصفحة</dt><dd style={{fontFamily:"ui-monospace,monospace",direction:"ltr",textAlign:"start"}}>{report.pageUrl}</dd>
              <dt>وقت الفحص</dt><dd>{data.scanDateFormatted||"—"}</dd>
              <dt>حقول البحث المكتشفة</dt><dd>{summary.totalSearchFields||0} (ظاهر: {summary.searchFieldsVisible||0})</dd>
              <dt>صفحة نتائج</dt><dd>{summary.isResultsPage ? "نعم" : "لا (صفحة عادية)"}</dd>
              <dt>عناصر بها مشاكل</dt><dd>{summary.fieldsWithIssues||0}</dd>
              <dt>إجمالي المشاكل</dt><dd>{summary.issuesCount||0}</dd>
            </dl>
            <h2>توزيع المشاكل حسب المتطلب</h2>
            <table>
              <thead><tr><th>المتطلب</th><th>العدد</th></tr></thead>
              <tbody>
                <tr><td>شريط البحث (DgaSearchBox)</td><td>{summary.searchBoxIssue||0}</td></tr>
                <tr><td>عرض النتائج (بطاقات + عنوان)</td><td>{summary.resultsIssue||0}</td></tr>
                <tr><td>أدوات الترتيب والفلترة</td><td>{summary.controlsIssue||0}</td></tr>
                <tr><td>الترقيم والتغذية الراجعة</td><td>{summary.paginationIssue||0}</td></tr>
              </tbody>
            </table>
            <h2>تفاصيل المشاكل</h2>
            <table>
              <thead><tr><th>ID</th><th>المتطلب</th><th>الشدة</th><th>العنصر</th><th>الوصف</th><th>التوصية</th></tr></thead>
              <tbody>
                {issues.length===0 && <tr><td colSpan="6">لا توجد مشاكل مكتشفة.</td></tr>}
                {issues.map(iss=>(
                  <tr key={iss.id}>
                    <td>{iss.id}</td><td>{iss.category}</td><td>{iss.severity}</td>
                    <td>{iss.elementLabel||"—"}</td>
                    <td style={{fontSize:11}}>{iss.description||"—"}</td>
                    <td style={{fontSize:11,color:"var(--text-3)"}}>{iss.recommendation||"—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <h2>المرجع</h2>
            <p style={{margin:0,direction:"ltr",textAlign:"start",fontFamily:"ui-monospace,monospace",fontSize:12}}>{data.reference}</p>
          </div>
        )}
        {activeFormat==="CSV" && (
          <div className="report-doc" style={{fontFamily:"ui-monospace,Menlo,monospace",direction:"ltr",textAlign:"start",fontSize:12,whiteSpace:"pre",overflow:"auto"}}>
{csvRows}
          </div>
        )}
        {activeFormat==="JSON" && (
          <div className="report-doc" style={{fontFamily:"ui-monospace,Menlo,monospace",direction:"ltr",textAlign:"start",fontSize:12,whiteSpace:"pre-wrap",overflow:"auto"}}>
{JSON.stringify(report,null,2)}
          </div>
        )}
      </div>
    </div>
  );
}
window.ReportPreview = ReportPreview;
