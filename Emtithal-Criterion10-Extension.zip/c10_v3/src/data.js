// data.js — Criterion 10: Search Template — Platforms Code
// مبني على القالب الرسمي index.tsx (DgaSearchBox, DgaButton, DgaFilteration, DgaPagination, Feedback)

const CRITERION_10_NAME    = "Ensure the search template is applied";
const CRITERION_10_NAME_AR = "التأكد من تطبيق قالب البحث كما في كود المنصات";

const CATEGORY_COLORS = {
  "قوالب":"#E49EDD", "عناصر":"#94DCF8", "أساسات":"#E5E500", "التجربة":"#9DA6F3"
};

const EMPTY_SUMMARY = {
  totalSearchFields:0, searchFieldsVisible:0,
  resultCardsFound:0, paginationFound:false, isSearchPage:false,
  fieldsWithIssues:0, issuesCount:0,
  searchBoxIssue:0, resultsIssue:0, controlsIssue:0, paginationIssue:0,
  bySeverity:{Critical:0,High:0,Medium:0,Low:0}
};

// ── 4 sub-criteria مطابقة لمكونات القالب الرسمي ───────────────────────────
const BASE_SUB_CRITERIA = [
  {
    id:          "search-box-compliance",
    requirement: "Search Box Compliance",
    category:    "Search Box Compliance",
    title:       "شريط البحث (DgaSearchBox + زر البحث)",
    description: "وجود DgaSearchBox بـ icon وشريط بحث size=lg، مع DgaButton (variant=primary-brand) بجانبه، ودعم RTL والعربية — وفق القالب الرسمي من كود المنصات.",
    howToFix:    "استخدم DgaSearchBox من platformscode-new-react مع placeholder بالعربية وأضف DgaButton(primary-brand) بجانبه في منطقة الهيدر.",
    reason:      "شريط البحث مطبّق بشكل صحيح وفق القالب.",
    status:      "pass", occurrences:0, issues:[]
  },
  {
    id:          "results-display-compliance",
    requirement: "Results Display Compliance",
    category:    "Results Display Compliance",
    title:       "عرض النتائج (عنوان + عدد + بطاقات + DgaDivider)",
    description: "عرض h1 'نتائج البحث' + عدد النتائج (N نتيجة وُجدت) + بطاقات النتائج [DgaTag[] + عنوان(link-primary) + وصف + تاريخ] + DgaDivider بين كل نتيجتين — وفق القالب.",
    howToFix:    "أضف h1 لعنوان النتائج، اعرض عدد النتائج، استخدم DgaTag لتصنيف كل نتيجة، واعرض التاريخ وDgaDivider بين النتائج.",
    reason:      "عرض النتائج مطابق للقالب.",
    status:      "pass", occurrences:0, issues:[]
  },
  {
    id:          "sort-filter-controls",
    requirement: "Sort & Filter Controls",
    category:    "Sort & Filter Controls",
    title:       "أدوات التحكم (زر الترتيب + DgaFilteration)",
    description: "وجود DgaButton (variant=secondary-outline) لترتيب النتائج بالتاريخ، و DgaFilteration بـ filterBlocks(categories chips) للفلترة — وفق القالب الرسمي.",
    howToFix:    "أضف DgaButton(secondary-outline) لترتيب النتائج وDgaFilteration بـ type=chips للتصنيفات وفق القالب.",
    reason:      "أدوات الترتيب والفلترة مطبّقة بشكل صحيح.",
    status:      "pass", occurrences:0, issues:[]
  },
  {
    id:          "pagination-feedback",
    requirement: "Pagination & Footer",
    category:    "Pagination & Footer",
    title:       "الترقيم والتغذية الراجعة (DgaPagination + Feedback)",
    description: "وجود DgaPagination (size=large) في أسفل نتائج البحث، ومكوّن Feedback (تغذية راجعة) بعد النتائج، ونص 'آخر تعديل' — وفق القالب الرسمي.",
    howToFix:    "أضف DgaPagination(totalPageCount, size=large) وFeedback component وتاريخ آخر تعديل وفق القالب.",
    reason:      "ترقيم الصفحات والتغذية الراجعة مطبّقان بشكل صحيح.",
    status:      "pass", occurrences:0, issues:[]
  }
];

function normaliseIssueForPanel(issue, index) {
  return {
    ...issue,
    n:         index + 1,
    target:    issue.selector || issue.domPath || `[data-pc-c10-id='${issue.id||index+1}']`,
    element:   issue.elementLabel || issue.selector || "عنصر البحث",
    current:   issue.actual   || issue.evidence || "يتطلب مراجعة",
    suggested: issue.expected || "مطابقة قالب البحث الرسمي في كود المنصات",
    location:  `${issue.category} · ${issue.selector||issue.domPath||"DOM"}`
  };
}

function createEmptyCriterion10Report() {
  return {
    criterion:"10", criterionName:CRITERION_10_NAME, criterionNameAr:CRITERION_10_NAME_AR,
    pageUrl:"—", pageTitle:"", scanDate:"",
    score:100, status:"Passed",
    summary:{...EMPTY_SUMMARY}, issues:[]
  };
}

function buildStandardDataFromReport(report) {
  const safeReport = report || createEmptyCriterion10Report();
  const grouped    = BASE_SUB_CRITERIA.map(item => ({...item, issues:[]}));

  (safeReport.issues||[]).forEach((issue, idx) => {
    const pi     = normaliseIssueForPanel(issue, idx);
    const target = grouped.find(g => g.category===issue.category||g.requirement===issue.requirement)||grouped[0];
    target.issues.push(pi);
  });

  grouped.forEach(item => {
    item.occurrences = item.issues.length;
    item.status      = item.issues.length ? "fail" : "pass";
    if (item.issues.length) item.reason = `تم العثور على ${item.issues.length} مشكلة تحتاج معالجة.`;
  });

  const passed  = grouped.filter(g=>g.status==="pass").length;
  const tScore  = Math.round((passed/grouped.length)*100);
  const tStatus = tScore===100?"Passed":tScore===0?"Failed":"Needs Review";
  const summary  = {...EMPTY_SUMMARY,...(safeReport.summary||{})};
  const scanDate = safeReport.scanDate||"";

  return {
    number:10, category:"قوالب", categoryColor:CATEGORY_COLORS["قوالب"],
    title:"مطابقة قالب البحث لنظام كود المنصات",
    titleEn:CRITERION_10_NAME,
    description:"التأكد من تطبيق قالب البحث الرسمي — يشمل: DgaSearchBox، عرض النتائج بالتصنيفات، أدوات الترتيب والفلترة، ترقيم الصفحات، والتغذية الراجعة.",
    reference:"https://design.dga.gov.sa/guidelines/templates/search-page | Figma: Templates Library - Platforms Code",
    pageUrl:safeReport.pageUrl||"—", pageTitle:safeReport.pageTitle||"الصفحة الحالية",
    scanDate, scanDateFormatted:scanDate?new Date(scanDate).toLocaleString("ar-SA"):"—",
    totalElementsScanned:summary.totalSearchFields||0,
    affectedElements:summary.fieldsWithIssues||0,
    score:tScore, severityScore:typeof safeReport.score==="number"?safeReport.score:100,
    status:tStatus, summary, report:safeReport, subCriteria:grouped
  };
}

function getIssueKey(issue){return issue?.id||issue?.target||`issue-${issue?.n}`;}

function getEffectiveSubCriteria(data,ignoredIssues={}) {
  return data.subCriteria.map(criterion=>{
    const original=criterion.issues||[];
    const active=original.filter(i=>!ignoredIssues[getIssueKey(i)]);
    const wasPass=criterion.status==="pass";
    const isPass=wasPass||active.length===0;
    return {
      ...criterion, status:isPass?"pass":"fail", issues:active,
      occurrences:wasPass?criterion.occurrences:active.length,
      reason:!wasPass&&active.length===0?"تم تجاهل جميع المشاكل في هذا المتطلب.":criterion.reason
    };
  });
}

function getCurrentCriterion10Report(){return window.CURRENT_C10_REPORT||createEmptyCriterion10Report();}
function setCurrentCriterion10Report(report){
  window.CURRENT_C10_REPORT=report||createEmptyCriterion10Report();
  window.STANDARD_DATA=buildStandardDataFromReport(window.CURRENT_C10_REPORT);
  return window.STANDARD_DATA;
}

const STANDARD_DATA=buildStandardDataFromReport(null);
window.CRITERION_10_NAME=CRITERION_10_NAME;
window.CRITERION_10_NAME_AR=CRITERION_10_NAME_AR;
window.EMPTY_SUMMARY=EMPTY_SUMMARY;
window.STANDARD_DATA=STANDARD_DATA;
window.createEmptyCriterion10Report=createEmptyCriterion10Report;
window.buildStandardDataFromReport=buildStandardDataFromReport;
window.getCurrentCriterion10Report=getCurrentCriterion10Report;
window.setCurrentCriterion10Report=setCurrentCriterion10Report;
window.getIssueKey=getIssueKey;
window.getEffectiveSubCriteria=getEffectiveSubCriteria;
