// search-audit.js — Criterion 10: Search Template — Platforms Code Design System
// مبني على القالب الرسمي: search/index.tsx من platformscode-new-react
// المكونات الإلزامية: DgaSearchBox, DgaButton(search+sort), DgaFilteration,
//                     بطاقات نتائج(Tags+title+desc+date), DgaPagination, Feedback
(function () {
  "use strict";

  const CRITERION      = "10";
  const CRITERION_NAME = "Ensure the search template is applied";

  const CAT_SEARCHBOX  = "Search Box Compliance";       // DgaSearchBox
  const CAT_RESULTS    = "Results Display Compliance";  // عنوان + عدد + بطاقات
  const CAT_CONTROLS   = "Sort & Filter Controls";      // DgaButton sort + DgaFilteration
  const CAT_PAGINATION = "Pagination & Footer";         // DgaPagination + Feedback

  const REQ_SEARCHBOX  = "Search Box Compliance";
  const REQ_RESULTS    = "Results Display Compliance";
  const REQ_CONTROLS   = "Sort & Filter Controls";
  const REQ_PAGINATION = "Pagination & Footer";

  // ── Utilities ──────────────────────────────────────────────────────────────
  function nowIso() { return new Date().toISOString(); }
  function cleanText(v, max) { return String(v||"").replace(/\s+/g," ").trim().slice(0,max||120); }

  function cssEscape(v) {
    if (window.CSS && CSS.escape) return CSS.escape(v);
    return String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&");
  }

  function isVisible(el) {
    if (!el||el.nodeType!==1) return false;
    try {
      var s=getComputedStyle(el);
      if (s.display==="none"||s.visibility==="hidden"||+s.opacity===0) return false;
      var r=el.getBoundingClientRect();
      return r.width>0&&r.height>0;
    } catch(e){return false;}
  }

  function getDomPath(el) {
    var parts=[],node=el;
    while(node&&node.nodeType===1&&node!==document.documentElement){
      var part=node.localName;
      if(node.id){parts.unshift("#"+cssEscape(node.id));break;}
      var parent=node.parentElement;
      if(parent){var same=Array.from(parent.children).filter(function(c){return c.localName===node.localName;});if(same.length>1)part+=":nth-of-type("+(same.indexOf(node)+1)+")";}
      parts.unshift(part);node=parent;
    }
    return parts.join(" > ");
  }

  function getSelector(el) {
    if(el.id) return "#"+cssEscape(el.id);
    return getDomPath(el)||el.localName||"element";
  }

  function elDesc(el) {
    var tag=el.localName||"element",id=el.id?"#"+el.id:"";
    var cls=(el.className&&typeof el.className==="string")?"."+el.className.trim().split(/\s+/).slice(0,2).join("."):"";
    var lbl=el.getAttribute("aria-label")||el.getAttribute("placeholder")||el.getAttribute("name")||el.getAttribute("id")||"";
    return "<"+tag+id+cls+">"+(lbl?" \""+cleanText(lbl,30)+"\"":"");
  }

  var _seq=0;
  function buildIssue(o) {
    _seq++;
    return {
      id:"C10-"+String(_seq).padStart(3,"0"),
      requirement:o.requirement, category:o.category,
      severity:o.severity, confidence:o.confidence,
      selector:getSelector(o.el), domPath:getDomPath(o.el),
      elementLabel:elDesc(o.el), href:"",
      description:o.description, evidence:o.evidence,
      expected:o.expected, actual:o.actual,
      recommendation:o.recommendation
    };
  }

  // ── Helpers ────────────────────────────────────────────────────────────────
  var AR=/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
  function hasArabic(t){return AR.test(t||"");}

  function isSearchPage() {
    var url=location.href.toLowerCase(), title=document.title.toLowerCase();
    var body=(document.body.textContent||"").slice(0,4000);
    return /search|بحث|query|q=/.test(url)||
           /نتائج.*بحث|search.*result/i.test(title)||
           /نتائج البحث|نتيجة البحث/.test(body);
  }

  // ── جمع عناصر البحث بطريقة شاملة ─────────────────────────────────────────
  function findSearchBox() {
    // DgaSearchBox يولّد input داخل dga-search-box أو class يحتوي search
    var candidates=[];
    var dgaSearch=document.querySelectorAll("dga-search-box, [class*='dga-search'], [class*='DgaSearch']");
    if(dgaSearch.length>0) return Array.from(dgaSearch).filter(isVisible);

    // input[type=search]
    document.querySelectorAll("input[type='search']").forEach(function(el){if(isVisible(el))candidates.push(el);});
    // inputs بخصائص بحثية
    document.querySelectorAll("input[type='text'],input:not([type])").forEach(function(el){
      if(!isVisible(el)) return;
      var attrs=["name","id","class","placeholder","aria-label"].map(function(a){return(el.getAttribute(a)||"").toLowerCase();});
      if(/search|بحث|q\b|query|ابحث/.test(attrs.join(" "))) candidates.push(el);
    });
    // role=search > input
    document.querySelectorAll("[role='search'] input").forEach(function(el){
      if(isVisible(el)&&!candidates.includes(el)) candidates.push(el);
    });
    return candidates;
  }

  function findSearchButton() {
    // DgaButton للبحث: variant=primary-brand داخل الهيدر أو بجانب صندوق البحث
    var allBtns=Array.from(document.querySelectorAll("button,[role='button']")).filter(isVisible);
    return allBtns.filter(function(btn){
      var txt=(btn.getAttribute("aria-label")||btn.textContent||"").trim().toLowerCase();
      var cls=(btn.className||"").toLowerCase();
      return /بحث|search/.test(txt)||/primary.*brand|brand.*primary/.test(cls)||
             btn.getAttribute("variant")==="primary-brand";
    });
  }

  function findSortButton() {
    var allBtns=Array.from(document.querySelectorAll("button,[role='button']")).filter(isVisible);
    return allBtns.filter(function(btn){
      var txt=(btn.getAttribute("aria-label")||btn.textContent||"").trim().toLowerCase();
      var cls=(btn.className||"").toLowerCase();
      return /ترتيب|sort/.test(txt)||/secondary.*outline/.test(cls)||
             btn.getAttribute("variant")==="secondary-outline";
    });
  }

  function findFilteration() {
    // DgaFilteration يولّد .filteration أو dga-filteration أو زر "تصفية/فلتر"
    var dga=document.querySelectorAll("dga-filteration,[class*='filteration'],[class*='DgaFilter']");
    if(dga.length>0) return Array.from(dga).filter(isVisible);
    var btns=Array.from(document.querySelectorAll("button,[role='button']")).filter(function(btn){
      var txt=(btn.getAttribute("aria-label")||btn.textContent||"").trim().toLowerCase();
      return /فلتر|تصفية|filter/i.test(txt)&&isVisible(btn);
    });
    var selects=Array.from(document.querySelectorAll("select,[class*='filter'],[class*='facet']")).filter(isVisible);
    var checkboxes=Array.from(document.querySelectorAll("form input[type='checkbox'],form input[type='radio']")).filter(isVisible);
    return [...btns,...selects,...checkboxes];
  }

  function findResultsSection() {
    // صندوق النتائج الرئيسي
    var selectors=[
      "main section","[class*='result']","[id*='result']",
      "[role='main']","main","[aria-label*='نتائج']","[aria-label*='result' i]"
    ];
    for(var i=0;i<selectors.length;i++){
      var els=Array.from(document.querySelectorAll(selectors[i])).filter(isVisible);
      if(els.length>0) return els[0];
    }
    return null;
  }

  function findResultCards() {
    // بطاقات النتائج: عناصر تحتوي tag + عنوان + وصف + تاريخ
    var cards=[];
    // dga-tag أو .dga-tag
    var tagContainers=document.querySelectorAll("[class*='dga-tag'],[class*='DgaTag'],dga-tag");
    var seen=new Set();
    tagContainers.forEach(function(tag){
      var parent=tag.parentElement&&tag.parentElement.parentElement;
      if(parent&&!seen.has(parent)&&isVisible(parent)){seen.add(parent);cards.push(parent);}
    });
    // fallback: divs تحتوي على عدة p
    if(cards.length===0){
      var divs=Array.from(document.querySelectorAll("div,article,li")).filter(function(el){
        return isVisible(el)&&el.querySelectorAll("p").length>=2&&el.offsetHeight<600&&el.offsetHeight>40;
      });
      cards=divs.slice(0,10);
    }
    return cards;
  }

  function findPagination() {
    var dga=document.querySelectorAll("dga-pagination,[class*='pagination'],[class*='DgaPagination'],[role='navigation'][aria-label*='page' i]");
    return Array.from(dga).filter(isVisible);
  }

  function findFeedback() {
    // Feedback component أو قسم تقييم
    var sel=["[class*='feedback'],[class*='Feedback'],[id*='feedback']","[class*='rating'],[class*='Rating']","[aria-label*='تقييم'],[aria-label*='feedback' i]","section:last-of-type"].join(",");
    return Array.from(document.querySelectorAll(sel)).filter(isVisible);
  }

  function findResultsCount() {
    // عرض عدد النتائج: "N نتيجة" أو "N found"
    return Array.from(document.querySelectorAll("p,span,div,h2")).filter(function(el){
      if(!isVisible(el)) return false;
      var txt=(el.textContent||"").trim();
      return txt.length<100&&/\d+\s*(نتيجة|وُجدت|found|result)/i.test(txt);
    });
  }

  function findResultsHeading() {
    return Array.from(document.querySelectorAll("h1,h2")).filter(function(el){
      if(!isVisible(el)) return false;
      var txt=(el.textContent||"").trim().toLowerCase();
      return /نتائج|result|search/i.test(txt);
    });
  }

  // ══════════════════════════════════════════════════════════════════════════
  // R1 — DgaSearchBox: شريط البحث الرسمي
  // القالب: DgaSearchBox (icon, showTrailingIcon, size=lg) + DgaButton(primary-brand)
  // ══════════════════════════════════════════════════════════════════════════
  function auditSearchBox(issues) {
    var fields=findSearchBox();

    // 1-a: وجود شريط البحث
    if(fields.length===0){
      issues.push(buildIssue({
        requirement:REQ_SEARCHBOX, category:CAT_SEARCHBOX,
        severity:"Critical", confidence:"High", el:document.body,
        description:"لا يوجد شريط بحث (DgaSearchBox) — المكوّن الإلزامي الأول في قالب كود المنصات.",
        evidence:"لم يتم العثور على input بحث أو dga-search-box في الصفحة",
        expected:"DgaSearchBox بـ icon وشريط بحث size=lg وفق القالب الرسمي.",
        actual:"لا يوجد شريط بحث.",
        recommendation:"أضف DgaSearchBox من مكتبة platformscode-new-react وفق القالب المعتمد."
      }));
      return;
    }

    var el=fields[0];

    // 1-b: الـ placeholder بالعربية
    var ph=el.getAttribute("placeholder")||(el.querySelector&&(el.querySelector("input")||{}).getAttribute&&(el.querySelector("input")||{getAttribute:function(){return"";}}).getAttribute("placeholder"))||"";
    var ariaLbl=el.getAttribute("aria-label")||"";
    if(!hasArabic(ph)&&!hasArabic(ariaLbl)){
      issues.push(buildIssue({
        requirement:REQ_SEARCHBOX, category:CAT_SEARCHBOX,
        severity:"Medium", confidence:"High", el:el,
        description:"شريط البحث بدون placeholder أو aria-label بالعربية — القالب يستخدم searchPlaceholder بالعربية.",
        evidence:"placeholder=\""+cleanText(ph,40)+"\" aria-label=\""+cleanText(ariaLbl,40)+"\"",
        expected:"placeholder بالعربية مثل \"ابحث هنا...\" أو \"اكتب للبحث\".",
        actual:"لا يوجد نص عربي في التسمية.",
        recommendation:"أضف placeholder بالعربية على DgaSearchBox."
      }));
    }

    // 1-c: زر البحث (DgaButton primary-brand) — موجود في القالب بجانب الـ SearchBox
    var searchBtns=findSearchButton();
    if(searchBtns.length===0){
      issues.push(buildIssue({
        requirement:REQ_SEARCHBOX, category:CAT_SEARCHBOX,
        severity:"High", confidence:"High", el:el,
        description:"لا يوجد زر بحث (DgaButton variant=primary-brand) — القالب يشترطه بجانب DgaSearchBox.",
        evidence:"لم يتم العثور على زر بحث ظاهر بجانب شريط البحث",
        expected:"DgaButton بـ variant=primary-brand وlabel=\"بحث\" بجانب DgaSearchBox.",
        actual:"لا يوجد زر بحث.",
        recommendation:"أضف DgaButton (variant=primary-brand, size=lg, label=بحث) بجانب DgaSearchBox."
      }));
    }

    // 1-d: RTL
    var st=getComputedStyle(el);
    var dir=st.direction||el.getAttribute("dir")||"";
    var docDir=document.documentElement.getAttribute("dir")||"";
    if(dir!=="rtl"&&docDir!=="rtl"){
      issues.push(buildIssue({
        requirement:REQ_SEARCHBOX, category:CAT_SEARCHBOX,
        severity:"High", confidence:"High", el:el,
        description:"شريط البحث لا يعمل بـ RTL — القالب العربي يشترط direction:rtl.",
        evidence:"direction="+dir+" doc dir="+docDir,
        expected:"direction:rtl أو dir=rtl على الصفحة.",
        actual:"اتجاه LTR أو غير محدد.",
        recommendation:"أضف dir=\"rtl\" على <html> أو الحاوي الرئيسي."
      }));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // R2 — عرض نتائج البحث (h1 + عدد النتائج + بطاقات Tags+title+desc+date)
  // ══════════════════════════════════════════════════════════════════════════
  function auditResultsDisplay(issues) {
    if(!isSearchPage()) return;

    // 2-a: عنوان "نتائج البحث" (h1)
    var headings=findResultsHeading();
    if(headings.length===0){
      issues.push(buildIssue({
        requirement:REQ_RESULTS, category:CAT_RESULTS,
        severity:"High", confidence:"Medium", el:document.body,
        description:"لا يوجد عنوان لقسم نتائج البحث — القالب يشترط h1 \"نتائج البحث\".",
        evidence:"لم يتم العثور على h1/h2 يحتوي \"نتائج\"",
        expected:"<h1>نتائج البحث</h1> أو ما يعادله في أعلى قسم النتائج.",
        actual:"لا يوجد عنوان لنتائج البحث.",
        recommendation:"أضف <h1> أو <h2> بنص \"نتائج البحث\" أعلى قسم النتائج."
      }));
    }

    // 2-b: عرض عدد النتائج (N نتيجة وُجدت)
    var countEls=findResultsCount();
    if(countEls.length===0){
      issues.push(buildIssue({
        requirement:REQ_RESULTS, category:CAT_RESULTS,
        severity:"Medium", confidence:"Medium", el:document.body,
        description:"عدد نتائج البحث غير ظاهر — القالب يعرض \"N نتيجة وُجدت\" أسفل العنوان.",
        evidence:"لا توجد نص يعرض عدد النتائج (pattern: \\d+ نتيجة|found)",
        expected:"نص يعرض عدد النتائج مثل: \"7 نتائج وُجدت\".",
        actual:"عدد النتائج غير مُعروض.",
        recommendation:"أضف <p>{count} نتيجة وُجدت</p> أسفل عنوان النتائج وفق القالب."
      }));
    }

    // 2-c: بطاقات النتائج بـ DgaTags
    var cards=findResultCards();
    if(cards.length===0){
      issues.push(buildIssue({
        requirement:REQ_RESULTS, category:CAT_RESULTS,
        severity:"High", confidence:"Medium", el:document.body,
        description:"لا توجد بطاقات نتائج بـ DgaTag — القالب يعرض كل نتيجة بـ [Tags + عنوان + وصف + تاريخ].",
        evidence:"لم يتم العثور على dga-tag أو عناصر تحمل تصنيفات في النتائج",
        expected:"كل نتيجة تحتوي: DgaTag[] + عنوان(link-primary) + وصف + تاريخ.",
        actual:"بطاقات النتائج لا تتبع هيكل القالب.",
        recommendation:"استخدم DgaTag (variant=neutral, size=md) لتصنيف كل نتيجة وفق القالب."
      }));
    } else {
      // 2-d: تحقق من وجود تاريخ في البطاقات
      var hasDate=cards.some(function(card){
        var txt=card.textContent||"";
        return /\d{4}|\d{1,2}[-\/]\d{1,2}|\d{1,2}\s*(يناير|فبراير|مارس|أبريل|مايو|يونيو|يوليو|أغسطس|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/i.test(txt);
      });
      if(!hasDate){
        issues.push(buildIssue({
          requirement:REQ_RESULTS, category:CAT_RESULTS,
          severity:"Low", confidence:"Low", el:cards[0],
          description:"بطاقات النتائج لا تعرض تاريخ النشر — القالب يشترط عرض التاريخ في كل نتيجة.",
          evidence:"لم يتم العثور على تاريخ في نصوص بطاقات النتائج",
          expected:"عرض تاريخ النشر في كل بطاقة نتيجة (مثل: 20-Nov-2024).",
          actual:"لا يوجد تاريخ في بطاقات النتائج.",
          recommendation:"أضف تاريخ النشر في كل بطاقة نتيجة وفق القالب الرسمي."
        }));
      }

      // 2-e: فاصل DgaDivider بين البطاقات
      var dividers=document.querySelectorAll("dga-divider,[class*='divider'],[class*='separator'],[class*='border-div']");
      if(dividers.length===0&&cards.length>1){
        issues.push(buildIssue({
          requirement:REQ_RESULTS, category:CAT_RESULTS,
          severity:"Low", confidence:"Medium", el:cards[0],
          description:"لا يوجد DgaDivider بين نتائج البحث — القالب يضع فاصل بين كل نتيجتين.",
          evidence:"لم يتم العثور على dga-divider أو .border-div بين بطاقات النتائج",
          expected:"DgaDivider بين كل نتيجتين وفق القالب الرسمي.",
          actual:"لا يوجد فاصل بين النتائج.",
          recommendation:"أضف DgaDivider بين كل نتيجتين وفق القالب (color=primary)."
        }));
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // R3 — أدوات التحكم: زر الترتيب (DgaButton sort) + DgaFilteration
  // ══════════════════════════════════════════════════════════════════════════
  function auditSortAndFilter(issues) {
    if(!isSearchPage()) return;

    // 3-a: زر الترتيب (DgaButton variant=secondary-outline + trailIcon sort)
    var sortBtns=findSortButton();
    if(sortBtns.length===0){
      issues.push(buildIssue({
        requirement:REQ_CONTROLS, category:CAT_CONTROLS,
        severity:"High", confidence:"Medium", el:document.body,
        description:"لا يوجد زر ترتيب (Sort) — القالب يشترط DgaButton (variant=secondary-outline) لترتيب النتائج بالتاريخ.",
        evidence:"لم يتم العثور على زر ترتيب/sort ظاهر",
        expected:"DgaButton بـ variant=secondary-outline ولabel=ترتيب مع أيقونة sort.",
        actual:"زر الترتيب غير موجود.",
        recommendation:"أضف DgaButton (variant=secondary-outline, trailIconType=sort-by-down-02) وفق القالب."
      }));
    }

    // 3-b: DgaFilteration (filterBlocks بـ categories chips)
    var filters=findFilteration();
    if(filters.length===0){
      issues.push(buildIssue({
        requirement:REQ_CONTROLS, category:CAT_CONTROLS,
        severity:"High", confidence:"Medium", el:document.body,
        description:"لا يوجد DgaFilteration — القالب يشترط فلترة بالتصنيفات (categories chips).",
        evidence:"لم يتم العثور على .filteration أو dga-filteration أو زر تصفية",
        expected:"DgaFilteration بـ filterBlocks تحتوي categories من نوع chips.",
        actual:"لا يوجد مكوّن فلترة.",
        recommendation:"أضف DgaFilteration بـ filterBlocks (categories chips) وفق القالب الرسمي."
      }));
    } else {
      // 3-c: هل الفلتر يحتوي على تصنيفات (chips/checkboxes) وليس فقط select
      var hasChips=filters.some(function(f){
        return f.querySelector&&(f.querySelector("[class*='chip']")||f.querySelector("input[type='checkbox']")||f.querySelector("[role='checkbox']"))!==null;
      });
      if(!hasChips&&filters.length>0){
        issues.push(buildIssue({
          requirement:REQ_CONTROLS, category:CAT_CONTROLS,
          severity:"Medium", confidence:"Medium", el:filters[0],
          description:"الفلترة لا تستخدم نظام الـ chips/categories — القالب يشترط DgaFilteration بـ type=chips.",
          evidence:"الفلتر لا يحتوي على chips أو checkboxes ضمن filterBlocks",
          expected:"DgaFilteration بـ filterBlocks[categories] من نوع chips.",
          actual:"الفلتر موجود لكن لا يستخدم نظام الـ chips.",
          recommendation:"استخدم DgaFilteration بـ type=chips في filterBlocks وفق القالب."
        }));
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // R4 — DgaPagination + Feedback (قسم التغذية الراجعة)
  // ══════════════════════════════════════════════════════════════════════════
  function auditPaginationAndFeedback(issues) {
    if(!isSearchPage()) return;

    // 4-a: DgaPagination
    var pagination=findPagination();
    if(pagination.length===0){
      issues.push(buildIssue({
        requirement:REQ_PAGINATION, category:CAT_PAGINATION,
        severity:"High", confidence:"Medium", el:document.body,
        description:"لا يوجد DgaPagination — القالب يشترط ترقيم الصفحات في أسفل نتائج البحث.",
        evidence:"لم يتم العثور على dga-pagination أو .pagination أو nav[aria-label*=page]",
        expected:"DgaPagination (siblingCount=1, size=large) في أسفل قسم النتائج.",
        actual:"لا يوجد ترقيم صفحات.",
        recommendation:"أضف DgaPagination (totalPageCount, size=large) وفق القالب الرسمي."
      }));
    }

    // 4-b: Feedback component (قسم التغذية الراجعة — إلزامي في القالب)
    var feedback=findFeedback();
    if(feedback.length===0){
      issues.push(buildIssue({
        requirement:REQ_PAGINATION, category:CAT_PAGINATION,
        severity:"Medium", confidence:"Low", el:document.body,
        description:"لا يوجد قسم Feedback (تغذية راجعة) — القالب يشترط وجوده بعد نتائج البحث.",
        evidence:"لم يتم العثور على .feedback أو عنصر تقييم في الصفحة",
        expected:"مكوّن Feedback بعد قسم النتائج وفق القالب.",
        actual:"لا يوجد قسم تغذية راجعة.",
        recommendation:"أضف مكوّن Feedback بعد نتائج البحث وفق القالب الرسمي."
      }));
    }

    // 4-c: "آخر تعديل" (lastModified — موجود في القالب)
    var hasLastMod=Array.from(document.querySelectorAll("p,span,time")).some(function(el){
      return isVisible(el)&&/آخر.*تعديل|last.*modif|تاريخ.*تحديث/i.test(el.textContent||"");
    });
    if(!hasLastMod){
      issues.push(buildIssue({
        requirement:REQ_PAGINATION, category:CAT_PAGINATION,
        severity:"Low", confidence:"Low", el:document.body,
        description:"نص \"آخر تعديل\" غير موجود — القالب يعرضه في نهاية الصفحة.",
        evidence:"لم يتم العثور على نص آخر تعديل/last modified",
        expected:"<p>آخر تعديل: ...</p> في نهاية الصفحة وفق القالب.",
        actual:"نص آخر تعديل غير موجود.",
        recommendation:"أضف تاريخ آخر تعديل في نهاية صفحة البحث وفق القالب."
      }));
    }
  }

  // ── Summary ────────────────────────────────────────────────────────────────
  function buildSummary(issues) {
    var affected=new Set(issues.map(function(i){return i.selector||i.domPath;}));
    var fields=findSearchBox();
    var cards=findResultCards();
    var pagination=findPagination();
    return {
      totalSearchFields:   fields.length,
      searchFieldsVisible: fields.filter(isVisible).length,
      resultCardsFound:    cards.length,
      paginationFound:     pagination.length>0,
      isSearchPage:        isSearchPage(),
      fieldsWithIssues:    affected.size,
      issuesCount:         issues.length,
      searchBoxIssue:      issues.filter(function(i){return i.category===CAT_SEARCHBOX;}).length,
      resultsIssue:        issues.filter(function(i){return i.category===CAT_RESULTS;}).length,
      controlsIssue:       issues.filter(function(i){return i.category===CAT_CONTROLS;}).length,
      paginationIssue:     issues.filter(function(i){return i.category===CAT_PAGINATION;}).length,
      bySeverity:{
        Critical:issues.filter(function(i){return i.severity==="Critical";}).length,
        High:    issues.filter(function(i){return i.severity==="High";}).length,
        Medium:  issues.filter(function(i){return i.severity==="Medium";}).length,
        Low:     issues.filter(function(i){return i.severity==="Low";}).length
      }
    };
  }

  function computeScore(issues) {
    var w={Critical:34,High:20,Medium:10,Low:5};
    return Math.max(0,100-issues.reduce(function(s,i){return s+(w[i.severity]||0);},0));
  }

  // ── Highlight ──────────────────────────────────────────────────────────────
  function getHState(){if(!window.__pcC10H)window.__pcC10H={items:[],timer:null};return window.__pcC10H;}

  function clearHighlights(){
    var st=getHState();
    if(st.timer){clearTimeout(st.timer);st.timer=null;}
    st.items.forEach(function(r){
      if(!r.el||!r.el.style)return;
      r.el.style.outline=r.outline;r.el.style.outlineOffset=r.oo;
      r.el.style.boxShadow=r.bs;r.el.style.scrollMargin=r.sm;
    });
    st.items=[];
    document.querySelectorAll("[data-pc-c10-b='1']").forEach(function(n){n.remove();});
    return true;
  }

  function findEl(sel,path){
    var el=null;
    if(sel){try{el=document.querySelector(sel);}catch(e){}}
    if(!el&&path){try{el=document.querySelector(path);}catch(e){}}
    return el;
  }

  function addBadge(el,label,idx){
    var r=el.getBoundingClientRect(),b=document.createElement("div");
    b.setAttribute("data-pc-c10-b","1");
    b.textContent=idx+". "+(label||"C10");
    b.style.cssText=["position:absolute","top:"+Math.max(8,r.top+scrollY-26)+"px",
      "left:"+Math.max(8,r.left+scrollX)+"px","z-index:2147483647",
      "background:#0369a1","color:#fff","font:600 10px system-ui,sans-serif",
      "padding:2px 7px","border-radius:999px","box-shadow:0 2px 8px rgba(0,0,0,.3)",
      "pointer-events:none"].join(";");
    document.documentElement.appendChild(b);
  }

  function highlightIssues(items,label){
    clearHighlights();
    var st=getHState(),seen=new Set(),els=[];
    (items||[]).forEach(function(item){
      var el=findEl(item.selector,item.domPath);
      if(!el||seen.has(el))return;
      seen.add(el);els.push({el:el,label:item.category||label||"C10"});
    });
    els.forEach(function(item,i){
      var el=item.el;
      st.items.push({el:el,outline:el.style.outline,oo:el.style.outlineOffset,bs:el.style.boxShadow,sm:el.style.scrollMargin});
      el.style.outline="3px solid #0369a1";el.style.outlineOffset="3px";
      el.style.boxShadow="0 0 0 5px rgba(3,105,161,0.18)";el.style.scrollMargin="96px";
      addBadge(el,item.label,i+1);
    });
    if(els[0])els[0].el.scrollIntoView({behavior:"smooth",block:"center"});
    st.timer=setTimeout(function(){clearHighlights();},9000);
    return els.length;
  }

  function highlightIssue(sel,path,label){return highlightIssues([{selector:sel,domPath:path,category:label}],label)>0;}

  // ── Main ───────────────────────────────────────────────────────────────────
  async function runAudit() {
    _seq=0; clearHighlights();
    var issues=[];
    auditSearchBox(issues);
    auditResultsDisplay(issues);
    auditSortAndFilter(issues);
    auditPaginationAndFeedback(issues);
    var score=computeScore(issues);
    var hasCrit=issues.some(function(i){return i.severity==="Critical";});
    var status=score===100?"Passed":(score<70||hasCrit)?"Failed":"Needs Review";
    return {
      criterion:CRITERION, criterionName:CRITERION_NAME,
      pageUrl:location.href, pageTitle:document.title,
      scanDate:nowIso(), score:score, status:status,
      summary:buildSummary(issues), issues:issues
    };
  }

  window.PlatformsCodeSearchAudit={runAudit:runAudit,highlightIssue:highlightIssue,highlightIssues:highlightIssues,clearHighlights:clearHighlights};
})();
