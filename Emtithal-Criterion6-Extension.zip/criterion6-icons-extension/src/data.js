// data.js — Criterion 6: Icon Usage Compliance
const CRITERION_6_NAME    = "Ensure usage of approved icons as per the Unified Design System (Code of Platforms)";
const CRITERION_6_NAME_AR = "ضمان استخدام الأيقونات المعتمدة وفق نظام التصميم الموحد (كود المنصات)";
const CATEGORY_COLORS = {"أساسات":"#E5E500","قوالب":"#E49EDD","عناصر":"#94DCF8","التجربة":"#9DA6F3"};

const EMPTY_SUMMARY = {
  totalIcons:0,visibleIcons:0,iconsWithIssues:0,issuesCount:0,
  libraryIssue:0,colorUsageIssue:0,featuredIconIssue:0,customIconIssue:0,
  bySeverity:{Critical:0,High:0,Medium:0,Low:0,"Manual Review":0}
};

const BASE_SUB_CRITERIA = [
  {
    id:"library-compliance",requirement:"Official Icon Library Compliance",category:"Unapproved Icon Library",
    title:"الالتزام بمكتبة الأيقونات الرسمية دون تعديل الحجم أو اللون",
    description:"التحقق من أن جميع الأيقونات مأخوذة من مكتبة الأيقونات الرسمية في كود المنصات، وأنه لم يتم تعديل حجمها (16px/20px/24px) أو ألوانها (fill/stroke) مباشرة.",
    howToFix:"استخدم الأيقونات من المكتبة الرسمية بأحجامها المعتمدة. استبدل fill/stroke المضمّن بـ currentColor أو CSS Variables.",
    reason:"جميع الأيقونات تستخدم المكتبة الرسمية بالحجم والألوان المعتمدة.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"color-usage-compliance",requirement:"Icon Color Usage Compliance",category:"Incorrect Icon Color Usage",
    title:"الاستخدام الصحيح لألوان الأيقونات (Status vs General)",
    description:"التحقق من أن ألوان الحالة (success/error/warning/info) محجوزة للسياقات التنبيهية فقط، وأن الأيقونات في السياقات العامة تستخدم ألوانًا محايدة أو أساسية.",
    howToFix:"استخدم ألوان الحالة (أخضر/أحمر/برتقالي/أزرق) فقط في التنبيهات والرسائل. في السياقات العامة استخدم الرمادي أو الأخضر الأساسي.",
    reason:"جميع الأيقونات تستخدم الألوان المناسبة لسياقها.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"featured-icon-compliance",requirement:"Featured Icon for Large Sizes",category:"Featured Icon Missing",
    title:"استخدام Featured Icon للأيقونات الأكبر من 24px",
    description:"التحقق من أن الأيقونات الأكبر من 24px تستخدم نمط 'Featured Icon' المعتمد في كود المنصات، وأن ألوانها وأحجامها لم تتغير.",
    howToFix:"استخدم مكوّن Featured Icon الرسمي للأيقونات الكبيرة بدلاً من تكبير الأيقونة العادية. لا تعدل ألوانه أو أحجامه.",
    reason:"الأيقونات الكبيرة تستخدم نمط Featured Icon بشكل صحيح.",
    status:"pass",occurrences:0,issues:[]
  },
  {
    id:"custom-icon-compliance",requirement:"Custom Icon Guidelines Compliance",category:"Custom Icon Approval Required",
    title:"الأيقونات المخصصة تتبع الإرشادات وتُطلب موافقة",
    description:"في حال عدم وجود أيقونة مناسبة في المكتبة، يجب تصميم الأيقونة المخصصة وفق إرشادات كود المنصات وتقديم طلب موافقة عبر الرابط المرجعي.",
    howToFix:"راجع إرشادات تصميم الأيقونات على design.dga.gov.sa وتأكد من وجود aria-label وأحجام معتمدة وتقديم طلب الموافقة.",
    reason:"لم يتم العثور على أيقونات مخصصة تحتاج مراجعة.",
    status:"pass",occurrences:0,issues:[]
  }
];

function normaliseIssueForPanel(issue,index){
  return {...issue,n:index+1,target:issue.selector||issue.domPath||`[data-pc-c6-id='${issue.id||index+1}']`,element:issue.elementLabel||issue.selector||"أيقونة",current:issue.actual||issue.evidence||"يتطلب مراجعة",suggested:issue.expected||"مطابقة إرشادات الأيقونات في كود المنصات",location:`${issue.category} · ${issue.selector||issue.domPath||"DOM"}`};
}

function createEmptyCriterion6Report(){
  return {criterion:"6",criterionName:CRITERION_6_NAME,criterionNameAr:CRITERION_6_NAME_AR,pageUrl:"—",pageTitle:"",scanDate:"",score:100,status:"Passed",summary:{...EMPTY_SUMMARY},issues:[]};
}

function buildStandardDataFromReport(report){
  const safeReport=report||createEmptyCriterion6Report();
  const grouped=BASE_SUB_CRITERIA.map(item=>({...item,issues:[]}));
  (safeReport.issues||[]).forEach((issue,idx)=>{
    const pi=normaliseIssueForPanel(issue,idx);
    const target=grouped.find(g=>g.category===issue.category||g.requirement===issue.requirement)||grouped[0];
    target.issues.push(pi);
  });
  grouped.forEach(item=>{
    item.occurrences=item.issues.length;item.status=item.issues.length?"fail":"pass";
    if(item.issues.length) item.reason=`تم العثور على ${item.issues.length} مشكلة تحتاج إلى معالجة ضمن هذا المتطلب.`;
  });
  const passed=grouped.filter(g=>g.status==="pass").length;
  const tScore=Math.round((passed/grouped.length)*100);
  const tStatus=tScore===100?"Passed":tScore===0?"Failed":"Needs Review";
  const summary={...EMPTY_SUMMARY,...(safeReport.summary||{})};
  const scanDate=safeReport.scanDate||"";
  return {
    number:6,category:"أساسات",categoryColor:CATEGORY_COLORS["أساسات"],
    title:"استخدام الأيقونات المعتمدة وفق كود المنصات",titleEn:CRITERION_6_NAME,
    description:"ضمان استخدام الأيقونات من المكتبة الرسمية بأحجامها المعتمدة وألوانها الصحيحة، مع استخدام Featured Icon للأحجام الكبيرة وإرشادات الأيقونات المخصصة.",
    reference:"https://design.dga.gov.sa/guidelines/foundations/iconography",
    pageUrl:safeReport.pageUrl||"—",pageTitle:safeReport.pageTitle||"الصفحة الحالية",
    scanDate,scanDateFormatted:scanDate?new Date(scanDate).toLocaleString("ar-SA"):"—",
    totalElementsScanned:summary.totalIcons||0,affectedElements:summary.iconsWithIssues||0,
    score:tScore,severityScore:typeof safeReport.score==="number"?safeReport.score:100,
    status:tStatus,summary,report:safeReport,subCriteria:grouped
  };
}

function getIssueKey(issue){return issue?.id||issue?.target||`issue-${issue?.n}`;}
function getEffectiveSubCriteria(data,ignoredIssues={}){
  return data.subCriteria.map(criterion=>{
    const original=criterion.issues||[],active=original.filter(i=>!ignoredIssues[getIssueKey(i)]);
    const wasPass=criterion.status==="pass",isPass=wasPass||active.length===0;
    return {...criterion,status:isPass?"pass":"fail",issues:active,occurrences:wasPass?criterion.occurrences:active.length,reason:!wasPass&&active.length===0?"تم تجاهل جميع المشاكل لهذا المتطلب.":criterion.reason};
  });
}
function getCurrentCriterion6Report(){return window.CURRENT_C6_REPORT||createEmptyCriterion6Report();}
function setCurrentCriterion6Report(report){window.CURRENT_C6_REPORT=report||createEmptyCriterion6Report();window.STANDARD_DATA=buildStandardDataFromReport(window.CURRENT_C6_REPORT);return window.STANDARD_DATA;}

const STANDARD_DATA=buildStandardDataFromReport(null);
window.CRITERION_6_NAME=CRITERION_6_NAME;window.CRITERION_6_NAME_AR=CRITERION_6_NAME_AR;
window.EMPTY_SUMMARY=EMPTY_SUMMARY;window.STANDARD_DATA=STANDARD_DATA;
window.createEmptyCriterion14Report=createEmptyCriterion6Report;
window.createEmptyCriterion6Report=createEmptyCriterion6Report;
window.buildStandardDataFromReport=buildStandardDataFromReport;
window.getCurrentCriterion14Report=getCurrentCriterion6Report;
window.getCurrentCriterion6Report=getCurrentCriterion6Report;
window.setCurrentCriterion14Report=setCurrentCriterion6Report;
window.setCurrentCriterion6Report=setCurrentCriterion6Report;
window.getIssueKey=getIssueKey;window.getEffectiveSubCriteria=getEffectiveSubCriteria;
