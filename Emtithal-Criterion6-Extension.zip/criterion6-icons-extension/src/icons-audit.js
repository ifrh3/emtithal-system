// icons-audit.js — Criterion 6: Icon Usage Compliance
// Platforms Code Design System — كود المنصات
(function () {
  "use strict";

  const CRITERION      = "6";
  const CRITERION_NAME = "Ensure usage of approved icons as per the Unified Design System (Code of Platforms)";

  const CAT_LIB      = "Unapproved Icon Library";
  const CAT_COLOR    = "Incorrect Icon Color Usage";
  const CAT_FEATURED = "Featured Icon Missing";
  const CAT_CUSTOM   = "Custom Icon Approval Required";

  const REQ_LIB      = "Official Icon Library Compliance";
  const REQ_COLOR    = "Icon Color Usage Compliance";
  const REQ_FEATURED = "Featured Icon for Large Sizes";
  const REQ_CUSTOM   = "Custom Icon Guidelines Compliance";

  // ── Utilities ──────────────────────────────────────────────────────────────
  function nowIso() { return new Date().toISOString(); }
  function cleanText(v,max=120){ return String(v||"").replace(/\s+/g," ").trim().slice(0,max); }
  function cssEscape(v){ if(window.CSS&&CSS.escape) return CSS.escape(v); return String(v).replace(/[^a-zA-Z0-9_-]/g,"\\$&"); }
  function cssNum(v){ const n=parseFloat(String(v||"").replace("px","")); return isFinite(n)?n:0; }

  function parseRgb(color){
    const s=String(color||"").trim().toLowerCase();
    if(!s||s==="transparent"||s==="rgba(0, 0, 0, 0)") return {r:0,g:0,b:0,a:0};
    const m=s.match(/^rgba?\(([^)]+)\)$/);
    if(m){const p=m[1].split(/[,/ ]+/).map(parseFloat).filter(isFinite);return{r:p[0]||0,g:p[1]||0,b:p[2]||0,a:p.length>3?p[3]:1};}
    const h=s.match(/^#([0-9a-f]{3,8})$/i);
    if(h){let v=h[1];if(v.length===3||v.length===4)v=v.split("").map(c=>c+c).join("");return{r:parseInt(v.slice(0,2),16),g:parseInt(v.slice(2,4),16),b:parseInt(v.slice(4,6),16),a:v.length>=8?parseInt(v.slice(6,8),16)/255:1};}
    return {r:0,g:0,b:0,a:-1};
  }
  function rgbToHsl(c){
    const r=c.r/255,g=c.g/255,b=c.b/255,max=Math.max(r,g,b),min=Math.min(r,g,b);
    let h=0,s=0;const l=(max+min)/2;
    if(max!==min){const d=max-min;s=l>0.5?d/(2-max-min):d/(max+min);switch(max){case r:h=(g-b)/d+(g<b?6:0);break;case g:h=(b-r)/d+2;break;case b:h=(r-g)/d+4;}h*=60;}
    return {h,s,l};
  }

  function isVisible(el){
    if(!el||el.nodeType!==1) return false;
    const st=getComputedStyle(el);
    if(st.display==="none"||st.visibility==="hidden"||+st.opacity===0) return false;
    const r=el.getBoundingClientRect();
    return r.width>0&&r.height>0;
  }
  function getDomPath(el){
    const parts=[];let node=el;
    while(node&&node.nodeType===1&&node!==document.documentElement){
      let part=node.localName;
      if(node.id){parts.unshift(`#${cssEscape(node.id)}`);break;}
      const parent=node.parentElement;
      if(parent){const same=Array.from(parent.children).filter(c=>c.localName===node.localName);if(same.length>1)part+=`:nth-of-type(${same.indexOf(node)+1})`;}
      parts.unshift(part);node=parent;
    }
    return parts.join(" > ");
  }
  function getSelector(el){if(el.id)return`#${cssEscape(el.id)}`;return getDomPath(el)||el.localName||"element";}
  function elDesc(el){
    const tag=el.localName||"el",id=el.id?`#${el.id}`:"";
    const cls=el.className&&typeof el.className==="string"?"."+el.className.trim().split(/\s+/).slice(0,2).join("."):"";
    const ariaLabel=el.getAttribute("aria-label")||"";
    const title=el.querySelector("title")?.textContent||"";
    return `<${tag}${id}${cls}>${(ariaLabel||title)?` "${cleanText(ariaLabel||title,25)}"`:""}`;
  }

  let _seq=0;
  function buildIssue({requirement,category,severity,confidence,el,description,evidence,expected,actual,recommendation}){
    _seq++;
    return {id:`C6-${String(_seq).padStart(3,"0")}`,requirement,category,severity,confidence,selector:getSelector(el),domPath:getDomPath(el),elementLabel:elDesc(el),href:"",description,evidence,expected,actual,recommendation};
  }

  // ── Detect Icons ───────────────────────────────────────────────────────────
  function detectIcons(){
    const selectors=[
      // SVG icons
      "svg[aria-label]","svg[role='img']","svg[class*='icon' i]",
      "svg[class*='ic-' i]","svg[data-icon]","svg[aria-hidden='true']",
      // Icon fonts / web fonts
      "i[class*='icon' i]","i[class*='fa' i]","i[class*='bi' i]","i[class*='ri-' i]",
      "i[class*='ti-' i]","i[class*='material' i]","i[class*='mdi' i]","i[class*='ph-' i]",
      "span[class*='icon' i]","span[class*='material' i]","span[class*='mdi' i]",
      // Named icon classes
      "[class*='icon-']","[class*='-icon']","[data-icon]","[data-feather]",
      // Img used as icons (small images)
      "img[alt=''][width]","img[aria-hidden='true']"
    ];
    const seen=new Set(),results=[];
    document.querySelectorAll(selectors.join(",")).forEach(el=>{
      if(seen.has(el))return;
      seen.add(el);
      // Exclude large images (not icons)
      if(el.localName==="img"){
        const w=el.naturalWidth||cssNum(el.getAttribute("width")||"0");
        const h=el.naturalHeight||cssNum(el.getAttribute("height")||"0");
        if(w>64||h>64)return; // Too big to be an icon
      }
      // Exclude SVGs that are illustrations (large)
      if(el.localName==="svg"){
        const rect=el.getBoundingClientRect();
        if(rect.width>80&&rect.height>80)return;
      }
      results.push(el);
    });
    return results;
  }

  // ── Size helpers ───────────────────────────────────────────────────────────
  function getIconSize(el){
    const rect=el.getBoundingClientRect();
    const st=getComputedStyle(el);
    const w=rect.width||cssNum(st.width)||cssNum(el.getAttribute("width")||"0");
    const h=rect.height||cssNum(st.height)||cssNum(el.getAttribute("height")||"0");
    return {w,h,max:Math.max(w,h)};
  }

  // ── Color helpers ──────────────────────────────────────────────────────────
  function getIconColor(el){
    const st=getComputedStyle(el);
    // For SVG: check fill, stroke, color
    const fill=st.fill||el.getAttribute("fill");
    const stroke=st.stroke||el.getAttribute("stroke");
    const color=st.color;
    // Prefer fill for SVG
    if(el.localName==="svg"||el.closest("svg")){
      if(fill&&fill!=="none"&&!fill.includes("none")) return fill;
      if(stroke&&stroke!=="none") return stroke;
    }
    return color||fill||"";
  }

  function colorToHsl(colorStr){
    if(!colorStr) return null;
    const c=parseRgb(colorStr);
    if(c.a<0||c.a<=0.05) return null;
    return rgbToHsl(c);
  }

  function isStatusColor(hsl,config){
    if(!hsl) return false;
    const cfg=config?.icons?.statusColors||{};
    const minSat=cfg.statusSaturationMin||0.4;
    if(hsl.s<minSat) return false;
    const h=hsl.h;
    // Success (green)
    const sucH=cfg.successHue||[100,175];
    if(h>=sucH[0]&&h<=sucH[1]) return true;
    // Error (red, wraps around 360)
    const errH=cfg.errorHue||[340,10];
    if(errH[0]>errH[1]){ if(h>=errH[0]||h<=errH[1]) return true; }
    else if(h>=errH[0]&&h<=errH[1]) return true;
    // Warning (orange/yellow)
    const warnH=cfg.warningHue||[35,55];
    if(h>=warnH[0]&&h<=warnH[1]) return true;
    // Info (blue)
    const infoH=cfg.infoHue||[200,230];
    if(h>=infoH[0]&&h<=infoH[1]) return true;
    return false;
  }

  function isNeutralOrPrimary(hsl,config){
    if(!hsl) return true; // unknown = don't fail
    // Neutral = low saturation (grey)
    if(hsl.s<=0.2) return true;
    // Primary = approved green family
    if(hsl.h>=100&&hsl.h<=175&&hsl.s>=0.15) return true;
    // Very dark or very light (black/white variants)
    if(hsl.l<=0.1||hsl.l>=0.9) return true;
    return false;
  }

  // ── Context detection ──────────────────────────────────────────────────────
  function detectIconContext(el,config){
    const cfg=config?.icons?.statusColors||{};
    // Walk up to find context
    let node=el;
    for(let i=0;i<6;i++){
      if(!node||node===document.body) break;
      const cls=(node.className||"").toLowerCase();
      const role=(node.getAttribute("role")||"").toLowerCase();
      const ariaLabel=(node.getAttribute("aria-label")||"").toLowerCase();
      const combined=cls+" "+role+" "+ariaLabel;
      // Check for status context keywords
      const statusKws=cfg.statusContextKeywords||[];
      if(statusKws.some(kw=>combined.includes(kw.toLowerCase()))){
        return "status";
      }
      // Check for non-status context keywords
      const nonStatusKws=cfg.nonStatusContextKeywords||[];
      if(nonStatusKws.some(kw=>combined.includes(kw.toLowerCase()))){
        return "general";
      }
      node=node.parentElement;
    }
    return "unknown";
  }

  // ── Library detection ──────────────────────────────────────────────────────
  function detectIconLibrary(el,config){
    const cfg=config?.icons?.officialLibrary||{};
    const classes=Array.from(el.classList||[]).join(" ").toLowerCase();
    const knownClasses=cfg.knownLibraryClasses||[];
    const knownPrefixes=cfg.knownLibraryPrefixes||[];

    // Check known library classes
    const matchedLib=knownClasses.find(lib=>classes.includes(lib.toLowerCase()));
    if(matchedLib) return {known:true,lib:matchedLib};

    // Check known prefixes
    const matchedPrefix=knownPrefixes.find(p=>classes.includes(p.toLowerCase()));
    if(matchedPrefix) return {known:true,lib:matchedPrefix};

    // SVG from sprite/defs (use tag)
    if(el.localName==="use"||el.querySelector("use")) return {known:true,lib:"svg-sprite"};
    if(el.localName==="svg"&&(el.getAttribute("data-icon")||el.querySelector("path"))) return {known:true,lib:"svg-inline"};
    if(el.localName==="img"&&el.src) return {known:false,lib:"img",src:el.src};

    return {known:false,lib:"unknown"};
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 1 — Official Icon Library Compliance
  // Only use icons from the official library without size/color changes
  // ══════════════════════════════════════════════════════════════════════════
  function auditLibraryCompliance(el,config,issues){
    const cfg=config?.icons?.officialLibrary||{};
    if(!isVisible(el)) return;

    // 1-a: Inline size override (width/height attributes or inline style)
    const inline=el.getAttribute("style")||"";
    const hasInlineSize=/width|height/i.test(inline)&&!/var\(--/i.test(inline);
    const widthAttr=el.getAttribute("width");
    const heightAttr=el.getAttribute("height");
    const size=getIconSize(el);

    if(cfg.disallowInlineSizeOverride&&hasInlineSize){
      issues.push(buildIssue({
        requirement:REQ_LIB,category:CAT_LIB,severity:"Medium",confidence:"High",el,
        description:"الأيقونة تحتوي على تعديل مباشر للحجم (inline style width/height) — يجب استخدام قيم الحجم المعتمدة بدون تعديل.",
        evidence:`style="${cleanText(inline,120)}"`,
        expected:"استخدام الأيقونة بحجمها المعتمد (16px/20px/24px) بدون تعديل inline.",
        actual:`inline size override: ${inline}`,
        recommendation:"أزل تعديلات الحجم المباشرة واستخدم prop الحجم الرسمي من مكتبة الأيقونات."
      }));
    }

    // 1-b: Inline fill/stroke color override (not currentColor or CSS variable)
    const fillAttr=el.getAttribute("fill");
    const strokeAttr=el.getAttribute("stroke");
    const colorOverrides=[];
    if(fillAttr&&fillAttr!=="none"&&fillAttr!=="currentColor"&&fillAttr!=="currentcolor"&&!fillAttr.startsWith("var(--")){
      // Check if it's a hardcoded color
      if(/#|rgb|hsl/.test(fillAttr)) colorOverrides.push(`fill="${fillAttr}"`);
    }
    if(strokeAttr&&strokeAttr!=="none"&&strokeAttr!=="currentColor"&&strokeAttr!=="currentcolor"&&!strokeAttr.startsWith("var(--")){
      if(/#|rgb|hsl/.test(strokeAttr)) colorOverrides.push(`stroke="${strokeAttr}"`);
    }
    if(cfg.disallowInlineColorOverride&&colorOverrides.length>0){
      issues.push(buildIssue({
        requirement:REQ_LIB,category:CAT_LIB,severity:"High",confidence:"High",el,
        description:"الأيقونة تحتوي على تعديل مباشر للون (fill/stroke attribute مضمّن) — يجب استخدام currentColor أو CSS Variables بدلاً من ألوان مضمّنة.",
        evidence:colorOverrides.join(" | "),
        expected:"استخدام fill='currentColor' أو var(--color-…) من رموز التصميم.",
        actual:colorOverrides.join(", "),
        recommendation:"استبدل قيم fill/stroke المضمّنة بـ currentColor أو برموز CSS Variables من كود المنصات."
      }));
    }

    // 1-c: Non-approved size (not 16/20/24px) for standard icons
    const approvedSizes=cfg.approvedSizesPx||[16,20,24];
    const tolerance=2;
    const iconSize=size.max;
    const isFeaturedSize=iconSize>cfg.featuredIconMinPx||24;
    const isApprovedSize=approvedSizes.some(s=>Math.abs(iconSize-s)<=tolerance);
    if(iconSize>8&&iconSize<24-tolerance&&!isApprovedSize){
      issues.push(buildIssue({
        requirement:REQ_LIB,category:CAT_LIB,severity:"Low",confidence:"Medium",el,
        description:"حجم الأيقونة لا يتطابق مع الأحجام المعتمدة في كود المنصات (16px، 20px، 24px).",
        evidence:`size=${Math.round(iconSize)}px`,
        expected:`أحد الأحجام المعتمدة: ${approvedSizes.join("px، ")}px.`,
        actual:`size=${Math.round(iconSize)}px`,
        recommendation:"استخدم الحجم المعتمد الأقرب من مكتبة الأيقونات (16، 20، أو 24px)."
      }));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 2 — Icon Color Usage Compliance
  // Status icons only for status contexts; general icons use neutral/primary
  // ══════════════════════════════════════════════════════════════════════════
  function auditColorUsage(el,config,issues){
    if(!isVisible(el)) return;
    const iconColor=getIconColor(el);
    if(!iconColor||iconColor==="currentcolor"||iconColor.includes("var(--")) return;

    const hsl=colorToHsl(iconColor);
    if(!hsl) return; // Can't determine color — don't fail

    const isStatus=isStatusColor(hsl,config);
    const isNeutral=isNeutralOrPrimary(hsl,config);
    const context=detectIconContext(el,config);

    // 2-a: Status color used in non-status context
    if(isStatus&&context==="general"){
      issues.push(buildIssue({
        requirement:REQ_COLOR,category:CAT_COLOR,severity:"High",confidence:"Medium",el,
        description:"أيقونة تستخدم لون حالة (Status Color — success/error/warning/info) في سياق غير تنبيهي — ألوان الحالة محجوزة للتنبيهات فقط.",
        evidence:`color=${iconColor}; context=general; hsl=(${Math.round(hsl.h)},${Math.round(hsl.s*100)}%,${Math.round(hsl.l*100)}%)`,
        expected:"الأيقونات في السياقات العامة تستخدم ألوانًا محايدة (رمادي) أو أساسية (أخضر معتمد).",
        actual:`استخدام لون حالة (${iconColor}) في سياق غير تنبيهي.`,
        recommendation:"استبدل اللون بلون محايد/أساسي من رموز التصميم (var(--color-neutral) أو var(--color-primary))."
      }));
    }

    // 2-b: Non-status non-neutral color in general context (arbitrary color)
    if(!isStatus&&!isNeutral&&context!=="unknown"){
      issues.push(buildIssue({
        requirement:REQ_COLOR,category:CAT_COLOR,severity:"Medium",confidence:"Medium",el,
        description:"الأيقونة تستخدم لونًا لا ينتمي إلى عائلة الألوان المعتمدة (محايد أو أساسي) ولا هو لون حالة معتمد.",
        evidence:`color=${iconColor}; hsl=(${Math.round(hsl.h)}°,${Math.round(hsl.s*100)}%,${Math.round(hsl.l*100)}%)`,
        expected:"ألوان الأيقونات إما محايدة (رمادي) أو أساسية (أخضر معتمد) أو ألوان حالة للسياقات التنبيهية.",
        actual:`لون غير معتمد: ${iconColor}`,
        recommendation:"استبدل اللون برمز CSS Variable من نظام التصميم: var(--color-icon) أو var(--color-primary)."
      }));
    }

    // 2-c: Hardcoded color value (not using CSS variable) — regardless of context
    if(iconColor&&!iconColor.includes("var(--")&&/#|rgb|hsl/.test(iconColor)){
      const isBlackOrWhite=/^(#000|#000000|#fff|#ffffff|rgb\(0,0,0\)|rgb\(255,255,255\))$/i.test(iconColor.replace(/\s/g,""));
      if(!isBlackOrWhite){
        issues.push(buildIssue({
          requirement:REQ_COLOR,category:CAT_COLOR,severity:"Medium",confidence:"High",el,
          description:"الأيقونة تستخدم لونًا مضمّنًا مباشرة بدلاً من رموز CSS Variables من نظام التصميم.",
          evidence:`hardcoded color: ${iconColor}`,
          expected:"استخدام var(--color-…) من رموز نظام التصميم.",
          actual:`hardcoded: ${iconColor}`,
          recommendation:"استبدل اللون المضمّن برمز CSS Variable المعتمد من كود المنصات."
        }));
      }
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 3 — Featured Icon for Large Sizes (> 24px)
  // ══════════════════════════════════════════════════════════════════════════
  function auditFeaturedIcon(el,config,issues){
    if(!isVisible(el)) return;
    const cfg=config?.icons?.featuredIcon||{};
    const minPx=cfg.minSizePx||24;
    const size=getIconSize(el);

    if(size.max<=minPx+2) return; // Only check icons > 24px

    // Check if it's using a Featured Icon variant
    const classes=(el.className||"").toLowerCase();
    const featuredSignals=cfg.featuredSignals||["featured","مميزة","icon-featured"];
    const hasFeatured=featuredSignals.some(sig=>classes.includes(sig.toLowerCase()))
      ||el.closest("[class*='featured' i]")!==null
      ||(el.getAttribute("data-variant")||"").toLowerCase().includes("featured");

    if(!hasFeatured){
      issues.push(buildIssue({
        requirement:REQ_FEATURED,category:CAT_FEATURED,severity:"Medium",confidence:"Medium",el,
        description:`الأيقونة حجمها ${Math.round(size.max)}px — الأيقونات الأكبر من ${minPx}px يجب أن تستخدم نمط "Featured Icon" بدون تغيير ألوانها أو أحجامها.`,
        evidence:`size=${Math.round(size.max)}px; no featured-icon variant detected`,
        expected:`استخدام نمط "Featured Icon" للأيقونات > ${minPx}px كما هو معتمد في كود المنصات.`,
        actual:`أيقونة بحجم ${Math.round(size.max)}px بدون نمط Featured Icon.`,
        recommendation:`استخدم مكوّن "Featured Icon" الرسمي من كود المنصات للأيقونات الكبيرة بدلاً من تعديل الأيقونة العادية.`
      }));
    }

    // 3-b: Featured icon color/size must NOT be modified
    const inline=el.getAttribute("style")||"";
    if(hasFeatured&&inline&&/width|height|color|fill|stroke/i.test(inline)){
      issues.push(buildIssue({
        requirement:REQ_FEATURED,category:CAT_FEATURED,severity:"High",confidence:"High",el,
        description:"أيقونة Featured تحتوي على تعديلات مباشرة للحجم أو اللون — يُمنع تعديل متغيرات Featured Icon.",
        evidence:`featured icon with inline overrides: style="${cleanText(inline,120)}"`,
        expected:"استخدام Featured Icon بدون أي تعديل على الألوان أو الأحجام.",
        actual:`تعديلات مباشرة موجودة على Featured Icon.`,
        recommendation:"أزل جميع التعديلات المباشرة من مكوّن Featured Icon."
      }));
    }
  }

  // ══════════════════════════════════════════════════════════════════════════
  // REQUIREMENT 4 — Custom Icon Guidelines Compliance
  // Custom icons must follow guidelines and get approval
  // ══════════════════════════════════════════════════════════════════════════
  function auditCustomIcon(el,config,issues){
    if(!isVisible(el)) return;
    const cfg=config?.icons?.customIcon||{};
    const classes=(el.className||"").toLowerCase();
    const customSignals=cfg.customSignals||["custom-icon","icon-custom","my-icon","app-icon"];

    const isCustom=customSignals.some(sig=>classes.includes(sig.toLowerCase()))
      ||el.getAttribute("data-custom-icon")==="true"
      ||(el.getAttribute("data-icon")||"").includes("custom");

    if(!isCustom) return;

    // 4-a: Custom icon must have aria-label or title for accessibility
    const hasLabel=el.getAttribute("aria-label")||el.getAttribute("aria-labelledby")||el.querySelector("title");
    if(!hasLabel){
      issues.push(buildIssue({
        requirement:REQ_CUSTOM,category:CAT_CUSTOM,severity:"High",confidence:"High",el,
        description:"أيقونة مخصصة (Custom Icon) لا تحتوي على وصف نصي (aria-label/title) — المستخدمون الذين يستخدمون تقنيات المساعدة لن يفهموا معناها.",
        evidence:`custom icon without aria-label: "${elDesc(el)}"`,
        expected:"aria-label أو <title> وصفي لكل أيقونة مخصصة.",
        actual:"لا يوجد aria-label أو title.",
        recommendation:'أضف aria-label="وصف الأيقونة" أو <title> داخل SVG للأيقونة المخصصة.'
      }));
    }

    // 4-b: Custom icon must follow approved sizes
    const size=getIconSize(el);
    const approvedSizes=config?.icons?.officialLibrary?.approvedSizesPx||[16,20,24];
    const isApproved=approvedSizes.some(s=>Math.abs(size.max-s)<=2)||size.max>24;
    if(!isApproved&&size.max>4){
      issues.push(buildIssue({
        requirement:REQ_CUSTOM,category:CAT_CUSTOM,severity:"Medium",confidence:"Medium",el,
        description:"أيقونة مخصصة بحجم غير معتمد — الأيقونات المخصصة يجب أن تتبع نفس أحجام مكتبة الأيقونات الرسمية.",
        evidence:`custom icon size=${Math.round(size.max)}px`,
        expected:`حجم معتمد: ${approvedSizes.join("، ")}px أو > 24px مع نمط Featured.`,
        actual:`size=${Math.round(size.max)}px`,
        recommendation:"اضبط حجم الأيقونة المخصصة ليتوافق مع الأحجام المعتمدة في كود المنصات."
      }));
    }

    // 4-c: Manual review reminder for approval
    issues.push(buildIssue({
      requirement:REQ_CUSTOM,category:CAT_CUSTOM,severity:"Manual Review",confidence:"Low",el,
      description:"أيقونة مخصصة تحتاج إلى مراجعة يدوية للتحقق من استيفاء إرشادات التصميم وتقديم طلب الموافقة.",
      evidence:`custom icon detected: "${elDesc(el)}"`,
      expected:"الأيقونات المخصصة تتبع إرشادات التصميم وتحصل على موافقة عبر الرابط المرجعي.",
      actual:"أيقونة مخصصة — التحقق اليدوي مطلوب.",
      recommendation:"راجع إرشادات تصميم الأيقونات على design.dga.gov.sa وقدّم طلب الموافقة قبل النشر."
    }));
  }

  // ── Summary ────────────────────────────────────────────────────────────────
  function buildSummary(elements,allIssues){
    const affected=new Set(allIssues.filter(i=>i.severity!=="Manual Review").map(i=>i.selector||i.domPath));
    return {
      totalIcons:            elements.length,
      visibleIcons:          elements.filter(isVisible).length,
      iconsWithIssues:       affected.size,
      issuesCount:           allIssues.length,
      libraryIssue:          allIssues.filter(i=>i.category===CAT_LIB).length,
      colorUsageIssue:       allIssues.filter(i=>i.category===CAT_COLOR).length,
      featuredIconIssue:     allIssues.filter(i=>i.category===CAT_FEATURED).length,
      customIconIssue:       allIssues.filter(i=>i.category===CAT_CUSTOM).length,
      bySeverity:{
        Critical:    allIssues.filter(i=>i.severity==="Critical").length,
        High:        allIssues.filter(i=>i.severity==="High").length,
        Medium:      allIssues.filter(i=>i.severity==="Medium").length,
        Low:         allIssues.filter(i=>i.severity==="Low").length,
        "Manual Review":allIssues.filter(i=>i.severity==="Manual Review").length
      }
    };
  }

  function computeScore(issues,config){
    const w={Critical:34,High:20,Medium:10,Low:5,"Manual Review":1,...(config?.scoring||{})};
    return Math.max(0,100-issues.reduce((s,i)=>s+(w[i.severity]||0),0));
  }

  // ── Main ───────────────────────────────────────────────────────────────────
  async function runAudit(config={}){
    _seq=0;
    const elements=detectIcons();
    const allIssues=[];
    const seen=new Set();
    elements.forEach(el=>{
      if(seen.has(getSelector(el)))return;
      seen.add(getSelector(el));
      auditLibraryCompliance(el,config,allIssues);
      auditColorUsage(el,config,allIssues);
      auditFeaturedIcon(el,config,allIssues);
      auditCustomIcon(el,config,allIssues);
    });
    const score=computeScore(allIssues,config);
    const hasCrit=allIssues.some(i=>i.severity==="Critical");
    const status=score===100?"Passed":(score<70||hasCrit)?"Failed":"Needs Review";
    return {criterion:CRITERION,criterionName:CRITERION_NAME,pageUrl:location.href,pageTitle:document.title,scanDate:nowIso(),score,status,summary:buildSummary(elements,allIssues),issues:allIssues};
  }

  // ── Highlight ──────────────────────────────────────────────────────────────
  function getHState(){if(!window.__pcC6HL)window.__pcC6HL={items:[],timer:null};return window.__pcC6HL;}
  function clearHighlights(){
    const st=getHState();if(st.timer){clearTimeout(st.timer);st.timer=null;}
    st.items.forEach(r=>{if(!r.el||!r.el.style)return;r.el.style.outline=r.outline;r.el.style.outlineOffset=r.outlineOffset;r.el.style.boxShadow=r.boxShadow;r.el.style.scrollMargin=r.scrollMargin;});
    st.items=[];document.querySelectorAll("[data-pc-c6-badge='1']").forEach(n=>n.remove());return true;
  }
  function findEl(selector,domPath){let el=null;if(selector){try{el=document.querySelector(selector);}catch(_){}}if(!el&&domPath){try{el=document.querySelector(domPath);}catch(_){}}return el;}
  function addBadge(el,label,index){
    const rect=el.getBoundingClientRect(),b=document.createElement("div");
    b.setAttribute("data-pc-c6-badge","1");b.textContent=`${index}. ${label||"C6"}`;
    b.style.cssText=["position:absolute",`top:${Math.max(8,rect.top+window.scrollY-26)}px`,`left:${Math.max(8,rect.left+window.scrollX)}px`,"z-index:2147483647","background:#78350f","color:#fff","font:600 10px system-ui,sans-serif","padding:2px 7px","border-radius:999px","box-shadow:0 2px 8px rgba(0,0,0,.3)","pointer-events:none"].join(";");
    document.documentElement.appendChild(b);
  }
  function highlightIssues(items,label){
    clearHighlights();const st=getHState(),seen=new Set(),els=[];
    (items||[]).forEach(item=>{const el=findEl(item.selector,item.domPath);if(!el||seen.has(el))return;seen.add(el);els.push({el,label:item.category||label||"C6"});});
    els.forEach((item,i)=>{const el=item.el;st.items.push({el,outline:el.style.outline,outlineOffset:el.style.outlineOffset,boxShadow:el.style.boxShadow,scrollMargin:el.style.scrollMargin});el.style.outline="3px solid #78350f";el.style.outlineOffset="3px";el.style.boxShadow="0 0 0 5px rgba(120,53,15,0.18)";el.style.scrollMargin="96px";addBadge(el,item.label,i+1);});
    if(els[0])els[0].el.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"});
    st.timer=window.setTimeout(()=>clearHighlights(),9000);return els.length;
  }
  function highlightIssue(selector,domPath,label){return highlightIssues([{selector,domPath,category:label}],label)>0;}

  window.PlatformsCodeIconsAudit={runAudit,highlightIssue,highlightIssues,clearHighlights};
})();
